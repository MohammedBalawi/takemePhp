<?php
/**
 * Route page.
 *
 * All the route functions.
 *
 * @package    PWDDM
 * @subpackage PWDDM/includes
 * @author     powerfulwp <cs@powerfulwp.com>
 */

/**
 * Route page.
 *
 * All the route functions.
 *
 * @package    PWDDM
 * @subpackage PWDDM/includes
 * @author     powerfulwp <cs@powerfulwp.com>
 */
class PWDDM_Route {

	/**
	 * Google_api_key variable.
	 *
	 * @var string
	 */
	private $pwddm_google_api_key;

	/**
	 * Initialize the class.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->pwddm_google_api_key = get_option( 'pwddm_google_api_key', '' );
	}

	/**
	 * Route alerts
	 *
	 * @return html
	 */
	public function pwddm_route_alerts__premium_only() {
		$html = '';
		if ( '' !== $this->pwddm_google_api_key ) {
			$plain_route_note_info = __( 'The route has been optimized by distance, if you want to make changes you can drag and drop orders manually.' );
			$plain_route_note_wait = __( 'Optimize route, please wait...' );
		} else {
			$plain_route_note_info = __( 'The route is ready for optimization, you can make changes by drag and drop orders manually.' );
			$plain_route_note_wait = __( 'Please wait...' );
		}

		$html .= '
			<div class="pwddm_plain_route_wrap">
					<div class="row" id="pwddm_plain_route_row">
					<div class="col-12"><a id="pwddm_plainroute_btn" data_start =\'<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="edit" class="svg-inline--fa fa-edit fa-w-18" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="currentColor" d="M402.6 83.2l90.2 90.2c3.8 3.8 3.8 10 0 13.8L274.4 405.6l-92.8 10.3c-12.4 1.4-22.9-9.1-21.5-21.5l10.3-92.8L388.8 83.2c3.8-3.8 10-3.8 13.8 0zm162-22.9l-48.8-48.8c-15.2-15.2-39.9-15.2-55.2 0l-35.4 35.4c-3.8 3.8-3.8 10 0 13.8l90.2 90.2c3.8 3.8 10 3.8 13.8 0l35.4-35.4c15.2-15.3 15.2-40 0-55.2zM384 346.2V448H64V128h229.8c3.2 0 6.2-1.3 8.5-3.5l40-40c7.6-7.6 2.2-20.5-8.5-20.5H48C21.5 64 0 85.5 0 112v352c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V306.2c0-10.7-12.9-16-20.5-8.5l-40 40c-2.2 2.3-3.5 5.3-3.5 8.5z"></path></svg> ' . esc_attr( __( 'Plan your route', 'pwddm' ) ) . '\' data_finish =\'<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="lock" class="svg-inline--fa fa-lock fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M400 224h-24v-72C376 68.2 307.8 0 224 0S72 68.2 72 152v72H48c-26.5 0-48 21.5-48 48v192c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V272c0-26.5-21.5-48-48-48zm-104 0H152v-72c0-39.7 32.3-72 72-72s72 32.3 72 72v72z"></path></svg> ' . esc_attr( __( 'Finish planning route', 'pwddm' ) ) . '\' class=" btn btn-secondary  btn-block" href="#">
					<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="edit" class="svg-inline--fa fa-edit fa-w-18" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="currentColor" d="M402.6 83.2l90.2 90.2c3.8 3.8 3.8 10 0 13.8L274.4 405.6l-92.8 10.3c-12.4 1.4-22.9-9.1-21.5-21.5l10.3-92.8L388.8 83.2c3.8-3.8 10-3.8 13.8 0zm162-22.9l-48.8-48.8c-15.2-15.2-39.9-15.2-55.2 0l-35.4 35.4c-3.8 3.8-3.8 10 0 13.8l90.2 90.2c3.8 3.8 10 3.8 13.8 0l35.4-35.4c15.2-15.3 15.2-40 0-55.2zM384 346.2V448H64V128h229.8c3.2 0 6.2-1.3 8.5-3.5l40-40c7.6-7.6 2.2-20.5-8.5-20.5H48C21.5 64 0 85.5 0 112v352c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V306.2c0-10.7-12.9-16-20.5-8.5l-40 40c-2.2 2.3-3.5 5.3-3.5 8.5z"></path></svg> ' . esc_html( __( 'Plan your route', 'pwddm' ) ) . '</a></div>
					</div>
					<div id="pwddm_plain_route_note_wait" style="display:none;margin-top:17px">
						<div class="alert alert-primary">' . $plain_route_note_wait . '</div>
					</div>
					<div id="pwddm_plain_route_note_info" style="display:none;margin-top:17px">
						<div class="alert alert-primary" id="pwddm_plain_route_note_alert">' . $plain_route_note_info . ' <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></div>
					</div>
			</div>';
		return $html;
	}

	/**
	 * All Routes query.
	 *
	 * @since 1.4.0
	 * @return object
	 */
	public function pwddm_all_routes_query__premium_only( $manager_id ) {

		$array = array(
			'driver_clause' => array(
				'key'     => 'lddfw_driverid',
				'compare' => 'EXISTS',
			),
		);

		$params = array(
			'posts_per_page' => -1,
			'post_status'    => get_option( 'lddfw_out_for_delivery_status', '' ),
			'post_type'      => 'shop_order',
			'meta_query'     => array(
				array(
					'relation' => 'or',
					array(
						'city_clause' => array(
							'key'     => '_shipping_city',
							'compare' => 'NOT EXISTS',
						),
					),
					array(
						'city_clause' => array(
							'key'     => '_shipping_city',
							'compare' => 'EXISTS',
						),
					),
					array(
						'sort_clause' => array(
							'key'     => 'lddfw_order_sort',
							'compare' => 'EXISTS',
							'type'    => 'NUMERIC',
						),
					),
					array(
						'sort_clause' => array(
							'key'     => 'lddfw_order_sort',
							'compare' => 'NOT EXISTS',
							'type'    => 'NUMERIC',
						),
					),
				),
				$array,
			),
			'orderby'        => array(
				'driver_clause' => 'ASC',
				'sort_clause'   => 'ASC',
				'city_clause'   => 'ASC',
			),
		);

		return new WP_Query( $params );
	}

	/**
	 * Route query.
	 *
	 * @since 1.0.0
	 * @param int $driver_id driver user id.
	 * @return object
	 */
	public function pwddm_route_query__premium_only( $driver_id ) {

		$array = array(
			'key'     => 'pwddm_driverid',
			'value'   => $driver_id,
			'compare' => '=',
		);

		$params = array(
			'posts_per_page' => -1,
			'post_status'    => get_option( 'pwddm_out_for_delivery_status', '' ),
			'post_type'      => 'shop_order',
			'meta_query'     => array(
				'relation' => 'AND',
				array(
					'relation' => 'or',
					array(
						'city_clause' => array(
							'key'     => '_shipping_city',
							'compare' => 'NOT EXISTS',
						),
					),
					array(
						'city_clause' => array(
							'key'     => '_shipping_city',
							'compare' => 'EXISTS',
						),
					),
					array(
						'sort_clause' => array(
							'key'     => 'pwddm_order_sort',
							'compare' => 'EXISTS',
							'type'    => 'NUMERIC',
						),
					),
					array(
						'sort_clause' => array(
							'key'     => 'pwddm_order_sort',
							'compare' => 'NOT EXISTS',
							'type'    => 'NUMERIC',
						),
					),
				),
				$array,
			),
			'orderby'        => array(
				'sort_clause' => 'ASC',
				'city_clause' => 'ASC',
			),
		);

		return new WP_Query( $params );
	}


	/**
	 * Sort delivery.
	 *
	 * @since 1.0.0
	 * @param int $driver_id driver user id.
	 * @return json
	 */
	public function pwddm_sort_delivery__premium_only( $driver_id ) {
		$result = 0;
		if ( isset( $_POST['pwddm_wpnonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_POST['pwddm_wpnonce'] ) );
			if ( ! wp_verify_nonce( $nonce, 'pwddm-nonce' ) ) {
				$error = __( 'Security Check Failure - This alert may occur when you are logged in as an administrator and as a delivery driver on the same browser and the same device. If you want to work on both panels please try to work with two different browsers.', 'pwddm' );
			} else {
				$orders_list = ( isset( $_POST['pwddm_orders_list'] ) ) ? sanitize_text_field( wp_unslash( $_POST['pwddm_orders_list'] ) ) : '';
				if ( '' !== $orders_list ) {
					$orders_list_array = explode( ',', $orders_list );
					$counter           = 1;
					foreach ( $orders_list_array  as $order ) {
						if ( '' !== $order ) {
							update_post_meta( $order, 'pwddm_order_sort', $counter );
							++$counter;
						}
					}
					$result = 1;
				}
			}
		}
		$this->pwddm_set_delivery_origin__premium_only( $driver_id );
		return $result;
	}

	/**
	 * Set delivery origin.
	 *
	 * @since 1.0.0
	 * @param int $driver_id driver user id.
	 */
	public function pwddm_set_delivery_origin__premium_only( $driver_id ) {
		$wc_query      = $this->pwddm_route_query__premium_only( $driver_id );
		$store         = new LDDFW_Store();
		$store_address = $store->lddfw_store_address( 'map_address' );
		$origin        = $store_address;
		while ( $wc_query->have_posts() ) {
			$wc_query->the_post();
			$orderid = get_the_ID();
			$order   = wc_get_order( $orderid );

			$billing_address_1 = $order->get_billing_address_1();
			$billing_address_2 = $order->get_billing_address_2();
			$billing_city      = $order->get_billing_city();
			$billing_state     = $order->get_billing_state();
			$billing_postcode  = $order->get_billing_postcode();
			$billing_country   = $order->get_billing_country();

			$shipping_address_1 = $order->get_shipping_address_1();
			$shipping_address_2 = $order->get_shipping_address_2();
			$shipping_city      = $order->get_shipping_city();
			$shipping_state     = $order->get_shipping_state();
			$shipping_postcode  = $order->get_shipping_postcode();
			$shipping_country   = $order->get_shipping_country();

			if ( '' === $shipping_address_1 ) {
				$shipping_address_1 = $billing_address_1;
				$shipping_address_2 = $billing_address_2;
				$shipping_city      = $billing_city;
				$shipping_state     = $billing_state;
				$shipping_postcode  = $billing_postcode;
				$shipping_country   = $billing_country;
			}

			$shippingaddress = $shipping_address_1;
			if ( '' !== $shipping_address_2 ) {
				$shippingaddress .= ' ' . $shipping_address_2;
			}
			if ( '' !== $shipping_city ) {
				$shippingaddress .= ' ' . $shipping_city;
			}
			if ( '' !== $shipping_state ) {
				$shippingaddress .= ' ' . $shipping_state;
			}
			if ( '' !== $shipping_country ) {
				$shippingaddress .= ' ' . $shipping_country;
			}
			$shippingaddress = str_replace( ' ', '+', $shippingaddress );
			// set delivery origin.
			update_post_meta( $orderid, 'pwddm_order_origin', $origin );
			$origin = $shippingaddress;
		}
	}

	/**
	 * Route script.
	 *
	 * @since 1.0.0
	 * @return html
	 */
	public function pwddm_route_script__premium_only() {
		$html = '';
		if ( '' !== $this->pwddm_google_api_key ) {
			$store         = new LDDFW_Store();
			$store_address = $store->lddfw_store_address( 'map_address' );

			$html .= '
			<script>
				var pwddm_optimizeWaypoints_flag = false;
				var pwddm_google_api_key         =  "' . $this->pwddm_google_api_key . '";
				var pwddm_google_api_origin 	 =  "' . esc_attr( $store_address ) . '";
			</script>
			';
		}
		return $html;
	}

	/**
	 * Route button.
	 *
	 * @since 1.0.0
	 * @return html
	 */
	public function pwddm_route_button__premium_only() {
		$html = '';
		if ( '' !== $this->pwddm_google_api_key ) {
			$html .= '
			<div class="pwddm_footer_buttons">
				<div class="container">
					<div class="row">
						<div class="col-12"><a href="#" id="pwddm_route_btn" class="btn btn-lg btn-block btn-success">
						<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="map-marked-alt" class="svg-inline--fa fa-map-marked-alt fa-w-18" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="currentColor" d="M288 0c-69.59 0-126 56.41-126 126 0 56.26 82.35 158.8 113.9 196.02 6.39 7.54 17.82 7.54 24.2 0C331.65 284.8 414 182.26 414 126 414 56.41 357.59 0 288 0zm0 168c-23.2 0-42-18.8-42-42s18.8-42 42-42 42 18.8 42 42-18.8 42-42 42zM20.12 215.95A32.006 32.006 0 0 0 0 245.66v250.32c0 11.32 11.43 19.06 21.94 14.86L160 448V214.92c-8.84-15.98-16.07-31.54-21.25-46.42L20.12 215.95zM288 359.67c-14.07 0-27.38-6.18-36.51-16.96-19.66-23.2-40.57-49.62-59.49-76.72v182l192 64V266c-18.92 27.09-39.82 53.52-59.49 76.72-9.13 10.77-22.44 16.95-36.51 16.95zm266.06-198.51L416 224v288l139.88-55.95A31.996 31.996 0 0 0 576 426.34V176.02c0-11.32-11.43-19.06-21.94-14.86z"></path></svg></i> ' . esc_html( __( 'View Route', 'pwddm' ) ) . '</a></div>
					</div>
				</div>
			</div>';
		}
		return $html;
	}




	/**
	 * Drivers routes
	 *
	 * @since 1.4.0
	 * @return json
	 */
	public function pwddm_drivers_routes__premium_only( $pwddm_manager_id ) {
		$pwddm_manager_drivers = get_user_meta( $pwddm_manager_id, 'pwddm_manager_drivers', true );
		$wc_query            = $this->pwddm_all_routes_query__premium_only( $pwddm_manager_id );
		$route_array         = '';
		$store               = new LDDFW_Store();
		$lddfw_order 		 = new LDDFW_Order();
		$store_address       = $store->lddfw_store_address( 'map_address' );
		$drivers_counter     = 0;
		$last_pwddm_driverid = 0;

		function pwddm_random_color_part() {
			return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT );
		}

		function pwddm_random_color() {
			return pwddm_random_color_part() . pwddm_random_color_part() . pwddm_random_color_part();
		}
		
		$drivers_colors = array(
			'#86b8ff',
			'#008000',
			'#800080',
			'#000080',
			'#FF00FF',
			'#cb4b4b',
			'#3377aa',
			'#9440ed',
			'#800000',
			'#bd9b33',
			'#808080',
			'#808000',
		);

		if ( $wc_query->have_posts() ) {
				$route_array = '{ "data": [{"route": [';
			while ( $wc_query->have_posts() ) {

				$wc_query->the_post();
				$orderid = get_the_ID();
				$order   = wc_get_order( $orderid );
				$pwddm_driverid = $order->get_meta( 'lddfw_driverid' );
				$order_seller_id  = $store->lddfw_order_seller( $order );
				$driver_manager = get_user_meta( $pwddm_driverid, 'pwddm_manager', true );

				if ( ( '0' === $pwddm_manager_drivers && ( '' === $driver_manager || false === $driver_manager ) ) || ( '1' === $pwddm_manager_drivers || '' === $pwddm_manager_drivers ) || ( '2' === $pwddm_manager_drivers && ( strval( $driver_manager ) === strval( $pwddm_manager_id ) ) )) {

						// Get and fromat shipping address.
						$shipping_array       = $lddfw_order->lddfw_order_address( 'shipping', $order, $orderid );
						$shipping_map_address = lddfw_format_address( 'map_address', $shipping_array );

						// route array
						if ( $last_pwddm_driverid !== $pwddm_driverid ){

							if ( $drivers_counter > 0 ) {
								$route_array = substr($route_array, 0, -1);
								$route_array .= '] ,"destination": "'. esc_attr( $shipping_map_address ) .'"},';
							};
							$user              = get_userdata( $pwddm_driverid );
							$lddfw_driver_name = ( ! empty( $user ) ) ? $user->display_name : '';
							$image_id                 = get_user_meta( $pwddm_driverid, 'lddfw_driver_image', true );
							$lddfw_driver_travel_mode = LDDFW_Driver::get_driver_driving_mode( $pwddm_driverid, '' );

							$image    = '';
							if( intval( $image_id ) > 0 ) {
								$image = wp_get_attachment_image_src( $image_id, 'medium' )[0];
							}

							$origin = get_post_meta( $orderid, 'lddfw_order_origin', true );
							if ( '' === $origin ) {
								$origin = $store->lddfw_pickup_address( 'map_address', $order, $order_seller_id );
							}

							$driver_color = "#" . pwddm_random_color() ;
							if ( $drivers_counter < 12 ){
								$driver_color = $drivers_colors[$drivers_counter];
							}
							$route_array .= '{"driver": [{"id": "'.$pwddm_driverid.'","name": "'. esc_attr ( $lddfw_driver_name ).'","Image": "'. esc_attr ( $image ).'","color": "'.$driver_color.'", "travel_mode":"' . $lddfw_driver_travel_mode . '"}],"origin": "'. esc_attr( $origin ).'","waypoints": [';
							$drivers_counter += 1;
							$last_pwddm_driverid = $pwddm_driverid;
						}
						$route_array .= '{"order": "'.$orderid.'","address": "'. esc_attr( $shipping_map_address ) .'","status": "waiting","color": "#800000"},';
					 ?>
					 <?php
					 
				 	}
				?>
				<?php

			}

			if ( $drivers_counter > 0 ) {
				$route_array  = substr( $route_array, 0, -1 );
				$route_array .= '] ,"destination": "' . esc_attr( $shipping_map_address ) . '"}]}]	}';
			} else {
				$route_array = "{}";
			}


		} else {
			$route_array = '{}';
		}
		return $route_array;
	}


	/**
	 * Admin routes screen.
	 *
	 * @since 1.4.0
	 * @return void
	 */
	public function pwddm_routes_screen() {
		global $pwddm_manager_id;
		echo '<div class="wrap container">';
		echo '<div id="pwddm_routes_notice" style="display:none">' . esc_html( __( 'There are no routes for drivers.', 'pwddm' ) ) . '</div>';
		echo '<div id="pwddm_routes" style="display:none">
				<div class="row">  
				<div class="col-12 col-md-8">  
				<div id="pwddm_map123"></div>
				</div>
				<div class="col-12 col-md-4">  
				<div id="driver-panel"></div>
				</div>
				</div>
				</div>
			  </div>';
		$pwddm_google_api_key = get_option( 'lddfw_google_api_key', '' );
		?>

		<script>
			var geocoder;
			var infowindow;
			var driverMarker = [];
			var pwddm_waypts_array = [];
			var pwddm_map;
			<?php
			echo '
				var pwddm_ajax_url = "' . esc_url( admin_url( 'admin-ajax.php' ) ) . '";
				var pwddm_hour_text = "' . esc_js( __( 'hour', 'pwddm' ) ) . '";
				var pwddm_hours_text = "' . esc_js( __( 'hours', 'pwddm' ) ) . '";
				var pwddm_mins_text = "' . esc_js( __( 'mins', 'pwddm' ) ) . '";
				'
			?>
		</script>

		<?php
		$route = new PWDDM_Route();
		echo $route->pwddm_route_script__premium_only();

		?>
				<script>
				var pwddm_json='';
				function pwddm_get_routes_json()
				{
					return jQuery.ajax({
							type: "POST",
							url: pwddm_ajax_url,
							dataType: "json",
							 data: {
								action: 'pwddm_ajax',
								pwddm_service: 'pwddm_drivers_routes',
								pwddm_wpnonce: pwddm_nonce,
								pwddm_data_type: 'json',
								pwddm_manager_id: '<?php echo $pwddm_manager_id; ?>'
							},
							success:function(data){
								pwddm_json = data;
							},
							error: function(request, status, error) {
								console.log(error);
							}
						})
				}

				function pwddm_drivers()
				{
					if( typeof pwddm_json['data'] != 'undefined' ){
						jQuery.each(pwddm_json['data'], function(i, data) {
						if(data['route'] != "") {
							jQuery.each(data['route'], function(i, route) {
							   var pwddm_driver_id   = route['driver'][0]['id'];
							   var pwddm_driver_name 		= route['driver'][0]['name'];
							   var pwddm_driver_image		= route['driver'][0]['Image'];
							   var pwddm_driver_color		= route['driver'][0]['color'];
								var pwddm_driver_img = '';
							   if ( pwddm_driver_image != ""){
								pwddm_driver_img = '<img src="'+pwddm_driver_image+'">';
							   } else
							   {
								pwddm_driver_img = '<img src="<?php echo plugins_url() . '/' . PWDDM_FOLDER . '/public/images/user.png?ver=' . PWDDM_VERSION; ?>">';
							   }
							   //style='background-image:url("+pwddm_driver_image+")'
							   jQuery("#driver-panel").append("<div class='pwddm_driver_box active' data='"+pwddm_driver_id+"' id='driver_"+pwddm_driver_id+"'>" + pwddm_driver_img + "<div class='pwddm_driver_name'>" + pwddm_driver_name+ "</div><div class='pwddm_button'></div> <div class='pwddm_handle'></div> <div class='pwddm_line' style='background-color:"+pwddm_driver_color+";'></div> <div class='pwddm_directions-panel-listing container'></div></div>");

							})
						}
					});

					jQuery("body").on("click", ".pwddm_driver_box .pwddm_handle", function(){
						var pwddm_driver_box = jQuery(this).parent();
						if ( pwddm_driver_box.hasClass("open") )  {
							pwddm_driver_box.removeClass("open");
						} else {
							pwddm_driver_box.addClass("open");
						}
						//setInterval(function(){drivers_tracking()}, 30000);
						 return false;
					});

					jQuery("body").on("click", ".pwddm_driver_box .pwddm_button", function(){
						var pwddm_driver_box = jQuery(this).parent();
						if ( pwddm_driver_box.hasClass("active") )  {
							pwddm_driver_box.removeClass("active");
						} else {
							pwddm_driver_box.addClass("active");
						}
						pwddm_initMap();
						return false;
					});

					}
				}

				function pwddm_computeTotalDistance(pwddm_driverid,result) {
					var pwddm_totalDist = 0;
					var pwddm_totalTime = 0;
					var pwddm_distance_text = '';
					var pwddm_distance_array = '';
					var pwddm_distance_type = '';

					var pwddm_myroute = result.routes[0];
					for (i = 0; i < pwddm_myroute.legs.length; i++) {
						pwddm_totalTime += pwddm_myroute.legs[i].duration.value;
						pwddm_distance_text = pwddm_myroute.legs[i].distance.text;
						pwddm_distance_array = pwddm_distance_text.split(" ");
						pwddm_totalDist += parseFloat(pwddm_distance_array[0]);
						pwddm_distance_type = pwddm_distance_array[1];
					}
					pwddm_totalTime = (pwddm_totalTime / 60).toFixed(0);
					pwddm_TotalTimeText = pwddm_timeConvert(pwddm_totalTime);

					jQuery("#driver_" + pwddm_driverid ).find(".pwddm_total_route").html( "<b>" + pwddm_TotalTimeText + "</b> <span>(" + (pwddm_totalDist).toFixed(1) + " " + pwddm_distance_type + ")</span> " );
				}
				function pwddm_timeConvert(n) {
					var pwddm_num = n;
					var pwddm_hours = (pwddm_num / 60);
					var pwddm_rhours = Math.floor(pwddm_hours);
					var pwddm_minutes = (pwddm_hours - pwddm_rhours) * 60;
					var pwddm_rminutes = Math.round(pwddm_minutes);
					var pwddm_result = '';
					if (pwddm_rhours > 1) {
						pwddm_result = pwddm_rhours + " " + pwddm_hours_text + " ";
					}
					if (pwddm_rhours == 1) {
						pwddm_result = pwddm_rhours + " " + pwddm_hour_text + " ";
					}
					if (pwddm_rminutes > 0) {
						pwddm_result += pwddm_rminutes + " " + pwddm_mins_text;
					}
					return pwddm_result;
				}

				function pwddm_numtoletter(pwddm_num) {
						var pwddm_s = '',
							pwddm_t;

						while (pwddm_num > 0) {
							pwddm_t = (pwddm_num - 1) % 26;
							pwddm_s = String.fromCharCode(65 + pwddm_t) + pwddm_s;
							pwddm_num = (pwddm_num - pwddm_t) / 26 | 0;
						}
						return pwddm_s || undefined;
					}
				function pwddm_initMap() {
				
				if( typeof pwddm_json['data'] != 'undefined' ){

				//Create map
				var rendererOptions = {
					draggable: false,
					suppressMarkers: true,
				};
				var pwddm_directionsService = new google.maps.DirectionsService();
				var pwddm_directionsRenderer = new google.maps.DirectionsRenderer(rendererOptions);
				var pwddm_map = new google.maps.Map(
					document.getElementById('pwddm_map123'), {
						zoom: 6,
						center: { lat: 41.85, lng: -87.65 }
					}
				);
				pwddm_directionsRenderer.setMap(pwddm_map);

				var infowindow = new google.maps.InfoWindow();
					//Set route
					jQuery.each(pwddm_json['data'], function(i, data) {
						
						if(data['route'] != "") {
							jQuery.each(data['route'], function(i, route) {

								var pwddm_origin 		= route['origin'];
								var pwddm_destination 	= route['destination'];
								var pwddm_waypts_array  = [] ;
								var pwddm_color 		= route['driver'][0]['color'];
								var pwddm_driverid 		= route['driver'][0]['id'];
								var pwddm_drivername 	= route['driver'][0]['name'];

								jQuery.each(route['waypoints'], function(i, waypoints) {
									if ( i + 1 < route['waypoints'].length )
									{
										pwddm_waypts_array.push( waypoints["address"] );
									}
									else
									{
										pwddm_destination = waypoints["address"];
									}
								});

								 if ( jQuery( "#driver_" + pwddm_driverid ).hasClass("active") ) {

									// Add drivers icon
									var icon = {
										path: "M499.99 176h-59.87l-16.64-41.6C406.38 91.63 365.57 64 319.5 64h-127c-46.06 0-86.88 27.63-103.99 70.4L71.87 176H12.01C4.2 176-1.53 183.34.37 190.91l6 24C7.7 220.25 12.5 224 18.01 224h20.07C24.65 235.73 16 252.78 16 272v48c0 16.12 6.16 30.67 16 41.93V416c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32v-32h256v32c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32v-54.07c9.84-11.25 16-25.8 16-41.93v-48c0-19.22-8.65-36.27-22.07-48H494c5.51 0 10.31-3.75 11.64-9.09l6-24c1.89-7.57-3.84-14.91-11.65-14.91zm-352.06-17.83c7.29-18.22 24.94-30.17 44.57-30.17h127c19.63 0 37.28 11.95 44.57 30.17L384 208H128l19.93-49.83zM96 319.8c-19.2 0-32-12.76-32-31.9S76.8 256 96 256s48 28.71 48 47.85-28.8 15.95-48 15.95zm320 0c-19.2 0-48 3.19-48-15.95S396.8 256 416 256s32 12.76 32 31.9-12.8 31.9-32 31.9z",
										fillColor: pwddm_color,
										fillOpacity: 1,
										anchor: new google.maps.Point(0,0),
										scale: 0.04
									}
									driverMarker[pwddm_driverid] = new google.maps.Marker({
									map: pwddm_map,
									icon : icon
									});

									// Click on the driver icon
									google.maps.event.addListener(driverMarker[pwddm_driverid], 'click', function () {
										infowindow.setContent(pwddm_drivername);
										infowindow.open(pwddm_map, driverMarker[pwddm_driverid]);
										pwddm_map.setZoom(16);
										pwddm_map.panTo(driverMarker[pwddm_driverid].position);
									});
									
									pwddm_calculateAndDisplayRoute(pwddm_driverid,pwddm_color,pwddm_map,pwddm_directionsService,pwddm_destination,pwddm_origin,pwddm_waypts_array);
								 }
							});
						}
					});

					/*
						//Click on driver name and image
						jQuery("body").on("click",".pwddm_driver_box .pwddm_driver_name, .pwddm_driver_box img",function(){
								var pwddm_driver_id = jQuery(this).parent().attr("data");
								if (  driverMarker[pwddm_driver_id] ){
									new google.maps.event.trigger( driverMarker[pwddm_driver_id], 'click' );
								}
							return false;
							});
					*/
				}
			}

				function pwddm_calculateAndDisplayRoute(pwddm_driverid,color,pwddm_map,directionsService , pwddm_destination_address,pwddm_google_api_origin,pwddm_waypts_array) {
					var pwddm_waypts = [];
					
					pwddm_waypts_array.forEach(function (item, index) {
						
						pwddm_waypts.push({
							location: item,
							stopover: true
						});
					});
					 
					setdirectionsService(pwddm_driverid,color,pwddm_map,directionsService,pwddm_waypts,pwddm_destination_address,pwddm_google_api_origin);
				}

				function drivers_tracking(){
					jQuery.ajax({
							type: "POST",
							url: pwddm_ajax_url,
							dataType: "json",
							data: {
								action: 'pwddm_ajax',
								pwddm_service: 'pwddm_drivers_locations',
								pwddm_wpnonce: pwddm_nonce,
								pwddm_data_type: 'json'
							},
							success: function(data) {

								jQuery.each( data, function( key, val ) {
									var driver_id = val.driver;
									latv = parseFloat(val.lat);
									lonv = parseFloat(val.long);
									var latlng = new google.maps.LatLng(latv,lonv);
									if ( driverMarker[driver_id] )  {
										driverMarker[driver_id].setPosition(latlng);
									}
								});
							},
							error: function(request, status, error) {}
						})
				}

				function setdirectionsService(pwddm_driverid,color,pwddm_map,directionsService,pwddm_waypts,pwddm_destination_address,pwddm_google_api_origin){
					 
					directionsService.route({
						origin: pwddm_google_api_origin,
						destination: pwddm_destination_address,
						waypoints: pwddm_waypts,
						optimizeWaypoints: false,
						travelMode: 'DRIVING'
					},
					function(response, status) {
						if (status === 'OK') {

							var directionsRenderer = new google.maps.DirectionsRenderer(
							{ 	polylineOptions: { strokeColor: color, strokeWeight: 6 } }
							);
							directionsRenderer.setMap(pwddm_map);
							directionsRenderer.setDirections(response);
							var pwddm_route = response.routes[0];
							var pwddm_summaryPanel = jQuery( "#driver_" + pwddm_driverid ).find( ".pwddm_directions-panel-listing" );
							pwddm_summaryPanel.html('<div class="pwddm_total_route"></div>') ;
							var pwddm_last_address = '';
							// For each route, display summary information.
							for (var i = 0; i < pwddm_route.legs.length; i++) {
								var pwddm_routeSegment = i + 1;
								if (pwddm_last_address != pwddm_route.legs[i].start_address) {
									pwddm_summaryPanel.append('<div class="row pwddm_address"><div class="col-2  col-md-3 text-center" ><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="map-marker" class="svg-inline--fa fa-map-marker fa-w-12" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0z"></path></svg><span class="pwddm_point">' + pwddm_numtoletter(pwddm_routeSegment) + '</span></div><div class="col-10 col-md-9">' + pwddm_route.legs[i].start_address + '</div></div>');
								}
								pwddm_summaryPanel.append( '<div class="row pwddm_drive"><div class="col-2  col-md-3 text-center"><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="ellipsis-v" style="width: 6px;" class="svg-inline--fa fa-ellipsis-v up fa-w-6" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 512"><path fill="currentColor" d="M96 184c39.8 0 72 32.2 72 72s-32.2 72-72 72-72-32.2-72-72 32.2-72 72-72zM24 80c0 39.8 32.2 72 72 72s72-32.2 72-72S135.8 8 96 8 24 40.2 24 80zm0 352c0 39.8 32.2 72 72 72s72-32.2 72-72-32.2-72-72-72-72 32.2-72 72z"></path></svg><br><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="car" class="svg-inline--fa fa-car fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M499.99 176h-59.87l-16.64-41.6C406.38 91.63 365.57 64 319.5 64h-127c-46.06 0-86.88 27.63-103.99 70.4L71.87 176H12.01C4.2 176-1.53 183.34.37 190.91l6 24C7.7 220.25 12.5 224 18.01 224h20.07C24.65 235.73 16 252.78 16 272v48c0 16.12 6.16 30.67 16 41.93V416c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32v-32h256v32c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32v-54.07c9.84-11.25 16-25.8 16-41.93v-48c0-19.22-8.65-36.27-22.07-48H494c5.51 0 10.31-3.75 11.64-9.09l6-24c1.89-7.57-3.84-14.91-11.65-14.91zm-352.06-17.83c7.29-18.22 24.94-30.17 44.57-30.17h127c19.63 0 37.28 11.95 44.57 30.17L384 208H128l19.93-49.83zM96 319.8c-19.2 0-32-12.76-32-31.9S76.8 256 96 256s48 28.71 48 47.85-28.8 15.95-48 15.95zm320 0c-19.2 0-48 3.19-48-15.95S396.8 256 416 256s32 12.76 32 31.9-12.8 31.9-32 31.9z"></path></svg><br><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="ellipsis-v" style="width: 6px;" class="svg-inline--fa down fa-ellipsis-v fa-w-6" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 512"><path fill="currentColor" d="M96 184c39.8 0 72 32.2 72 72s-32.2 72-72 72-72-32.2-72-72 32.2-72 72-72zM24 80c0 39.8 32.2 72 72 72s72-32.2 72-72S135.8 8 96 8 24 40.2 24 80zm0 352c0 39.8 32.2 72 72 72s72-32.2 72-72-32.2-72-72-72-72 32.2-72 72z"></path></svg> </div><div class="col-10 col-md-9 middle"  ><b>' + pwddm_route.legs[i].duration.text + "</b><br>" + pwddm_route.legs[i].distance.text + '</div></div></div>' );
								pwddm_summaryPanel.append( '<div class="row pwddm_address"><div class="col-2  col-md-3 text-center"><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="map-marker" class="svg-inline--fa fa-map-marker fa-w-12" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0z"></path></svg><span class="pwddm_point">' + pwddm_numtoletter((pwddm_routeSegment + 1) * 1) + '</span></div><div class="col-10 col-md-9">' + pwddm_route.legs[i].end_address + '</div></div>' );
								pwddm_last_address = pwddm_route.legs[i].end_address;
							}
							pwddm_computeTotalDistance(pwddm_driverid,response);

						} else {
							var pwddm_summaryPanel = jQuery( "#driver_" + pwddm_driverid ).find( ".pwddm_directions-panel-listing" );
							pwddm_summaryPanel.html('<div class="pwddm_total_route"></div>') ;
							pwddm_summaryPanel.append('Directions request failed due to ' + status);
						}
					}
				);
				}


				function pwddm_screen(){
					//Load routes
					jQuery.when( pwddm_get_routes_json () ).done(function( data ){
					var pwddm_json = data;
					if( typeof pwddm_json['data'] != 'undefined' ){
						jQuery( "#pwddm_routes_notice").hide();
						var head = document.getElementsByTagName('head')[0];
						var script = document.createElement('script');
						script.type = 'text/javascript';
						script.onload = function() {
							 
							//Create drivers
							pwddm_drivers();
							
							//Create map
							pwddm_initMap();

							jQuery( "#pwddm_routes").show();
						}
						script.src = "https://maps.googleapis.com/maps/api/js?v=3&key=<?php echo $pwddm_google_api_key; ?>";
						head.appendChild(script);
						} else
						{
							jQuery( "#pwddm_routes_notice").show();
						}
					});
				}
				pwddm_screen();
				</script>
				<?php

	}
}
