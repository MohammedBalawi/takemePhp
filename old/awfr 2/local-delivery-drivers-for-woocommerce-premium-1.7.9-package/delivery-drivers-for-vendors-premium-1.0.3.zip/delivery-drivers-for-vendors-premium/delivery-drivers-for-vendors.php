<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link    http://www.powerfulwp.com
 * @since   1.0.0
 * @package DDFWM
 *
 * @wordpress-plugin
 * Plugin Name: Delivery Drivers for Vendors Premium
 * Plugin URI:        https://powerfulwp.com/delivery-drivers-for-woocommerce-multi-vendor-marketplace/
 * Description:       Let your vendors manage their drivers<span>, assign drivers to orders, routes, reports, commission, and more!
 * Version:           1.0.3
 * Author:            powerfulwp
 * Author URI:        http://www.powerfulwp.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       ddfwm
 * Domain Path:       /languages
 * @fs_premium_only   /includes/class-ddfwm-route.php
 */
// If this file is called directly, abort.
if ( !defined( 'WPINC' ) ) {
    die;
}
if ( !function_exists( 'ddfwm_fs' ) ) {
    // Create a helper function for easy SDK access.
    function ddfwm_fs()
    {
        global  $ddfwm_fs ;
        
        if ( !isset( $ddfwm_fs ) ) {
            // Include Freemius SDK.
            
            if ( file_exists( dirname( dirname( __FILE__ ) ) . '/local-delivery-drivers-for-woocommerce/freemius/start.php' ) ) {
                // Try to load SDK from parent plugin folder.
                require_once dirname( dirname( __FILE__ ) ) . '/local-delivery-drivers-for-woocommerce/freemius/start.php';
            } else {
                
                if ( file_exists( dirname( dirname( __FILE__ ) ) . '/local-delivery-drivers-for-woocommerce-premium/freemius/start.php' ) ) {
                    // Try to load SDK from premium parent plugin folder.
                    require_once dirname( dirname( __FILE__ ) ) . '/local-delivery-drivers-for-woocommerce-premium/freemius/start.php';
                } else {
                    require_once dirname( __FILE__ ) . '/freemius/start.php';
                }
            
            }
            
            $ddfwm_fs = fs_dynamic_init( array(
                'id'             => '8117',
                'slug'           => 'delivery-drivers-for-vendors',
                'type'           => 'plugin',
                'public_key'     => 'pk_eb967f7dffb13569754dd05f9f072',
                'is_premium'     => true,
                'premium_suffix' => 'Premium',
                'has_paid_plans' => true,
                'trial'          => array(
                'days'               => 14,
                'is_require_payment' => true,
            ),
                'parent'         => array(
                'id'         => '6995',
                'slug'       => 'local-delivery-drivers-for-woocommerce',
                'public_key' => 'pk_5ae065da4addc985fe67f63c46a51',
                'name'       => 'Local Delivery Drivers for WooCommerce',
            ),
                'menu'           => array(
                'first-path' => 'admin.php?page=lddfw-settings&tab=ddfwm',
                'support'    => false,
            ),
                'is_live'        => true,
            ) );
        }
        
        return $ddfwm_fs;
    }

}
$ddfwm_plugin_basename = plugin_basename( __FILE__ );
$ddfwm_plugin_basename_array = explode( '/', $ddfwm_plugin_basename );
$ddfwm_plugin_folder = $ddfwm_plugin_basename_array[0];
$ddfwm_vendors_page = get_option( 'ddfwm_vendors_page', '' );

if ( !function_exists( 'ddfwm_activate' ) ) {
    /**
     * Currently plugin version.
     * Start at version 1.0.0 and use SemVer - https://semver.org
     */
    define( 'DDFWM_VERSION', '1.0.3' );
    /**
     * Define delivery driver page id.
     */
    define( 'DDFWM_PAGE_ID', $ddfwm_vendors_page );
    /**
     * Define plugin folder name.
     */
    define( 'DDFWM_FOLDER', $ddfwm_plugin_folder );
    /**
     * The code that runs during plugin activation.
     * This action is documented in includes/class-ddfwm-activator.php
     */
    function ddfwm_activate()
    {
        include_once plugin_dir_path( __FILE__ ) . 'includes/class-ddfwm-activator.php';
        DDFWM_Activator::activate();
    }
    
    /**
     * Get order custom fields.
     *
     * @since 1.1.2
     * @param int   $orderid order id.
     * @param array $posts custom fields array.
     * @return html
     */
    function ddfwm_order_custom_fields__premium_only( $orderid, $posts )
    {
        $html = '';
        $counter = 0;
        foreach ( $posts as $post ) {
            $meta = get_post_meta( $post->ID, '', true );
            $meta = array_map( function ( $n ) {
                return $n[0];
            }, $meta );
            if ( 0 < $counter && '' !== $html ) {
                $html .= '<br>';
            }
            $field_value = '';
            foreach ( $meta as $key => $value ) {
                $value = preg_replace( '/\\s+/', ' ', $value );
                
                if ( '_' !== substr( $key, 0, 1 ) ) {
                    $post_meta = get_post_meta( $orderid, $key, true );
                    if ( '' !== $post_meta ) {
                        
                        if ( '' !== $value ) {
                            $field_value .= $value . $post_meta . ' ';
                        } else {
                            $field_value .= $post_meta . ' ';
                        }
                    
                    }
                }
            
            }
            if ( '' !== $field_value ) {
                $html .= $post->post_title . ': ' . $field_value;
            }
            $counter++;
        }
        return $html;
    }
    
    /**
     * The code that runs during plugin deactivation.
     * This action is documented in includes/class-ddfwm-deactivator.php
     */
    function ddfwm_deactivate()
    {
        include_once plugin_dir_path( __FILE__ ) . 'includes/class-ddfwm-deactivator.php';
        DDFWM_Deactivator::deactivate();
    }
    
    /**
     * Begins execution of the plugin.
     *
     * Since everything within the plugin is registered via hooks,
     * then kicking off the plugin from this point in the file does
     * not affect the page life cycle.
     *
     * @since 1.0.0
     */
    function ddfwm_run()
    {
        $ddfwm_multivendor = '';
        if ( is_plugin_active( 'wc-frontend-manager/wc_frontend_manager.php' ) ) {
            // WCFM.
            $ddfwm_multivendor = 'wcfm';
        }
        if ( is_plugin_active( 'dc-woocommerce-multi-vendor/dc_product_vendor.php' ) ) {
            // WC Marketplace.
            $ddfwm_multivendor = 'wcmp';
        }
        if ( is_plugin_active( 'dokan-lite/dokan.php' ) ) {
            // Dokan.
            $ddfwm_multivendor = 'dokan';
        }
        if ( !defined( 'DDFWM_MULTIVENDOR' ) ) {
            define( 'DDFWM_MULTIVENDOR', $ddfwm_multivendor );
        }
        $plugin = new DDFWM();
        $plugin->run();
    }
    
    /**
     * Check for free version
     *
     * @since 1.0.0
     * @return boolean
     */
    function ddfwm_is_free()
    {
        
        if ( ddfwm_fs()->is__premium_only() && ddfwm_fs()->can_use_premium_code() ) {
            return false;
        } else {
            return true;
        }
    
    }
    
    /**
     * Premium feature notice.
     *
     * @since 1.0.0
     * @param string $button text.
     * @param string $html html.
     * @param string $class class.
     * @return html
     */
    function ddfwm_premium_feature_notice( $button, $html, $class )
    {
        return '<div class="lddfw_premium-feature ' . esc_attr( $class ) . '">
			<button class="btn btn-secondary btn-sm">' . ddfwm_premium_feature( '' ) . ' ' . $button . '</button>
			<div class="lddfw_lightbox" style="display:none">
				<div class="lddfw_lightbox_wrap">
					<div class="container">
						<a href="#" class="lddfw_lightbox_close">×</a>' . ddfwm_premium_feature_notice_content( $html ) . '
					</div>
				</div>
			</div>
		</div>';
    }
    
    /**
     * Premium feature.
     *
     * @since 1.0.0
     * @param string $value text.
     * @return html
     */
    function ddfwm_premium_feature( $value )
    {
        $result = $value;
        if ( ddfwm_is_free() ) {
            $result = '<svg style="color:#ffc106" width=20 aria-hidden="true" focusable="false" data-prefix="fas" data-icon="star" class=" lddfw_premium_icon svg-inline--fa fa-star fa-w-18" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"> <title>' . esc_attr( 'Premium Feature', 'lddfw' ) . '</title><path fill="currentColor" d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path></svg>';
        }
        return $result;
    }
    
    /**
     * Premium feature notice content.
     *
     * @since 1.0.0
     * @param string $html html.
     * @return html
     */
    function ddfwm_premium_feature_notice_content( $html )
    {
        return '<div class="lddfw_premium-feature-content"><div class="lddfw_title premium_feature_title">
		<h2>' . esc_html( __( 'Premium Feature', 'lddfw' ) ) . '</h2>
		<p>' . esc_html( __( 'You Discovered a Premium Feature!', 'lddfw' ) ) . '</p>
		</div>
		<p class="lddfw_content-subtitle">' . esc_html( __( 'With premium version you will be able to:', 'lddfw' ) ) . '</p>
		' . $html . '</div>';
    }
    
    /**
     * Get delivery driver page url.
     *
     * @param  mixed $params .
     * @since 1.0.0
     */
    function ddfwm_vendors_page_url( $params )
    {
        $link = get_page_link( DDFWM_PAGE_ID );
        
        if ( '' !== $params ) {
            
            if ( strpos( $link, '?' ) !== false ) {
                $link = esc_url( $link ) . '&' . $params;
            } else {
                $link = esc_url( $link ) . '?' . $params;
            }
            
            $link .= '&rnd=' . rand();
        }
        
        return $link;
    }
    
    /**
     * Register_query_vars for delivery driver page.
     *
     * @since 1.0.0
     * @param array $vars query_vars array.
     * @return array
     */
    function ddfwm_register_query_vars( $vars )
    {
        $vars[] = 'ddfwm_screen';
        $vars[] = 'ddfwm_orderid';
        $vars[] = 'ddfwm_page';
        $vars[] = 'ddfwm_dates';
        $vars[] = 'ddfwm_reset_login';
        $vars[] = 'ddfwm_reset_key';
        $vars[] = 'ddfwm_driverid';
        $vars[] = 'ddfwm_status';
        return $vars;
    }
    
    /**
     * Function that return vendor role.
     *
     * @since 1.0.0
     * @return statement
     */
    function ddfwm_vendor_role()
    {
        $vendor = new DDFWM_Vendor();
        $vendors_role = $vendor->ddfwm_vendor_role( DDFWM_MULTIVENDOR );
        return ( '' !== $vendors_role ? $vendors_role : '' );
    }
    
    /**
     * Vendor_order_meta.
     *
     * @return string
     */
    function ddfwm_vendor_order_meta()
    {
        return '_dokan_vendor_id';
    }
    
    /**
     * Order_seller_query
     *
     * @param  mixed $join .
     * @return string
     */
    function ddfwm_order_seller_query( $join )
    {
        global  $wpdb, $ddfwm_vendor_id ;
        switch ( DDFWM_MULTIVENDOR ) {
            case 'dokan':
                return $wpdb->prepare( $join . ' ' . $wpdb->prefix . 'postmeta sellers on p.id=sellers.post_id and sellers.meta_key = \'_dokan_vendor_id\' and sellers.meta_value = %s ', $ddfwm_vendor_id );
                break;
            case 'wcmp':
                return $wpdb->prepare( $join . ' ' . $wpdb->prefix . 'postmeta sellers on p.id=sellers.post_id and sellers.meta_key = \'_vendor_id\' and sellers.meta_value = %s ', $ddfwm_vendor_id );
                break;
            case 'wcfm':
                return $wpdb->prepare( $join . ' ' . $wpdb->prefix . 'wcfm_marketplace_orders sellers on p.id=sellers.order_id and sellers.vendor_id= %s ', $ddfwm_vendor_id );
                break;
            default:
                return '';
                break;
        }
    }
    
    /**
     * Add image to media.
     *
     * @param  mixed $image image.
     * @param  mixed $type type.
     * @return statement
     */
    function ddfwm_add_image_to_media( $image, $type )
    {
        $pos = strpos( $image, ';' );
        $mime = explode( ':', substr( $image, 0, $pos ) )[1];
        
        if ( 'image/png' === $mime ) {
            $image = str_replace( 'data:image/png;base64,', '', $image );
            $filename = $type . '.png';
        }
        
        
        if ( 'image/jpeg' === $mime ) {
            $image = str_replace( 'data:image/jpeg;base64,', '', $image );
            $filename = $type . '.jpg';
        }
        
        
        if ( 'image/gif' === $mime ) {
            $image = str_replace( 'data:image/gif;base64,', '', $image );
            $filename = $type . '.gif';
        }
        
        $upload_dir = wp_upload_dir();
        $upload_path = str_replace( '/', DIRECTORY_SEPARATOR, $upload_dir['path'] ) . DIRECTORY_SEPARATOR;
        $image = str_replace( ' ', '+', $image );
        $decoded = base64_decode( $image );
        $hashed_filename = md5( $filename . microtime() ) . '_' . $filename;
        $file_path = $upload_path . $hashed_filename;
        $wp_filetype = wp_check_filetype( $filename, null );
        $image_upload = file_put_contents( $upload_path . $hashed_filename, $decoded );
        // Handle uploaded file.
        if ( !function_exists( 'wp_handle_sideload' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        $file = array();
        $file['error'] = '';
        $file['tmp_name'] = $upload_path . $hashed_filename;
        $file['name'] = $hashed_filename;
        $file['type'] = 'image/png';
        $file['size'] = filesize( $upload_path . $hashed_filename );
        // upload file to server.
        $file_return = wp_handle_sideload( $file, array(
            'test_form' => false,
        ) );
        $filename = $file_return['file'];
        $attachment = array(
            'post_mime_type' => $file_return['type'],
            'post_title'     => preg_replace( '/\\.[^.]+$/', '', basename( $filename ) ),
            'post_content'   => '',
            'post_status'    => 'inherit',
            'guid'           => $upload_dir['url'] . '/' . basename( $filename ),
        );
        foreach ( get_intermediate_image_sizes() as $s ) {
            $sizes[$s] = array(
                'width'  => '',
                'height' => '',
            );
            $sizes[$s]['width'] = get_option( "{$s}_size_w" );
            $sizes[$s]['height'] = get_option( "{$s}_size_h" );
        }
        $sizes = apply_filters( 'intermediate_image_sizes_advanced', $sizes );
        foreach ( $sizes as $size => $size_data ) {
            $resized = image_make_intermediate_size( $filename, $size_data['width'], $size_data['height'] );
            if ( $resized ) {
                $metadata['sizes'][$size] = $resized;
            }
        }
        $attach_id = wp_insert_attachment( $attachment, $filename );
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
        wp_update_attachment_metadata( $attach_id, $attach_data );
        return $attach_id;
    }
    
    /**
     * Function that uninstall the plugin.
     *
     * @since 1.0.0
     * @return void
     */
    function ddfwm_fs_uninstall_cleanup()
    {
    }
    
    /**
     * Fs_init
     *
     * @return void
     */
    function ddfwm_fs_init()
    {
        
        if ( ddfwm_fs_is_parent_active_and_loaded() ) {
            // Init Freemius.
            ddfwm_fs();
            // Signal that the add-on's SDK was initiated.
            do_action( 'ddfwm_fs_loaded' );
            ddfwm_run();
        }
    
    }
    
    /**
     * Fs_is_parent_active_and_loaded
     *
     * @return statement
     */
    function ddfwm_fs_is_parent_active_and_loaded()
    {
        // Check if the parent's init SDK method exists.
        return function_exists( 'lddfw_fs' );
    }
    
    /**
     * Fs_is_parent_active
     *
     * @return statement
     */
    function ddfwm_fs_is_parent_active()
    {
        $active_plugins = get_option( 'active_plugins', array() );
        
        if ( is_multisite() ) {
            $network_active_plugins = get_site_option( 'active_sitewide_plugins', array() );
            $active_plugins = array_merge( $active_plugins, array_keys( $network_active_plugins ) );
        }
        
        foreach ( $active_plugins as $basename ) {
            if ( 0 === strpos( $basename, 'local-delivery-drivers-for-woocommerce/' ) || 0 === strpos( $basename, 'local-delivery-drivers-for-woocommerce-premium/' ) ) {
                return true;
            }
        }
        return false;
    }

}

register_activation_hook( __FILE__, 'ddfwm_activate' );
register_deactivation_hook( __FILE__, 'ddfwm_deactivate' );
/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-ddfwm.php';
add_filter( 'query_vars', 'ddfwm_register_query_vars' );

if ( ddfwm_fs_is_parent_active_and_loaded() ) {
    // If parent already included, init add-on.
    ddfwm_fs_init();
} elseif ( ddfwm_fs_is_parent_active() ) {
    // Init add-on only after the parent is loaded.
    add_action( 'lddfw_fs_loaded', 'ddfwm_fs_init' );
} else {
    // Even though the parent is not activated, execute add-on for activation / uninstall hooks.
    ddfwm_fs_init();
}
