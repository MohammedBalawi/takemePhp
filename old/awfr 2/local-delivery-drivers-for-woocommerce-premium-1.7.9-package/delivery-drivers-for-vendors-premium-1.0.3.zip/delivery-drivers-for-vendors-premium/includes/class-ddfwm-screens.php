<?php
/**
 * Plugin Screens.
 *
 * All the screens functions.
 *
 * @package    DDFWM
 * @subpackage DDFWM/includes
 * @author     powerfulwp <cs@powerfulwp.com>
 */

/**
 * Plugin Screens.
 *
 * All the screens functions.
 *
 * @package    DDFWM
 * @subpackage DDFWM/includes
 * @author     powerfulwp <cs@powerfulwp.com>
 */
class DDFWM_Screens {

	/**
	 * Footer.
	 *
	 * @since 1.0.0
	 * @return html
	 */
	public function ddfwm_footer() {
		return "<div id='footer'></div>";
	}

	/**
	 * Header.
	 *
	 * @since 1.0.0
	 * @param string $title page title.
	 * @param string $back_url the url for back.
	 * @return html
	 */
	public function ddfwm_header( $title = null, $back_url = null ) {
		global $ddfwm_vendor_id,  $ddfwm_vendor_drivers;
		$vendor = new DDFWM_Vendor();
		$html   = '
		<div class="container-fluid header-container" >
		<div class="container">
		<div class="row">
			<div class="col-12">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<a class="navbar-brand" href="' . ddfwm_vendors_page_url( 'ddfwm_screen=dashboard' ) . '">' . esc_html( $vendor->ddfwm_store_name( '', $ddfwm_vendor_id ) ) . '</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		  <span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarSupportedContent">
		  <ul class="navbar-nav mr-auto">
			<li class="nav-item active">
			  <a class="nav-link" href="' . ddfwm_vendors_page_url( 'ddfwm_screen=dashboard' ) . '">' . esc_html( __( 'Dashboard', 'ddfwm' ) ) . '</a>
			</li>
			<li class="nav-item">
			  <a class="nav-link" href="' . ddfwm_vendors_page_url( 'ddfwm_screen=reports' ) . '">' . esc_html( __( 'Reports', 'ddfwm' ) ) . '</a>
			</li>

			<li class="nav-item">
			  <a class="nav-link" href="' . ddfwm_vendors_page_url( 'ddfwm_screen=routes' ) . '">' . esc_html( __( 'Routes', 'ddfwm' ) ) . '</a>
			</li>

		  <li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
			  ' . esc_html( __( 'Drivers', 'ddfwm' ) ) . '
			</a>
			<div class="dropdown-menu" aria-labelledby="navbarDropdown">';

			if ( ddfwm_fs()->is__premium_only() ) {
				if ( ddfwm_fs()->is_plan( 'premium', true ) ) {
					if ( '1' === $ddfwm_vendor_drivers || '2' === $ddfwm_vendor_drivers ) {
						$html .= ' <a class="dropdown-item" href="' . ddfwm_vendors_page_url( 'ddfwm_screen=newdriver' ) . '">' . esc_html( __( 'Add new driver', 'ddfwm' ) ) . '</a>';
					}
				}
			}

			$html .= '<a class="dropdown-item" href="' . ddfwm_vendors_page_url( 'ddfwm_screen=drivers' ) . '">' . esc_html( __( 'All drivers', 'ddfwm' ) ) . '</a>
			</div>
		  </li>

		  <li class="nav-item dropdown">
		  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
			' . esc_html( __( 'Orders', 'ddfwm' ) ) . '
		  </a>
		  <div class="dropdown-menu" aria-labelledby="navbarDropdown">
			<a class="dropdown-item" href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders' ) . '">' . esc_html( __( 'All orders', 'ddfwm' ) ) . '</a>
		  </div>
		</li>
		 <li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
			  ' . esc_html( __( 'Account', 'ddfwm' ) ) . '
			</a>
			<div class="dropdown-menu" aria-labelledby="navbarDropdown">';
		if ( lddfw_fs()->is__premium_only() ) {
			if ( lddfw_fs()->can_use_premium_code() ) {
					$html .= '<a class="dropdown-item" href="' . ddfwm_vendors_page_url( 'ddfwm_screen=settings' ) . '">' . esc_html( __( 'Settings', 'ddfwm' ) ) . '</a>
						<div class="dropdown-divider"></div>';
			}
		}
			$html .= '<a class="dropdown-item" href="' . ddfwm_vendors_page_url( 'ddfwm_screen=logout' ) . '">' . esc_html( __( 'Log out', 'ddfwm' ) ) . '</a>
			</div>
		  </li>
		  </ul>
		</div>
	  </nav>
	  </div>
		</div>
	 </div>
	 </div>
	 <div class="container">
		<div class="row">
			<div class="col-12">
				<h1>' . esc_html( $title ) . '</h1>
			</div>
		</div>
	 </div>
	  ';
		return $html;
	}

	/**
	 * Homepage.
	 *
	 * @since 1.0.0
	 * @return html
	 */
	public function ddfwm_home() {
		// show vendor homepage.
		global $ddfwm_screen, $ddfwm_reset_key, $ddfwm_reset_login;

		$style_home = '';
		if ( 'resetpassword' === $ddfwm_screen ) {
			$style_home = 'style="display:none"';
		}

		// home page.
		$html = '<div class="ddfwm_wpage" id="ddfwm_home" ' . $style_home . '>
		<div class="container-fluid ddfwm_cover"><span class="ddfwm_helper"></span>';

		$title    = esc_html( __( 'WELCOME', 'ddfwm' ) );
		$subtitle = esc_html( __( 'To the vendor delivery drivers manager', 'ddfwm' ) );
		$logo     = '<img class="ddfwm_header_image" src="' . esc_url( plugins_url() . '/' . DDFWM_FOLDER . '/public/images/ddfwm.png?ver=' . DDFWM_VERSION ) . '">';

		$html .= $logo;
		$html .= '</div>
		<div class="container">
			<h1>' . $title . '</h1>
			<p>' . $subtitle . '</p>
			<div class="d-grid gap-2 col-12 col-md-6 mx-auto">
			<button id="ddfwm_start" class="btn btn-primary btn-lg btn-block" type="button">' . esc_html( __( 'Get started', 'ddfwm' ) ) . '</button>
			</div>
		</div>
	</div>
	';

		$login = new DDFWM_Login();
		$html .= $login->ddfwm_login_screen();

		$password = new DDFWM_Password();
		$html    .= $password->ddfwm_forgot_password_screen();
		$html    .= $password->ddfwm_forgot_password_email_sent_screen();
		$html    .= $password->ddfwm_create_password_screen();
		$html    .= $password->ddfwm_new_password_created_screen();

		return $html;
	}


	/**
	 * New driver screen.
	 *
	 * @since 1.0.0
	 * @param int $vendor_id vendor user id.
	 * @return html
	 */
	public function ddfwm_new_driver_screen( $vendor_id ) {
		$title  = esc_html( __( 'New Driver', 'ddfwm' ) );
		$html   = $this->ddfwm_header( $title );
		$driver = new DDFWM_Driver();
		$html  .= $driver->ddfwm_new_driver_form();
		$html  .= $this->ddfwm_footer();
		return $html;
	}

	/**
	 * Edit driver screen.
	 *
	 * @since 1.0.0
	 * @param int $vendor_id vendor user id.
	 * @param int $driver_id driver user id.
	 * @return html
	 */
	public function ddfwm_driver_screen( $vendor_id, $driver_id ) {
		$user_meta = get_userdata( $driver_id );
		$title     = esc_html( $user_meta->first_name . ' ' . $user_meta->last_name, 'ddfwm' );
		$html      = $this->ddfwm_header( $title );
		$driver    = new DDFWM_Driver();
		$html     .= $driver->ddfwm_edit_driver_form( $user_meta );
		$html     .= $this->ddfwm_footer();
		return $html;
	}

	/**
	 * All drivers screen.
	 *
	 * @since 1.0.0
	 * @param int $vendor_id vendor user id.
	 * @return html
	 */
	public function ddfwm_drivers_screen( $vendor_id ) {
		$title  = esc_html( __( 'Drivers', 'ddfwm' ) );
		$html   = $this->ddfwm_header( $title );
		$driver = new DDFWM_Driver();
		$html  .= $driver->ddfwm_drivers( $vendor_id );
		$html  .= $this->ddfwm_footer();
		return $html;
	}



	/**
	 * Dashboard screen.
	 *
	 * @since 1.0.0
	 * @param int $driver_id driver user id.
	 * @return html
	 */
	public function ddfwm_dashboard_screen( $driver_id ) {
		$title   = __( 'Dashboard', 'ddfwm' );
		$html    = $this->ddfwm_header( $title );
		$reports = new DDFWM_Reports();
		$html   .= $reports->screen_dashboard();
		$html   .= $this->ddfwm_footer();
		return $html;
	}

	/**
	 * Reports screen.
	 *
	 * @since 1.0.0
	 * @param int $driver_id driver user id.
	 * @return html
	 */
	public function ddfwm_reports_screen( $driver_id ) {
		$title   = __( 'Reports', 'ddfwm' );
		$html    = $this->ddfwm_header( $title );
		$reports = new DDFWM_Reports();
		$html   .= $reports->screen_reports();
		$html   .= $this->ddfwm_footer();
		return $html;
	}

	/**
	 * Drivers routes.
	 *
	 * @since 1.0.0
	 * @param int $driver_id driver user id.
	 */
	public function ddfwm_routes_screen( $driver_id ) {
		$title = __( 'Drivers routes', 'ddfwm' );
		echo $this->ddfwm_header( $title ) ;


		if ( ddfwm_is_free() ) {
			$content = ddfwm_premium_feature( '' ) . ' ' . esc_html( __( 'View drivers\' routes on a map.', 'ddfwm' ) ) . '<br>
					 <p>' . ddfwm_premium_feature( '' ) . ' ' . esc_html( __( 'View routes\' duration and distance.', 'ddfwm' ) ) . '</p>
					<p>
					<img style="max-width:100%" src="' . esc_url( plugins_url() . '/' . DDFWM_FOLDER . '/public/images/routes-preview.png?ver=' . DDFWM_FOLDER ) . '"></p>
					';
			echo '<div class="container">' . ddfwm_premium_feature_notice_content( $content ) . '</div>';
		}

		if ( ddfwm_fs()->is__premium_only() ) {
			if ( ddfwm_fs()->can_use_premium_code() ) {
				 $route = new DDFWM_route();
				 $route->ddfwm_routes_screen__premium_only();
			}
		}

		echo $this->ddfwm_footer();

	}

	/**
	 * Vendor settings.
	 *
	 * @since 1.0.0
	 * @param int $seller_id seller user id.
	 * @return html
	 */
	public function ddfwm_settings_screen( $seller_id ) {
		$title  = __( 'Settings', 'ddfwm' );
		$html   = $this->ddfwm_header( $title );
		$vendor = new DDFWM_Vendor();
		$html  .= $vendor->ddfwm_settings_form( $seller_id );
		$html  .= $this->ddfwm_footer();
		return $html;
	}









	/**
	 * Orders screen.
	 *
	 * @since 1.0.0
	 * @param int $vendor_id vendor user id.
	 * @return html
	 */
	public function ddfwm_orders_screen( $vendor_id ) {
		$title    = __( 'Orders', 'ddfwm' );
		$back_url = ddfwm_vendors_page_url( 'ddfwm_screen=dashboard' );
		$html     = $this->ddfwm_header( $title, $back_url );
		$html    .= '<div id="ddfwm_content" class="container">';
		$orders   = new DDFWM_Orders();
		$html    .= $orders->ddfwm_orders_page( $vendor_id );
		$html    .= ' </div>';
		$html    .= $this->ddfwm_footer();
		return $html;
	}

	/**
	 * Order screen.
	 *
	 * @since 1.0.0
	 * @param int $vendor_id vendor user id.
	 * @return html
	 */
	public function ddfwm_order_screen( $vendor_id ) {
		global $ddfwm_order_id;
		$order_class    = new DDFWM_Order();
		$order          = wc_get_order( $ddfwm_order_id );
		$vendor         = new DDFWM_Vendor();
		$order_vendorid = $vendor->order_seller( $order );

		$title = __( 'Order #', 'ddfwm' ) . ' ' . $ddfwm_order_id;
		$html  = $this->ddfwm_header( $title, '' );

		if ( intval( $order_vendorid ) === intval( $vendor_id ) ) {
			$html .= $order_class->ddfwm_order_page( $order, $vendor_id );
		} else {
			$html .= '<div class="alert alert-danger">' . esc_html( __( 'Access Denied, You do not have permissions to access this order', 'ddfwm' ) ) . '</div>';
		}
		$html .= $this->ddfwm_footer();
		return $html;
	}
}
