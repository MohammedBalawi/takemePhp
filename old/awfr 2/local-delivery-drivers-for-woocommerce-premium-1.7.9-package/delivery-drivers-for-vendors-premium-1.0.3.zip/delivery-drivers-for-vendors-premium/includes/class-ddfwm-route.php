<?php
/**
 * Route page.
 *
 * All the route functions.
 *
 * @package    DDFWM
 * @subpackage DDFWM/includes
 * @author     powerfulwp <cs@powerfulwp.com>
 */

/**
 * Route page.
 *
 * All the route functions.
 *
 * @package    DDFWM
 * @subpackage DDFWM/includes
 * @author     powerfulwp <cs@powerfulwp.com>
 */
class DDFWM_Route {

	/**
	 * Google_api_key variable.
	 *
	 * @var string
	 */
	private $ddfwm_google_api_key;

	/**
	 * Initialize the class.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->ddfwm_google_api_key = get_option( 'ddfwm_google_api_key', '' );
	}

	/**
	 * Route alerts
	 *
	 * @return html
	 */
	public function ddfwm_route_alerts__premium_only() {
		$html = '';
		if ( '' !== $this->ddfwm_google_api_key ) {
			$plain_route_note_info = __( 'The route has been optimized by distance, if you want to make changes you can drag and drop orders manually.' );
			$plain_route_note_wait = __( 'Optimize route, please wait...' );
		} else {
			$plain_route_note_info = __( 'The route is ready for optimization, you can make changes by drag and drop orders manually.' );
			$plain_route_note_wait = __( 'Please wait...' );
		}

		$html .= '
			<div class="ddfwm_plain_route_wrap">
					<div class="row" id="ddfwm_plain_route_row">
					<div class="col-12"><a id="ddfwm_plainroute_btn" data_start =\'<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="edit" class="svg-inline--fa fa-edit fa-w-18" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="currentColor" d="M402.6 83.2l90.2 90.2c3.8 3.8 3.8 10 0 13.8L274.4 405.6l-92.8 10.3c-12.4 1.4-22.9-9.1-21.5-21.5l10.3-92.8L388.8 83.2c3.8-3.8 10-3.8 13.8 0zm162-22.9l-48.8-48.8c-15.2-15.2-39.9-15.2-55.2 0l-35.4 35.4c-3.8 3.8-3.8 10 0 13.8l90.2 90.2c3.8 3.8 10 3.8 13.8 0l35.4-35.4c15.2-15.3 15.2-40 0-55.2zM384 346.2V448H64V128h229.8c3.2 0 6.2-1.3 8.5-3.5l40-40c7.6-7.6 2.2-20.5-8.5-20.5H48C21.5 64 0 85.5 0 112v352c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V306.2c0-10.7-12.9-16-20.5-8.5l-40 40c-2.2 2.3-3.5 5.3-3.5 8.5z"></path></svg> ' . esc_attr( __( 'Plan your route', 'ddfwm' ) ) . '\' data_finish =\'<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="lock" class="svg-inline--fa fa-lock fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M400 224h-24v-72C376 68.2 307.8 0 224 0S72 68.2 72 152v72H48c-26.5 0-48 21.5-48 48v192c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V272c0-26.5-21.5-48-48-48zm-104 0H152v-72c0-39.7 32.3-72 72-72s72 32.3 72 72v72z"></path></svg> ' . esc_attr( __( 'Finish planning route', 'ddfwm' ) ) . '\' class=" btn btn-secondary  btn-block" href="#">
					<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="edit" class="svg-inline--fa fa-edit fa-w-18" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="currentColor" d="M402.6 83.2l90.2 90.2c3.8 3.8 3.8 10 0 13.8L274.4 405.6l-92.8 10.3c-12.4 1.4-22.9-9.1-21.5-21.5l10.3-92.8L388.8 83.2c3.8-3.8 10-3.8 13.8 0zm162-22.9l-48.8-48.8c-15.2-15.2-39.9-15.2-55.2 0l-35.4 35.4c-3.8 3.8-3.8 10 0 13.8l90.2 90.2c3.8 3.8 10 3.8 13.8 0l35.4-35.4c15.2-15.3 15.2-40 0-55.2zM384 346.2V448H64V128h229.8c3.2 0 6.2-1.3 8.5-3.5l40-40c7.6-7.6 2.2-20.5-8.5-20.5H48C21.5 64 0 85.5 0 112v352c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V306.2c0-10.7-12.9-16-20.5-8.5l-40 40c-2.2 2.3-3.5 5.3-3.5 8.5z"></path></svg> ' . esc_html( __( 'Plan your route', 'ddfwm' ) ) . '</a></div>
					</div>
					<div id="ddfwm_plain_route_note_wait" style="display:none;margin-top:17px">
						<div class="alert alert-primary">' . $plain_route_note_wait . '</div>
					</div>
					<div id="ddfwm_plain_route_note_info" style="display:none;margin-top:17px">
						<div class="alert alert-primary" id="ddfwm_plain_route_note_alert">' . $plain_route_note_info . ' <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></div>
					</div>
			</div>';
		return $html;
	}

	/**
	 * All Routes query.
	 *
	 * @param  mixed $ddfwm_vendor_id .
	 * @since 1.4.0
	 * @return object
	 */
	public function ddfwm_all_routes_query__premium_only( $ddfwm_vendor_id ) {

		$array = array(
			'driver_clause' => array(
				'key'     => 'lddfw_driverid',
				'compare' => 'EXISTS',
			),
		);

		$params = array(
			'posts_per_page' => -1,
			'post_status'    => get_option( 'lddfw_out_for_delivery_status', '' ),
			'post_type'      => 'shop_order',
			'meta_query'     => array(
				array(
					'relation' => 'or',
					array(
						'city_clause' => array(
							'key'     => '_shipping_city',
							'compare' => 'NOT EXISTS',
						),
					),
					array(
						'city_clause' => array(
							'key'     => '_shipping_city',
							'compare' => 'EXISTS',
						),
					),
					array(
						'sort_clause' => array(
							'key'     => 'lddfw_order_sort',
							'compare' => 'EXISTS',
							'type'    => 'NUMERIC',
						),
					),
					array(
						'sort_clause' => array(
							'key'     => 'lddfw_order_sort',
							'compare' => 'NOT EXISTS',
							'type'    => 'NUMERIC',
						),
					),
				),
				$array,
			),
			'orderby'        => array(
				'driver_clause' => 'ASC',
				'sort_clause'   => 'ASC',
				'city_clause'   => 'ASC',
			),
		);

		return new WP_Query( $params );
	}

	/**
	 * Route query.
	 *
	 * @since 1.0.0
	 * @param int $driver_id driver user id.
	 * @return object
	 */
	public function ddfwm_route_query__premium_only( $driver_id ) {

		$array = array(
			'key'     => 'ddfwm_driverid',
			'value'   => $driver_id,
			'compare' => '=',
		);

		$params = array(
			'posts_per_page' => -1,
			'post_status'    => get_option( 'ddfwm_out_for_delivery_status', '' ),
			'post_type'      => 'shop_order',
			'meta_query'     => array(
				'relation' => 'AND',
				array(
					'relation' => 'or',
					array(
						'city_clause' => array(
							'key'     => '_shipping_city',
							'compare' => 'NOT EXISTS',
						),
					),
					array(
						'city_clause' => array(
							'key'     => '_shipping_city',
							'compare' => 'EXISTS',
						),
					),
					array(
						'sort_clause' => array(
							'key'     => 'ddfwm_order_sort',
							'compare' => 'EXISTS',
							'type'    => 'NUMERIC',
						),
					),
					array(
						'sort_clause' => array(
							'key'     => 'ddfwm_order_sort',
							'compare' => 'NOT EXISTS',
							'type'    => 'NUMERIC',
						),
					),
				),
				$array,
			),
			'orderby'        => array(
				'sort_clause' => 'ASC',
				'city_clause' => 'ASC',
			),
		);

		return new WP_Query( $params );
	}


	/**
	 * Sort delivery.
	 *
	 * @since 1.0.0
	 * @param int $driver_id driver user id.
	 * @return json
	 */
	public function ddfwm_sort_delivery__premium_only( $driver_id ) {
		$result = 0;
		if ( isset( $_POST['ddfwm_wpnonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_POST['ddfwm_wpnonce'] ) );
			if ( ! wp_verify_nonce( $nonce, 'ddfwm-nonce' ) ) {
				$error = __( 'Security Check Failure - This alert may occur when you are logged in as an administrator and as a delivery driver on the same browser and the same device. If you want to work on both panels please try to work with two different browsers.', 'ddfwm' );
			} else {
				$orders_list = ( isset( $_POST['ddfwm_orders_list'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_orders_list'] ) ) : '';
				if ( '' !== $orders_list ) {
					$orders_list_array = explode( ',', $orders_list );
					$counter           = 1;
					foreach ( $orders_list_array  as $order ) {
						if ( '' !== $order ) {
							update_post_meta( $order, 'ddfwm_order_sort', $counter );
							++$counter;
						}
					}
					$result = 1;
				}
			}
		}
		$this->ddfwm_set_delivery_origin__premium_only( $driver_id );
		return $result;
	}

	/**
	 * Set delivery origin.
	 *
	 * @since 1.0.0
	 * @param int $driver_id driver user id.
	 */
	public function ddfwm_set_delivery_origin__premium_only( $driver_id ) {
		$wc_query      = $this->ddfwm_route_query__premium_only( $driver_id );
		$store         = new LDDFW_Store();
		$store_address = $store->lddfw_store_address( 'map_address' );
		$origin        = $store_address;
		while ( $wc_query->have_posts() ) {
			$wc_query->the_post();
			$orderid = get_the_ID();
			$order   = wc_get_order( $orderid );

			$billing_address_1 = $order->get_billing_address_1();
			$billing_address_2 = $order->get_billing_address_2();
			$billing_city      = $order->get_billing_city();
			$billing_state     = $order->get_billing_state();
			$billing_postcode  = $order->get_billing_postcode();
			$billing_country   = $order->get_billing_country();

			$shipping_address_1 = $order->get_shipping_address_1();
			$shipping_address_2 = $order->get_shipping_address_2();
			$shipping_city      = $order->get_shipping_city();
			$shipping_state     = $order->get_shipping_state();
			$shipping_postcode  = $order->get_shipping_postcode();
			$shipping_country   = $order->get_shipping_country();

			if ( '' === $shipping_address_1 ) {
				$shipping_address_1 = $billing_address_1;
				$shipping_address_2 = $billing_address_2;
				$shipping_city      = $billing_city;
				$shipping_state     = $billing_state;
				$shipping_postcode  = $billing_postcode;
				$shipping_country   = $billing_country;
			}

			$shippingaddress = $shipping_address_1;
			if ( '' !== $shipping_address_2 ) {
				$shippingaddress .= ' ' . $shipping_address_2;
			}
			if ( '' !== $shipping_city ) {
				$shippingaddress .= ' ' . $shipping_city;
			}
			if ( '' !== $shipping_state ) {
				$shippingaddress .= ' ' . $shipping_state;
			}
			if ( '' !== $shipping_country ) {
				$shippingaddress .= ' ' . $shipping_country;
			}
			$shippingaddress = str_replace( ' ', '+', $shippingaddress );
			// set delivery origin.
			update_post_meta( $orderid, 'ddfwm_order_origin', $origin );
			$origin = $shippingaddress;
		}
	}

	/**
	 * Route script.
	 *
	 * @since 1.0.0
	 * @return html
	 */
	public function ddfwm_route_script__premium_only() {
		$html = '';
		if ( '' !== $this->ddfwm_google_api_key ) {
			$store         = new LDDFW_Store();
			$store_address = $store->lddfw_store_address( 'map_address' );

			$html .= '
			<script>
				var ddfwm_optimizeWaypoints_flag = false;
				var ddfwm_google_api_key         =  "' . esc_attr( $this->ddfwm_google_api_key ) . '";
				var ddfwm_google_api_origin 	 =  "' . esc_attr( $store_address ) . '";
			</script>
			';
		}
		echo $html;
	}

	/**
	 * Route button.
	 *
	 * @since 1.0.0
	 * @return html
	 */
	public function ddfwm_route_button__premium_only() {
		$html = '';
		if ( '' !== $this->ddfwm_google_api_key ) {
			$html .= '
			<div class="ddfwm_footer_buttons">
				<div class="container">
					<div class="row">
						<div class="col-12"><a href="#" id="ddfwm_route_btn" class="btn btn-lg btn-block btn-success">
						<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="map-marked-alt" class="svg-inline--fa fa-map-marked-alt fa-w-18" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="currentColor" d="M288 0c-69.59 0-126 56.41-126 126 0 56.26 82.35 158.8 113.9 196.02 6.39 7.54 17.82 7.54 24.2 0C331.65 284.8 414 182.26 414 126 414 56.41 357.59 0 288 0zm0 168c-23.2 0-42-18.8-42-42s18.8-42 42-42 42 18.8 42 42-18.8 42-42 42zM20.12 215.95A32.006 32.006 0 0 0 0 245.66v250.32c0 11.32 11.43 19.06 21.94 14.86L160 448V214.92c-8.84-15.98-16.07-31.54-21.25-46.42L20.12 215.95zM288 359.67c-14.07 0-27.38-6.18-36.51-16.96-19.66-23.2-40.57-49.62-59.49-76.72v182l192 64V266c-18.92 27.09-39.82 53.52-59.49 76.72-9.13 10.77-22.44 16.95-36.51 16.95zm266.06-198.51L416 224v288l139.88-55.95A31.996 31.996 0 0 0 576 426.34V176.02c0-11.32-11.43-19.06-21.94-14.86z"></path></svg></i> ' . esc_html( __( 'View Route', 'ddfwm' ) ) . '</a></div>
					</div>
				</div>
			</div>';
		}
		return $html;
	}




	/**
	 * Drivers routes
	 *
	 * @param  mixed $ddfwm_vendor_id .
	 * @since 1.4.0
	 * @return json
	 */
	public function ddfwm_drivers_routes__premium_only( $ddfwm_vendor_id ) {

		$wc_query            = $this->ddfwm_all_routes_query__premium_only( $ddfwm_vendor_id );
		$route_array         = '';
		$store               = new LDDFW_Store();
		$store_address       = $store->lddfw_store_address( 'map_address' );
		$drivers_counter     = 0;
		$last_ddfwm_driverid = 0;

		/**
		 * Random_color_part.
		 *
		 * @return string
		 */
		function ddfwm_random_color_part() {
			return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT );
		}
		/**
		 * Random_color.
		 *
		 * @return string
		 */
		function ddfwm_random_color() {
			return ddfwm_random_color_part() . ddfwm_random_color_part() . ddfwm_random_color_part();
		}

		$drivers_colors = array(
			'#86b8ff',
			'#008000',
			'#800080',
			'#000080',
			'#FF00FF',
			'#cb4b4b',
			'#3377aa',
			'#9440ed',
			'#800000',
			'#bd9b33',
			'#808080',
			'#808000',
		);

		if ( $wc_query->have_posts() ) {
				$route_array = '{ "data": [{"route": [';
			while ( $wc_query->have_posts() ) {

				$wc_query->the_post();
				$orderid = get_the_ID();
				$order   = wc_get_order( $orderid );

				// Shipping address.
				$billing_address_1 = $order->get_billing_address_1();
				$billing_address_2 = $order->get_billing_address_2();
				$billing_city      = $order->get_billing_city();
				$billing_state     = $order->get_billing_state();
				$billing_postcode  = $order->get_billing_postcode();
				$billing_country   = $order->get_billing_country();

				$shipping_address_1 = $order->get_shipping_address_1();
				$shipping_address_2 = $order->get_shipping_address_2();
				$shipping_city      = $order->get_shipping_city();
				$shipping_state     = $order->get_shipping_state();
				$shipping_postcode  = $order->get_shipping_postcode();
				$shipping_country   = $order->get_shipping_country();

				if ( '' === $shipping_address_1 ) {
					$shipping_address_1 = $billing_address_1;
					$shipping_address_2 = $billing_address_2;
					$shipping_city      = $billing_city;
					$shipping_state     = $billing_state;
					$shipping_postcode  = $billing_postcode;
					$shipping_country   = $billing_country;
				}

				$shippingaddress = $shipping_address_1;
				if ( '' !== $shipping_address_2 ) {
					$shippingaddress .= ' ' . $shipping_address_2;
				}
				if ( '' !== $shipping_city ) {
					$shippingaddress .= ', ' . $shipping_city;
				}
				if ( '' !== $shipping_state ) {
					$shippingaddress .= ' ' . $shipping_state;
				}
				if ( '' !== $shipping_country ) {
					$shippingaddress .= ' ' . $shipping_country;
				}
				$shippingaddress = str_replace( ' ', '+', $shippingaddress );

				// route array.
				$ddfwm_driverid = $order->get_meta( 'lddfw_driverid' );

				if ( $last_ddfwm_driverid !== $ddfwm_driverid ) {

					if ( $drivers_counter > 0 ) {
						$route_array  = substr( $route_array, 0, -1 );
						$route_array .= '] ,"destination": "' . esc_attr( $shippingaddress ) . '"},';
					};
					$user              = get_userdata( $ddfwm_driverid );
					$ddfwm_driver_name = $user->display_name;
					$image_id          = get_user_meta( $ddfwm_driverid, 'lddfw_driver_image', true );
					$image             = '';
					if ( intval( $image_id ) > 0 ) {
						$image = wp_get_attachment_image_src( $image_id, 'medium' )[0];
					}
					$origin = get_post_meta( $orderid, 'lddfw_order_origin', true );
					if ( '' === $origin ) {
						$origin = $store_address;
					}

					$driver_color = '#' . ddfwm_random_color();
					if ( $drivers_counter < 12 ) {
						$driver_color = $drivers_colors[ $drivers_counter ];
					}
					$route_array        .= '{"driver": [{"id": "' . $ddfwm_driverid . '","name": "' . esc_attr( $ddfwm_driver_name ) . '","Image": "' . esc_attr( $image ) . '","color": "' . $driver_color . '"}],"origin": "' . esc_attr( $origin ) . '","waypoints": [';
					++$drivers_counter;
					$last_ddfwm_driverid = $ddfwm_driverid;
				}
				$route_array .= '{"order": "' . $orderid . '","address": "' . esc_attr( $shippingaddress ) . '","status": "waiting","color": "#800000"},';
				?>
				<?php

			}

			$route_array  = substr( $route_array, 0, -1 );
			$route_array .= '] ,"destination": "' . esc_attr( $shippingaddress ) . '"}]}]	}';
		} else {
			$route_array = '{}';
		}
		return $route_array;
	}


	/**
	 * Admin routes screen.
	 *
	 * @since 1.4.0
	 * @return void
	 */
	public function ddfwm_routes_screen__premium_only() {
		global $ddfwm_vendor_id;
		echo '<div class="wrap container">';
		echo '<div id="ddfwm_routes_notice" style="display:none">' . esc_html( __( 'There are no routes for drivers.', 'ddfwm' ) ) . '</div>';
		echo '<div id="ddfwm_routes" style="display:none">
				<div class="row">
				<div class="col-12 col-md-8">
				<div id="ddfwm_map123"></div>
				</div>
				<div class="col-12 col-md-4">
				<div id="driver-panel"></div>
				</div>
				</div>
				</div>
			  </div>';
		$ddfwm_google_api_key = get_option( 'lddfw_google_api_key', '' );
		?>

		<script>
			var geocoder;
			var infowindow;
			var driverMarker = [];
			var ddfwm_waypts_array = [];
			var ddfwm_map;
			<?php
			echo '
				var ddfwm_ajax_url = "' . esc_url( admin_url( 'admin-ajax.php' ) ) . '";
				var ddfwm_hour_text = "' . esc_js( __( 'hour', 'ddfwm' ) ) . '";
				var ddfwm_hours_text = "' . esc_js( __( 'hours', 'ddfwm' ) ) . '";
				var ddfwm_mins_text = "' . esc_js( __( 'mins', 'ddfwm' ) ) . '";
				'
			?>
		</script>

		<?php
		$route = new DDFWM_Route();
		$route->ddfwm_route_script__premium_only();

		?>
				<script>
				var ddfwm_json='';
				function ddfwm_get_routes_json()
				{
					return jQuery.ajax({
							type: "POST",
							url: ddfwm_ajax_url,
							dataType: "json",
							 data: {
								action: 'ddfwm_ajax',
								ddfwm_service: 'ddfwm_drivers_routes',
								ddfwm_wpnonce: ddfwm_nonce,
								ddfwm_data_type: 'json',
								ddfwm_vendor_id: '<?php echo esc_attr( $ddfwm_vendor_id ); ?>'
							},
							success:function(data){
								ddfwm_json = data;
							},
							error: function(request, status, error) {
								console.log(error);
							}
						})
				}

				function ddfwm_drivers()
				{
					if( typeof ddfwm_json['data'] != 'undefined' ){
						jQuery.each(ddfwm_json['data'], function(i, data) {
						if(data['route'] != "") {
							jQuery.each(data['route'], function(i, route) {
							   var ddfwm_driver_id   = route['driver'][0]['id'];
							   var ddfwm_driver_name 		= route['driver'][0]['name'];
							   var ddfwm_driver_image		= route['driver'][0]['Image'];
							   var ddfwm_driver_color		= route['driver'][0]['color'];
								var ddfwm_driver_img = '';
							   if ( ddfwm_driver_image != ""){
								ddfwm_driver_img = '<img src="'+ddfwm_driver_image+'">';
							   } else
							   {
								ddfwm_driver_img = '<img src="<?php echo esc_url( plugins_url() . '/' . DDFWM_FOLDER . '/public/images/user.png?ver=' . DDFWM_VERSION ); ?>">';
							   }
							   //style='background-image:url("+ddfwm_driver_image+")'
							   jQuery("#driver-panel").append("<div class='ddfwm_driver_box active' data='"+ddfwm_driver_id+"' id='driver_"+ddfwm_driver_id+"'>" + ddfwm_driver_img + "<div class='ddfwm_driver_name'>" + ddfwm_driver_name+ "</div><div class='ddfwm_button'></div> <div class='ddfwm_handle'></div> <div class='ddfwm_line' style='background-color:"+ddfwm_driver_color+";'></div> <div class='ddfwm_directions-panel-listing container'></div></div>");

							})
						}
					});

					jQuery("body").on("click", ".ddfwm_driver_box .ddfwm_handle", function(){
						var ddfwm_driver_box = jQuery(this).parent();
						if ( ddfwm_driver_box.hasClass("open") )  {
							ddfwm_driver_box.removeClass("open");
						} else {
							ddfwm_driver_box.addClass("open");
						}
						//setInterval(function(){drivers_tracking()}, 30000);
						 return false;
					});

					jQuery("body").on("click", ".ddfwm_driver_box .ddfwm_button", function(){
						var ddfwm_driver_box = jQuery(this).parent();
						if ( ddfwm_driver_box.hasClass("active") )  {
							ddfwm_driver_box.removeClass("active");
						} else {
							ddfwm_driver_box.addClass("active");
						}
						ddfwm_initMap();
						return false;
					});

					}
				}

				function ddfwm_computeTotalDistance(ddfwm_driverid,result) {
					var ddfwm_totalDist = 0;
					var ddfwm_totalTime = 0;
					var ddfwm_distance_text = '';
					var ddfwm_distance_array = '';
					var ddfwm_distance_type = '';

					var ddfwm_myroute = result.routes[0];
					for (i = 0; i < ddfwm_myroute.legs.length; i++) {
						ddfwm_totalTime += ddfwm_myroute.legs[i].duration.value;
						ddfwm_distance_text = ddfwm_myroute.legs[i].distance.text;
						ddfwm_distance_array = ddfwm_distance_text.split(" ");
						ddfwm_totalDist += parseFloat(ddfwm_distance_array[0]);
						ddfwm_distance_type = ddfwm_distance_array[1];
					}
					ddfwm_totalTime = (ddfwm_totalTime / 60).toFixed(0);
					ddfwm_TotalTimeText = ddfwm_timeConvert(ddfwm_totalTime);

					jQuery("#driver_" + ddfwm_driverid ).find(".ddfwm_total_route").html( "<b>" + ddfwm_TotalTimeText + "</b> <span>(" + (ddfwm_totalDist).toFixed(1) + " " + ddfwm_distance_type + ")</span> " );
				}
				function ddfwm_timeConvert(n) {
					var ddfwm_num = n;
					var ddfwm_hours = (ddfwm_num / 60);
					var ddfwm_rhours = Math.floor(ddfwm_hours);
					var ddfwm_minutes = (ddfwm_hours - ddfwm_rhours) * 60;
					var ddfwm_rminutes = Math.round(ddfwm_minutes);
					var ddfwm_result = '';
					if (ddfwm_rhours > 1) {
						ddfwm_result = ddfwm_rhours + " " + ddfwm_hours_text + " ";
					}
					if (ddfwm_rhours == 1) {
						ddfwm_result = ddfwm_rhours + " " + ddfwm_hour_text + " ";
					}
					if (ddfwm_rminutes > 0) {
						ddfwm_result += ddfwm_rminutes + " " + ddfwm_mins_text;
					}
					return ddfwm_result;
				}

				function ddfwm_numtoletter(ddfwm_num) {
						var ddfwm_s = '',
							ddfwm_t;

						while (ddfwm_num > 0) {
							ddfwm_t = (ddfwm_num - 1) % 26;
							ddfwm_s = String.fromCharCode(65 + ddfwm_t) + ddfwm_s;
							ddfwm_num = (ddfwm_num - ddfwm_t) / 26 | 0;
						}
						return ddfwm_s || undefined;
					}
				function ddfwm_initMap() {

				if( typeof ddfwm_json['data'] != 'undefined' ){

				//Create map
				var rendererOptions = {
					draggable: false,
					suppressMarkers: true,
				};
				var ddfwm_directionsService = new google.maps.DirectionsService();
				var ddfwm_directionsRenderer = new google.maps.DirectionsRenderer(rendererOptions);
				var ddfwm_map = new google.maps.Map(
					document.getElementById('ddfwm_map123'), {
						zoom: 6,
						center: { lat: 41.85, lng: -87.65 }
					}
				);
				ddfwm_directionsRenderer.setMap(ddfwm_map);

				var infowindow = new google.maps.InfoWindow();
					//Set route
					jQuery.each(ddfwm_json['data'], function(i, data) {

						if(data['route'] != "") {
							jQuery.each(data['route'], function(i, route) {

								var ddfwm_origin 		= route['origin'];
								var ddfwm_destination 	= route['destination'];
								var ddfwm_waypts_array  = [] ;
								var ddfwm_color 		= route['driver'][0]['color'];
								var ddfwm_driverid 		= route['driver'][0]['id'];
								var ddfwm_drivername 	= route['driver'][0]['name'];

								jQuery.each(route['waypoints'], function(i, waypoints) {
									if ( i + 1 < route['waypoints'].length )
									{
										ddfwm_waypts_array.push( waypoints["address"] );
									}
									else
									{
										ddfwm_destination = waypoints["address"];
									}
								});

								 if ( jQuery( "#driver_" + ddfwm_driverid ).hasClass("active") ) {

									// Add drivers icon
									var icon = {
										path: "M499.99 176h-59.87l-16.64-41.6C406.38 91.63 365.57 64 319.5 64h-127c-46.06 0-86.88 27.63-103.99 70.4L71.87 176H12.01C4.2 176-1.53 183.34.37 190.91l6 24C7.7 220.25 12.5 224 18.01 224h20.07C24.65 235.73 16 252.78 16 272v48c0 16.12 6.16 30.67 16 41.93V416c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32v-32h256v32c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32v-54.07c9.84-11.25 16-25.8 16-41.93v-48c0-19.22-8.65-36.27-22.07-48H494c5.51 0 10.31-3.75 11.64-9.09l6-24c1.89-7.57-3.84-14.91-11.65-14.91zm-352.06-17.83c7.29-18.22 24.94-30.17 44.57-30.17h127c19.63 0 37.28 11.95 44.57 30.17L384 208H128l19.93-49.83zM96 319.8c-19.2 0-32-12.76-32-31.9S76.8 256 96 256s48 28.71 48 47.85-28.8 15.95-48 15.95zm320 0c-19.2 0-48 3.19-48-15.95S396.8 256 416 256s32 12.76 32 31.9-12.8 31.9-32 31.9z",
										fillColor: ddfwm_color,
										fillOpacity: 1,
										anchor: new google.maps.Point(0,0),
										scale: 0.04
									}
									driverMarker[ddfwm_driverid] = new google.maps.Marker({
									map: ddfwm_map,
									icon : icon
									});

									// Click on the driver icon
									google.maps.event.addListener(driverMarker[ddfwm_driverid], 'click', function () {
										infowindow.setContent(ddfwm_drivername);
										infowindow.open(ddfwm_map, driverMarker[ddfwm_driverid]);
										ddfwm_map.setZoom(16);
										ddfwm_map.panTo(driverMarker[ddfwm_driverid].position);
									});

									ddfwm_calculateAndDisplayRoute(ddfwm_driverid,ddfwm_color,ddfwm_map,ddfwm_directionsService,ddfwm_destination,ddfwm_origin,ddfwm_waypts_array);
								 }
							});
						}
					});

					/*
						//Click on driver name and image
						jQuery("body").on("click",".ddfwm_driver_box .ddfwm_driver_name, .ddfwm_driver_box img",function(){
								var ddfwm_driver_id = jQuery(this).parent().attr("data");
								if (  driverMarker[ddfwm_driver_id] ){
									new google.maps.event.trigger( driverMarker[ddfwm_driver_id], 'click' );
								}
							return false;
							});
					*/
				}
			}

				function ddfwm_calculateAndDisplayRoute(ddfwm_driverid,color,ddfwm_map,directionsService , ddfwm_destination_address,ddfwm_google_api_origin,ddfwm_waypts_array) {
					var ddfwm_waypts = [];

					ddfwm_waypts_array.forEach(function (item, index) {

						ddfwm_waypts.push({
							location: item,
							stopover: true
						});
					});

					setdirectionsService(ddfwm_driverid,color,ddfwm_map,directionsService,ddfwm_waypts,ddfwm_destination_address,ddfwm_google_api_origin);
				}

				function drivers_tracking(){
					jQuery.ajax({
							type: "POST",
							url: ddfwm_ajax_url,
							dataType: "json",
							data: {
								action: 'ddfwm_ajax',
								ddfwm_service: 'ddfwm_drivers_locations',
								ddfwm_wpnonce: ddfwm_nonce,
								ddfwm_data_type: 'json'
							},
							success: function(data) {

								jQuery.each( data, function( key, val ) {
									var driver_id = val.driver;
									latv = parseFloat(val.lat);
									lonv = parseFloat(val.long);
									var latlng = new google.maps.LatLng(latv,lonv);
									if ( driverMarker[driver_id] )  {
										driverMarker[driver_id].setPosition(latlng);
									}
								});
							},
							error: function(request, status, error) {}
						})
				}

				function setdirectionsService(ddfwm_driverid,color,ddfwm_map,directionsService,ddfwm_waypts,ddfwm_destination_address,ddfwm_google_api_origin){

					directionsService.route({
						origin: ddfwm_google_api_origin,
						destination: ddfwm_destination_address,
						waypoints: ddfwm_waypts,
						optimizeWaypoints: false,
						travelMode: 'DRIVING'
					},
					function(response, status) {
						if (status === 'OK') {

							var directionsRenderer = new google.maps.DirectionsRenderer(
							{ 	polylineOptions: { strokeColor: color, strokeWeight: 6 } }
							);
							directionsRenderer.setMap(ddfwm_map);
							directionsRenderer.setDirections(response);
							var ddfwm_route = response.routes[0];
							var ddfwm_summaryPanel = jQuery( "#driver_" + ddfwm_driverid ).find( ".ddfwm_directions-panel-listing" );
							ddfwm_summaryPanel.html('<div class="ddfwm_total_route"></div>') ;
							var ddfwm_last_address = '';
							// For each route, display summary information.
							for (var i = 0; i < ddfwm_route.legs.length; i++) {
								var ddfwm_routeSegment = i + 1;
								if (ddfwm_last_address != ddfwm_route.legs[i].start_address) {
									ddfwm_summaryPanel.append('<div class="row ddfwm_address"><div class="col-2 text-center" ><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="map-marker" class="svg-inline--fa fa-map-marker fa-w-12" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0z"></path></svg><span class="ddfwm_point">' + ddfwm_numtoletter(ddfwm_routeSegment) + '</span></div><div class="col-10">' + ddfwm_route.legs[i].start_address + '</div></div>');
								}
								ddfwm_summaryPanel.append( '<div class="row ddfwm_drive"><div class="col-2 text-center"><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="ellipsis-v" style="width: 6px;" class="svg-inline--fa fa-ellipsis-v up fa-w-6" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 512"><path fill="currentColor" d="M96 184c39.8 0 72 32.2 72 72s-32.2 72-72 72-72-32.2-72-72 32.2-72 72-72zM24 80c0 39.8 32.2 72 72 72s72-32.2 72-72S135.8 8 96 8 24 40.2 24 80zm0 352c0 39.8 32.2 72 72 72s72-32.2 72-72-32.2-72-72-72-72 32.2-72 72z"></path></svg><br><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="car" class="svg-inline--fa fa-car fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M499.99 176h-59.87l-16.64-41.6C406.38 91.63 365.57 64 319.5 64h-127c-46.06 0-86.88 27.63-103.99 70.4L71.87 176H12.01C4.2 176-1.53 183.34.37 190.91l6 24C7.7 220.25 12.5 224 18.01 224h20.07C24.65 235.73 16 252.78 16 272v48c0 16.12 6.16 30.67 16 41.93V416c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32v-32h256v32c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32v-54.07c9.84-11.25 16-25.8 16-41.93v-48c0-19.22-8.65-36.27-22.07-48H494c5.51 0 10.31-3.75 11.64-9.09l6-24c1.89-7.57-3.84-14.91-11.65-14.91zm-352.06-17.83c7.29-18.22 24.94-30.17 44.57-30.17h127c19.63 0 37.28 11.95 44.57 30.17L384 208H128l19.93-49.83zM96 319.8c-19.2 0-32-12.76-32-31.9S76.8 256 96 256s48 28.71 48 47.85-28.8 15.95-48 15.95zm320 0c-19.2 0-48 3.19-48-15.95S396.8 256 416 256s32 12.76 32 31.9-12.8 31.9-32 31.9z"></path></svg><br><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="ellipsis-v" style="width: 6px;" class="svg-inline--fa down fa-ellipsis-v fa-w-6" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 512"><path fill="currentColor" d="M96 184c39.8 0 72 32.2 72 72s-32.2 72-72 72-72-32.2-72-72 32.2-72 72-72zM24 80c0 39.8 32.2 72 72 72s72-32.2 72-72S135.8 8 96 8 24 40.2 24 80zm0 352c0 39.8 32.2 72 72 72s72-32.2 72-72-32.2-72-72-72-72 32.2-72 72z"></path></svg> </div><div class="col-10 middle"  ><b>' + ddfwm_route.legs[i].duration.text + "</b><br>" + ddfwm_route.legs[i].distance.text + '</div></div></div>' );
								ddfwm_summaryPanel.append( '<div class="row ddfwm_address"><div class="col-2 text-center"><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="map-marker" class="svg-inline--fa fa-map-marker fa-w-12" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0z"></path></svg><span class="ddfwm_point">' + ddfwm_numtoletter((ddfwm_routeSegment + 1) * 1) + '</span></div><div class="col-10">' + ddfwm_route.legs[i].end_address + '</div></div>' );
								ddfwm_last_address = ddfwm_route.legs[i].end_address;
							}
							ddfwm_computeTotalDistance(ddfwm_driverid,response);

						} else {
							var ddfwm_summaryPanel = jQuery( "#driver_" + ddfwm_driverid ).find( ".ddfwm_directions-panel-listing" );
							ddfwm_summaryPanel.html('<div class="ddfwm_total_route"></div>') ;
							ddfwm_summaryPanel.append('Directions request failed due to ' + status);
						}
					}
				);
				}


				function ddfwm_screen(){
					//Load routes
					jQuery.when( ddfwm_get_routes_json () ).done(function( data ){
					var ddfwm_json = data;
					if( typeof ddfwm_json['data'] != 'undefined' ){
						jQuery( "#ddfwm_routes_notice").hide();
						var head = document.getElementsByTagName('head')[0];
						var script = document.createElement('script');
						script.type = 'text/javascript';
						script.onload = function() {

							//Create drivers
							ddfwm_drivers();

							//Create map
							ddfwm_initMap();

							jQuery( "#ddfwm_routes").show();
						}
						script.src = "https://maps.googleapis.com/maps/api/js?v=3&key=<?php echo esc_attr( $ddfwm_google_api_key ); ?>";
						head.appendChild(script);
						} else
						{
							jQuery( "#ddfwm_routes_notice").show();
						}
					});
				}
				ddfwm_screen();
				</script>
				<?php

	}
}
