<?php
/**
 * Fired during plugin activation
 *
 * @link  http://www.powerfulwp.com
 * @since 1.0.0
 *
 * @package    DDFWM
 * @subpackage DDFWM/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    DDFWM
 * @subpackage DDFWM/includes
 * @author     powerfulwp <cs@powerfulwp.com>
 */
class DDFWM_Activator {
	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since 1.0.0
	 */
	public static function activate() {


		if ( ddfwm_fs()->is__premium_only() ) {
			if ( ddfwm_fs()->can_use_premium_code() ) {


				if ( is_plugin_active( 'delivery-drivers-for-vendors/delivery-drivers-for-vendors.php' ) ) {
					deactivate_plugins( 'delivery-drivers-for-vendors/delivery-drivers-for-vendors.php' );
				}

			}
		}

		// Create vendor page for the first activation.
		$ddfwm_vendors_page = get_option( 'ddfwm_vendors_page', '' );

		if ( '' === $ddfwm_vendors_page ) {

			$array = array(
				'post_title'     => 'Vendors drivers manager',
				'post_type'      => 'page',
				'post_name'      => 'drivers-manager',
				'post_status'    => 'publish',
				'comment_status' => 'closed',
				'ping_status'    => 'closed',
			);

			$page_id = wp_insert_post( $array );

			if ( ! get_option( 'ddfwm_vendors_page' ) ) {
				add_option( 'ddfwm_vendors_page', $page_id );
			} else {
				update_option( 'ddfwm_vendors_page', $page_id );
			}
		}

	}
}
