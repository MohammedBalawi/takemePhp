<?php
/**
 * Plugin Reports.
 *
 * All the screens functions.
 *
 * @package    DDFWM
 * @subpackage DDFWM/includes
 * @author     powerfulwp <cs@powerfulwp.com>
 */

/**
 * Plugin Reports.
 *
 * All the Reports functions.
 *
 * @package    DDFWM
 * @subpackage DDFWM/includes
 * @author     powerfulwp <cs@powerfulwp.com>
 */
class DDFWM_Reports {

	/**
	 * Driver_status_orders.
	 *
	 * @param  mixed $driver_id .
	 * @param  mixed $status .
	 * @param  mixed $array .
	 * @return statement
	 */
	public function driver_status_orders( $driver_id, $status, $array ) {
		$orders = 0;
		foreach ( $array as $row ) {
			if ( '' === $driver_id ) {

				if ( $row->post_status === $status ) {
					$orders = $row->orders;
					break;
				}
			} else {
				if ( $row->post_status === $status && $driver_id === $row->driver_id ) {
					$orders = $row->orders;
					break;
				}
			}
		}
		return $orders;
	}

	/**
	 * Drivers orders dashboard report.
	 *
	 * @since 1.1.0
	 * @return html
	 */
	public function claim_orders_dashboard_report() {
		$orders                        = new DDFWM_Orders();
		$report_array                  = $orders->ddfwm_claim_orders_dashboard_report_query();
		$html                          = '<h5>' . esc_html( __( 'Orders without drivers', 'ddfwm' ) ) . '</h5>
	<div class="table-responsive">
	<table class=" table table-striped table-hover ">
	<thead class="table-dark">
		<tr>
			<th class="manage-column column-primary ">' . esc_html( __( 'Ready for claim', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center">' . esc_html( __( 'Driver assigned', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center">' . esc_html( __( 'Out for delivery', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center">' . esc_html( __( 'Delivered today', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center">' . esc_html( __( 'Failed delivery', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center">' . esc_html( __( 'Total', 'ddfwm' ) ) . '</td>
		</tr>
	</thead>
	<tbody>';
		$ddfwm_driver_assigned_status  = get_option( 'lddfw_driver_assigned_status', '' );
		$ddfwm_out_for_delivery_status = get_option( 'lddfw_out_for_delivery_status', '' );
		$ddfwm_failed_attempt_status   = get_option( 'lddfw_failed_attempt_status', '' );
		$ddfwm_delivered_status        = get_option( 'lddfw_delivered_status', '' );
		$ddfwm_processing_status       = get_option( 'lddfw_processing_status', '' );

		if ( empty( $report_array ) ) {
			$html .= '
		<tr>
			<td colspan="6" class="text-center">' . esc_html( __( 'No orders', 'ddfwm' ) ) . '</td>
		</tr>';
		} else {
				$processing_status       = $this->driver_status_orders( '', $ddfwm_processing_status, $report_array );
				$out_for_delivery_orders = $this->driver_status_orders( '', $ddfwm_out_for_delivery_status, $report_array );
				$driver_assigned_orders  = $this->driver_status_orders( '', $ddfwm_driver_assigned_status, $report_array );
				$failed_attempt_orders   = $this->driver_status_orders( '', $ddfwm_failed_attempt_status, $report_array );
				$delivered_orders        = $this->driver_status_orders( '', $ddfwm_delivered_status, $report_array );
				$total                   = $processing_status + $out_for_delivery_orders + $driver_assigned_orders + $failed_attempt_orders + $delivered_orders;
				$html                   .= '
				<tr class="table-secondary">
					<td class="title column-title has-row-actions column-primary" data-colname="' . esc_html( __( 'Ready for claim', 'ddfwm' ) ) . '" >
				    	' . ddfwm_premium_feature( '<a href=" ' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_orders_filter=-2&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_processing_status' ) ) ) . '">' . $processing_status . '</a>' ) . '
					</td>
					<td data-colname="' . esc_html( __( 'Driver assigned', 'ddfwm' ) ) . '" class="text-center">' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_orders_filter=-2&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_driver_assigned_status' ) ) ) . '">' . $driver_assigned_orders . '</a>' ) . '</td>
					<td data-colname="' . esc_html( __( 'Out for delivery', 'ddfwm' ) ) . '" class="text-center">' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_orders_filter=-2&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_out_for_delivery_status' ) ) ) . '">' . $out_for_delivery_orders . '</a>' ) . '</td>
					<td data-colname="' . esc_html( __( 'Delivered today', 'ddfwm' ) ) . '" class="text-center">' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_orders_filter=-2&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_delivered_status' ) ) ) . '">' . $delivered_orders . '</a>' ) . '</td>
					<td data-colname="' . esc_html( __( 'Failed delivery', 'ddfwm' ) ) . '" class="text-center">' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_orders_filter=-2&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_failed_attempt_status' ) ) ) . '">' . $failed_attempt_orders . '</a>' ) . '</td>
					<td data-colname="' . esc_html( __( 'Total', 'ddfwm' ) ) . '" class="text-center">' . ddfwm_premium_feature( $total ) . '</td>
				</tr>';
				$html                   .= '</tbody>';
		}
		$html .= '</table></div>';
		return $html;
	}

	/**
	 * Drivers orders dashboard report.
	 *
	 * @since 1.1.0
	 * @return html
	 */
	public function drivers_orders_dashboard_report() {
		global   $ddfwm_vendor_id;
		$orders       = new DDFWM_Orders();
		$driver       = new LDDFW_Driver();
		$report_array = $orders->ddfwm_drivers_orders_dashboard_report_query();
		$html         = '<h5>' . esc_html( __( 'Drivers orders', 'ddfwm' ) ) . '</h5>
	<div class="table-responsive">
	<table class=" table table-striped table-hover ">
	<thead class="table-dark">
		<tr>
			<th class="manage-column column-primary ">' . esc_html( __( 'Drivers', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center ">' . esc_html( __( 'Phone', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center">' . esc_html( __( 'Driver assigned', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center">' . esc_html( __( 'Out for delivery', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center">' . esc_html( __( 'Delivered today', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center">' . esc_html( __( 'Failed delivery', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center">' . esc_html( __( 'Total', 'ddfwm' ) ) . '</td>
		</tr>
	</thead>
	<tbody>';

		$ddfwm_driver_assigned_status  = get_option( 'lddfw_driver_assigned_status', '' );
		$ddfwm_out_for_delivery_status = get_option( 'lddfw_out_for_delivery_status', '' );
		$ddfwm_failed_attempt_status   = get_option( 'lddfw_failed_attempt_status', '' );
		$ddfwm_delivered_status        = get_option( 'lddfw_delivered_status', '' );

		$last_driver                   = '';
		$out_for_delivery_orders_total = 0;
		$driver_assigned_orders_total  = 0;
		$failed_attempt_orders_total   = 0;
		$delivered_orders_total        = 0;
		$total                         = 0;
		$driver_counter                = 0;
		$sub_total                     = 0;
		if ( empty( $report_array ) ) {
			$html .= '
		<tr>
			<td colspan="7" class="text-center">' . esc_html( __( 'No orders', 'ddfwm' ) ) . '</td>
		</tr>';
		} else {

			foreach ( $report_array as $row ) {
				$driver_id = $row->driver_id;
				if ( $last_driver !== $driver_id ) {

					$driver_seller = get_user_meta( $driver_id, 'ddfwm_vendor', true );
					

						++$driver_counter;

						$out_for_delivery_orders = $this->driver_status_orders( $driver_id, $ddfwm_out_for_delivery_status, $report_array );
						$driver_assigned_orders  = $this->driver_status_orders( $driver_id, $ddfwm_driver_assigned_status, $report_array );
						$failed_attempt_orders   = $this->driver_status_orders( $driver_id, $ddfwm_failed_attempt_status, $report_array );
						$delivered_orders        = $this->driver_status_orders( $driver_id, $ddfwm_delivered_status, $report_array );

						$sub_total                      = $out_for_delivery_orders + $driver_assigned_orders + $failed_attempt_orders + $delivered_orders;
						$total                         += $sub_total;
						$out_for_delivery_orders_total += $out_for_delivery_orders;
						$driver_assigned_orders_total  += $driver_assigned_orders;
						$failed_attempt_orders_total   += $failed_attempt_orders;
						$delivered_orders_total        += $delivered_orders;

						$phone = get_user_meta( $driver_id, 'billing_phone', true );

						$last_driver = $driver_id;
						$html       .= '
				<tr>
					<td class="title column-title has-row-actions column-primary" data-colname="' . esc_html( __( 'Driver', 'ddfwm' ) ) . '" >
						' . $row->driver_name . '
					</td>
				 	<td class="text-center" data-colname="' . esc_html( __( 'Phone', 'ddfwm' ) ) . '"><a href="tel:' . $phone . '">' . $phone . '</a></td> 
					<td class="text-center" data-colname="' . esc_html( __( 'Driver assigned', 'ddfwm' ) ) . '">' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_orders_filter=-1&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_driver_assigned_status' ) ) ) . '">' . $driver_assigned_orders . '</a>' ) . '</td>
					<td class="text-center" data-colname="' . esc_html( __( 'Out for delivery', 'ddfwm' ) ) . '">' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_orders_filter=' . esc_attr( $driver_id ) . '&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_out_for_delivery_status' ) ) ) . '">' . $out_for_delivery_orders . '</a>' ) . '</td>
					<td class="text-center" data-colname="' . esc_html( __( 'Delivered today', 'ddfwm' ) ) . '">' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_orders_filter=' . esc_attr( $driver_id ) . '&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_delivered_status' ) ) . '&ddfwm_dates_range=' . date_i18n( 'Y-m-d' ) . ',' . date_i18n( 'Y-m-d' ) ) . '">' . $delivered_orders . '</a>' ) . '</td>
					<td class="text-center" data-colname="' . esc_html( __( 'Failed delivery', 'ddfwm' ) ) . '">' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_orders_filter=' . esc_attr( $driver_id ) . '&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_failed_attempt_status' ) ) ) . '">' . $failed_attempt_orders . '</a>' ) . '</td>
					<td class="text-center" data-colname="' . esc_html( __( 'Total', 'ddfwm' ) ) . '">' . ddfwm_premium_feature( $sub_total ) . '</td>
				</tr>';
					
				}
			}
		}
		$html .= '</tbody>
		<tfoot class="table-secondary">
			<td class="title column-title has-row-actions column-primary">' . $driver_counter . ' ' . esc_html( __( 'Drivers', 'ddfwm' ) ) . '</td>
			<td class="text-center"> </td>
			<td class="text-center">' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_orders_filter=-1&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_driver_assigned_status' ) ) ) . '">' . $driver_assigned_orders_total . '</a>' ) . '</td>
			<td class="text-center">' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_orders_filter=-1&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_out_for_delivery_status' ) ) ) . '">' . $out_for_delivery_orders_total . '</a>' ) . '</td>
			<td class="text-center">' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_orders_filter=-1&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_delivered_status' ) ) . '&ddfwm_dates_range=' . date_i18n( 'Y-m-d' ) . ',' . date_i18n( 'Y-m-d' ) ) . '">' . $delivered_orders_total . '</a>' ) . '</td>
			<td class="text-center">' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_orders_filter=-1&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_failed_attempt_status' ) ) ) . '">' . $failed_attempt_orders_total . '</a>' ) . '</td>
			<td class="text-center">' . ddfwm_premium_feature( $total ) . '</td>
		</tfoot>
	</table></div>';
		return $html;
	}

	/**
	 * Drivers refund query.
	 *
	 * @param  mixed $fromdate .
	 * @param  mixed $todate .
	 * @param  mixed $driver_id .
	 * @return statement
	 */
	public function ddfwm_drivers_refund_query( $fromdate, $todate, $driver_id = '' ) {
		global $wpdb,$ddfwm_vendor_id;

		$driver_query = '';
		if ( '' !== $driver_id ) {
			$driver_query = $wpdb->prepare( 'pm.meta_value = %s and', array( $driver_id ) );
		}

		$query = $wpdb->get_results(
			$wpdb->prepare(
				'select pm.meta_value as driver_id,
				COALESCE(SUM( pm5.meta_value ),0) as refund  
				from ' . $wpdb->prefix . 'posts p
				inner join ' . $wpdb->prefix . 'postmeta pm on p.id=pm.post_id and pm.meta_key = \'lddfw_driverid\'
				inner join ' . $wpdb->prefix . 'postmeta pm1 on p.id=pm1.post_id and pm1.meta_key = \'lddfw_delivered_date\'
				' . ddfwm_order_seller_query( 'inner join' ) . '
				left join ' . $wpdb->prefix . 'posts p2 on p.id=p2.post_parent
				left join ' . $wpdb->prefix . 'postmeta pm5 on p2.id=pm5.post_id and pm5.meta_key = \'_refund_amount\'
				where ' . $driver_query . ' p.post_type=\'shop_order\' and
				( p.post_status = %s and CAST( pm1.meta_value AS DATE ) >= %s and CAST( pm1.meta_value AS DATE ) <= %s )
				group by pm.meta_value
				order by pm.meta_value ',
				array(
					get_option( 'lddfw_delivered_status', '' ),
					$fromdate,
					$todate,

				)
			)
		); // db call ok; no-cache ok.
		return $query;
	}

	/**
	 * Drivers commissions query.
	 *
	 * @param  mixed $fromdate .
	 * @param  mixed $todate .
	 * @param  mixed $driver_id .
	 * @return statement
	 */
	public function ddfwm_drivers_commission_query( $fromdate, $todate, $driver_id = '' ) {
		global $wpdb,$ddfwm_vendor_id;

		$driver_query = '';
		if ( '' !== $driver_id ) {
			$driver_query = $wpdb->prepare( 'pm.meta_value = %s and', array( $driver_id ) );
		}

		$query = $wpdb->get_results(
			$wpdb->prepare(
				'select pm.meta_value driver_id,
				COALESCE(SUM( pm2.meta_value ),0) as commission ,
				count(p.id) as orders,
				COALESCE(SUM( pm3.meta_value),0)  as orders_total ,
				COALESCE(SUM( pm4.meta_value ),0) as shipping_total
				from ' . $wpdb->prefix . 'posts p
				inner join ' . $wpdb->prefix . 'postmeta pm on p.id=pm.post_id and pm.meta_key = \'lddfw_driverid\'
				inner join ' . $wpdb->prefix . 'postmeta pm1 on p.id=pm1.post_id and pm1.meta_key = \'lddfw_delivered_date\'
				left join ' . $wpdb->prefix . 'postmeta pm2 on p.id=pm2.post_id and pm2.meta_key = \'lddfw_driver_commission\'
				left join ' . $wpdb->prefix . 'postmeta pm3 on p.id=pm3.post_id and pm3.meta_key = \'_order_total\'
				left join ' . $wpdb->prefix . 'postmeta pm4 on p.id=pm4.post_id and pm4.meta_key = \'_order_shipping\'
				' . ddfwm_order_seller_query( 'inner join' ) . '
				where ' . $driver_query . ' p.post_type=\'shop_order\' and
				( p.post_status = %s and CAST( pm1.meta_value AS DATE ) >= %s and CAST( pm1.meta_value AS DATE ) <= %s )
				group by pm.meta_value
				order by pm.meta_value ',
				array(
					get_option( 'lddfw_delivered_status', '' ),
					$fromdate,
					$todate,
				)
			)
		); // db call ok; no-cache ok.
		return $query;
	}

	/**
	 * Drivers commissions report.
	 *
	 * @since 1.1.0
	 * @return html
	 */
	public function drivers_commissions_report() {

		$ddfwm_dates_range      = ( isset( $_POST['ddfwm_dates_range'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_dates_range'] ) ) : 'today';
		$ddfwm_dates_range_from = ( isset( $_POST['ddfwm_dates_range_from'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_dates_range_from'] ) ) : date_i18n( 'Y-m-d' );
		$ddfwm_dates_range_to   = ( isset( $_POST['ddfwm_dates_range_to'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_dates_range_to'] ) ) : date_i18n( 'Y-m-d' );

		$refund_array = $this->ddfwm_drivers_refund_query( $ddfwm_dates_range_from, $ddfwm_dates_range_to );
		$report_array = $this->ddfwm_drivers_commission_query( $ddfwm_dates_range_from, $ddfwm_dates_range_to );
		$html         = '<h5>' . esc_html( __( 'Drivers commissions', 'ddfwm' ) ) . '</h5>
	<div id="lddfw_dates_range_wrap" class="row">
		<form method="POST" name="ddfwm_form" class="row g-3 form-inline" action="' . ddfwm_vendors_page_url( 'ddfwm_screen=reports' ) . '">
			<div class="col-auto">
			' . esc_html( __( 'Dates', 'ddfwm' ) ) . '
			</div>
			<div class="col-auto">
				<div id="lddfw_dates_range_select">
					<select class="form-select " name="ddfwm_dates_range" id="ddfwm_dates_range" >
						<option ' . selected( $ddfwm_dates_range, 'today', false ) . ' fromdate="' . date_i18n( 'Y-m-d' ) . '" todate="' . date_i18n( 'Y-m-d' ) . '" value="today">' . esc_html( __( 'Today', 'ddfwm' ) ) . '</option>
						<option ' . selected( $ddfwm_dates_range, 'yesterday', false ) . ' fromdate="' . date_i18n( 'Y-m-d', strtotime( '-1 days' ) ) . '" todate="' . date_i18n( 'Y-m-d', strtotime( '-1 days' ) ) . '" value="yesterday">' . esc_html( __( 'Yesterday', 'ddfwm' ) ) . '</option>
						<option ' . selected( $ddfwm_dates_range, 'thismonth', false ) . '  fromdate="' . date_i18n( 'Y-m-d', strtotime( 'first day of this month' ) ) . '" todate="' . date_i18n( 'Y-m-d', strtotime( 'last day of this month' ) ) . '"  value="thismonth">' . esc_html( __( 'This month', 'ddfwm' ) ) . '</option>
						<option ' . selected( $ddfwm_dates_range, 'lastmonth', false ) . '  fromdate="' . date_i18n( 'Y-m-d', strtotime( 'first day of last month' ) ) . '" todate="' . date_i18n( 'Y-m-d', strtotime( 'last day of last month' ) ) . '"  value="lastmonth">' . esc_html( __( 'Last month', 'ddfwm' ) ) . '</option>
						<option ' . selected( $ddfwm_dates_range, 'custom', false ) . '  value="custom">' . esc_html( __( 'Custom', 'ddfwm' ) ) . '</option>
					</select>
				</div>
			</div>
			<div class="col-auto" id="ddfwm_dates_custom_range" style="display:none">
				<div class="input-group ">
					<label>' . esc_html( __( 'From', 'ddfwm' ) ) . '</label> &nbsp; <input type = "text" value="' . $ddfwm_dates_range_from . '" class="ddfwm-datepicker form-control " name="ddfwm_dates_range_from" id = "ddfwm_dates_range_from" >
					&nbsp; <label>' . esc_html( __( 'To', 'ddfwm' ) ) . '</label> &nbsp; <input type = "text" value="' . $ddfwm_dates_range_to . '" class="ddfwm-datepicker form-control "  name="ddfwm_dates_range_to" id = "ddfwm_dates_range_to" >
				</div>
			</div>
			<div class="col-auto">
			<input class="btn btn-primary mb-2" type="submit" name="ddfwm_submit" id="ddfwm_dates_range_submit" class="button button-primary" value="' . esc_html( __( 'Send', 'ddfwm' ) ) . '">
			</div>
		</form>
	</div>
	<div class="table-responsive">
	<table class="table table-striped table-hover">
	<thead class="table-dark">
		<tr>
			<th class="manage-column column-primary ">' . esc_html( __( 'Drivers', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center">' . esc_html( __( 'Orders', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center">' . esc_html( __( 'Orders Total', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center">' . esc_html( __( 'Shipping Total', 'ddfwm' ) ) . '</td>
			<th class="manage-column column-primary text-center">' . esc_html( __( 'Commission', 'ddfwm' ) ) . '</td>
		</tr>
	</thead>
	<tbody>';

		$last_driver    = '';
		$commission     = 0;
		$orders_price   = 0;
		$shipping_price = 0;
		$orders_counter = 0;
		$driver_counter = 0;

		$commission_total     = 0;
		$orders_counter_total = 0;
		$orders_total         = 0;
		$shipping_total       = 0;
		if ( empty( $report_array ) ) {
			$html .= '
		<tr>
			<td colspan="5" class="text-center">' . esc_html( __( 'No orders', 'ddfwm' ) ) . '</td>
		</tr>';
		} else {
			foreach ( $report_array as $row ) {
				$driver_id = $row->driver_id;
				if ( $last_driver !== $driver_id ) {
					$driver          = get_userdata( $driver_id );
					$driver_name     = $driver->display_name;
					++$driver_counter;
					if ( ddfwm_fs()->is__premium_only() ) {
						if ( ddfwm_fs()->can_use_premium_code() ) {
							$orders_counter = $row->orders;
							$orders_price   = $row->orders_total;

							// Calculate refunds.
							if ( ! empty( $refund_array ) ) {
								foreach ( $refund_array as $refund_row ) {
									if ( $refund_row->driver_id === $driver_id ) {
										$orders_price = $orders_price - $refund_row->refund;
										break;
									}
								}
							}

							$shipping_price = $row->shipping_total;
							$commission     = $row->commission;

							$orders_counter_total += $orders_counter;
							$commission_total     += $commission;
							$orders_total         += $orders_price;
							$shipping_total       += $shipping_price;
						}
					}
					$last_driver = $driver_id;

					$html .= '
				<tr>
					<td class="title column-title has-row-actions column-primary" data-colname="' . esc_html( __( 'Driver', 'ddfwm' ) ) . '" >' . $driver_name . '</td>
					<td class="text-center" data-colname="' . esc_html( __( 'Orders', 'ddfwm' ) ) . '" > ' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_from_date=' . $ddfwm_dates_range_from . '&ddfwm_to_date=' . $ddfwm_dates_range_to . '&ddfwm_orders_filter=' . esc_attr( $driver_id ) . '&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_delivered_status' ) ) ) . '">' . $orders_counter . '</a>' ) . '</td>
					<td class="text-center" data-colname="' . esc_html( __( 'Orders Price', 'ddfwm' ) ) . '" > ' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_from_date=' . $ddfwm_dates_range_from . '&ddfwm_to_date=' . $ddfwm_dates_range_to . '&ddfwm_orders_filter=' . esc_attr( $driver_id ) . '&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_delivered_status' ) ) ) . '">' . get_woocommerce_currency_symbol() . $orders_price . '</a>' ) . '</td>
					<td class="text-center" data-colname="' . esc_html( __( 'Shipping Price', 'ddfwm' ) ) . '" > ' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_from_date=' . $ddfwm_dates_range_from . '&ddfwm_to_date=' . $ddfwm_dates_range_to . '&ddfwm_orders_filter=' . esc_attr( $driver_id ) . '&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_delivered_status' ) ) ) . '">' . get_woocommerce_currency_symbol() . $shipping_price . '</a>' ) . '</td>
					<td class="text-center" data-colname="' . esc_html( __( 'Commission', 'ddfwm' ) ) . '" > ' . ddfwm_premium_feature( '<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=orders&ddfwm_from_date=' . $ddfwm_dates_range_from . '&ddfwm_to_date=' . $ddfwm_dates_range_to . '&ddfwm_orders_filter=' . esc_attr( $driver_id ) . '&ddfwm_orders_status=' . esc_attr( get_option( 'lddfw_delivered_status' ) ) ) . '">' . get_woocommerce_currency_symbol() . $commission . '</a>' ) . '</td>
				</tr>';
				}
			}
		}
		$html .= '</tbody>
		<tfoot class="table-secondary">
			<td class="title column-title has-row-actions column-primary" data-colname="' . esc_html( __( 'Driver', 'ddfwm' ) ) . '" >' . $driver_counter . ' ' . esc_html( __( 'Drivers', 'ddfwm' ) ) . '</td>
			<td class="text-center" data-colname="' . esc_html( __( 'Orders', 'ddfwm' ) ) . '"> ' . ddfwm_premium_feature( '<a href="edit.php?post_status=' . esc_attr( get_option( 'lddfw_delivered_status' ) ) . '&post_type=shop_order&lddfw_from_date=' . $ddfwm_dates_range_from . '&ddfwm_to_date=' . $ddfwm_dates_range_to . '&ddfwm_orders_filter=-1">' . $orders_counter_total . '</a>' ) . '</td>
			<td class="text-center" data-colname="' . esc_html( __( 'Orders Price', 'ddfwm' ) ) . '"> ' . ddfwm_premium_feature( '<a href="edit.php?post_status=' . esc_attr( get_option( 'lddfw_delivered_status' ) ) . '&post_type=shop_order&lddfw_from_date=' . $ddfwm_dates_range_from . '&ddfwm_to_date=' . $ddfwm_dates_range_to . '&ddfwm_orders_filter=-1">' . get_woocommerce_currency_symbol() . $orders_total . '</a>' ) . ' </td>
			<td class="text-center" data-colname="' . esc_html( __( 'Shipping Price', 'ddfwm' ) ) . '"> ' . ddfwm_premium_feature( '<a href="edit.php?post_status=' . esc_attr( get_option( 'lddfw_delivered_status' ) ) . '&post_type=shop_order&lddfw_from_date=' . $ddfwm_dates_range_from . '&ddfwm_to_date=' . $ddfwm_dates_range_to . '&ddfwm_orders_filter=-1">' . get_woocommerce_currency_symbol() . $shipping_total . '</a>' ) . ' </td>
			<td class="text-center" data-colname="' . esc_html( __( 'Commission', 'ddfwm' ) ) . '"> ' . ddfwm_premium_feature( '<a href="edit.php?post_status=' . esc_attr( get_option( 'lddfw_delivered_status' ) ) . '&post_type=shop_order&lddfw_from_date=' . $ddfwm_dates_range_from . '&ddfwm_to_date=' . $ddfwm_dates_range_to . '&ddfwm_orders_filter=-1">' . get_woocommerce_currency_symbol() . $commission_total . '</a>' ) . ' </td>
		</tfoot>
	</table></div>';
		return $html;
	}

	/**
	 * Admin dashboard screen.
	 *
	 * @since 1.1.0
	 * @return html
	 */
	public function screen_dashboard() {
		  $html  = '<div class="container">';
		  $html .= $this->drivers_orders_dashboard_report();
		  $html .= '<hr style="margin-top:30px; margin-bottom:30px">';
		  $html .= $this->claim_orders_dashboard_report();
		  $html .= '<hr style="margin-top:30px; margin-bottom:30px">';
		  $html .= $this->drivers_dashboard_report();
		  $html .= '</div>';
		return $html;
	}

	/**
	 * Admin report screen.
	 *
	 * @since 1.1.0
	 * @return html
	 */
	public function screen_reports() {
		$html  = '<div class="container">';
		$html .= $this->drivers_commissions_report();
		$html .= '
		</div>';
		return $html;
	}

	/**
	 * Drivers dashboard report.
	 *
	 * @since 1.1.0
	 * @return html
	 */
	public function drivers_dashboard_report() {
		global $ddfwm_vendor_id, $ddfwm_vendor_drivers;
		$drivers = DDFWM_Driver::ddfwm_get_drivers( $ddfwm_vendor_id, 'all' );
		$vendor  = new DDFWM_Vendor();
		$html    = '
		<div class="row" style="margin-top:30px; margin-bottom:10px;">
		<div class="col-6">
			<h5 style="
			margin-top: 14px;
			margin-bottom: 0px;
		">' . esc_html( __( 'Active drivers', 'ddfwm' ) ) . '</h5>
		</div>
		<div class="col-6">';
		if ( ddfwm_fs()->is__premium_only() ) {
			if ( ddfwm_fs()->is_plan( 'premium', true ) ) {
				if ( '1' === $ddfwm_vendor_drivers || '2' === $ddfwm_vendor_drivers ) {
					$html .= '<a style="float:right; margin-left:10px;"  href="' . ddfwm_vendors_page_url( 'ddfwm_screen=newdriver' ) . '" class="btn btn-primary" >' . esc_html( __( 'Add new driver', 'ddfwm' ) ) . '</a>';
				}
			}
		}
		$html        .= '<a style="float:right" class="btn btn-secondary" href="' . ddfwm_vendors_page_url( 'ddfwm_screen=drivers' ) . '">' . esc_html( __( 'All drivers', 'ddfwm' ) ) . '</a>
		</div>
		</div>
		<div class="table-responsive">
		<table class=" table table-striped table-hover  ">
		<thead class="table-dark">
			<tr>
				<th class="manage-column column-primary " style="min-width:150px">' . esc_html( __( 'Drivers', 'ddfwm' ) ) . '</td>
				<th>' . esc_html( __( 'Phone', 'ddfwm' ) ) . '</td>
				<th>' . esc_html( __( 'Email', 'ddfwm' ) ) . '</td>
				<th>' . esc_html( __( 'Address', 'ddfwm' ) ) . '</td>
				<th class="manage-column column-primary text-center">' . esc_html( __( 'Availability', 'ddfwm' ) ) . '</td>
				<th class="manage-column column-primary text-center">' . esc_html( __( 'Claim orders', 'ddfwm' ) ) . '</td>
				<th class="text-center">' . esc_html( __( 'Vendor', 'ddfwm' ) ) . '</td>
			</tr>
		</thead>
		<tbody>';
		$total_driver = 0;

		if ( empty( $drivers ) ) {
			$html .= '
			<tr>
				<td colspan="6" class="text-center">' . esc_html( __( 'No drivers', 'ddfwm' ) ) . '</td>
			</tr>';
		} else {
			foreach ( $drivers as $driver ) {

				/**
				 * Driver data.
				 */
				$driver_id  = $driver->ID;
				$seller_id  = get_user_meta( $driver_id, 'ddfwm_vendor', true );
				$store_name = $vendor->ddfwm_store_name( '', $seller_id );

				$ddfwm_driver_account = get_user_meta( $driver_id, 'lddfw_driver_account', true );

				if ( '1' === $ddfwm_driver_account ) {
					$email             = $driver->user_email;
					$full_name         = $driver->display_name;
					$availability      = get_user_meta( $driver_id, 'lddfw_driver_availability', true );
					$driver_claim      = get_user_meta( $driver_id, 'lddfw_driver_claim', true );
					$phone             = get_user_meta( $driver_id, 'billing_phone', true );
					$billing_address_1 = get_user_meta( $driver_id, 'billing_address_1', true );
					$billing_address_2 = get_user_meta( $driver_id, 'billing_address_2', true );
					$billing_city      = get_user_meta( $driver_id, 'billing_city', true );
					$billing_company   = get_user_meta( $driver_id, 'billing_company', true );
					$availability_icon = '';
					$driver_claim_icon = '';

					/**
					 * Driver billing address.
					 */
					$billing_address = '';
					if ( '' !== $billing_company ) {
						$billing_address = $billing_address . $billing_company . ', ';
					}
					if ( '' !== $billing_address_1 ) {
						$billing_address = $billing_address . $billing_address_1;
					}
					if ( '' !== $billing_address_2 ) {
						$billing_address = $billing_address . ', ' . $billing_address_2;
					}
					if ( '' !== $billing_city ) {
						$billing_address = $billing_address . ', ' . $billing_city;
					}

					$total_driver++;

							/**
							 * Driver status icons and counters.
							 */
					if ( '1' === $availability ) {
						$availability_icon = '<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle" class=" text-success svg-inline--fa fa-circle fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path></svg>';
					} else {
						$availability_icon = '<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle" class=" text-danger svg-inline--fa fa-circle fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path></svg>';
					}

					if ( '1' === $driver_claim ) {
						$driver_claim_icon = '<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle" class=" text-success svg-inline--fa fa-circle fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path></svg>';
					} else {
						$driver_claim_icon = '<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle" class=" text-danger svg-inline--fa fa-circle fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path></svg>';
					}
						$icon_class = ( strval( $seller_id ) === strval( $ddfwm_vendor_id ) ) ? 'ddfwm_user_icon' : 'ddfwm_user_icon_disable';
					$html          .= '
				<tr>
					<td class="title column-title has-row-actions column-primary" data-colname="' . esc_html( __( 'Driver', 'ddfwm' ) ) . '" >
						<a href="' . ddfwm_vendors_page_url( 'ddfwm_screen=driver&ddfwm_driverid=' . $driver_id ) . '">' . esc_html( $full_name ) . '</a>
					</td>
					<td data-colname="' . esc_html( __( 'Phone', 'ddfwm' ) ) . '"><a href="tel:' . esc_attr( $phone ) . '">' . esc_html( $phone ) . '</a></td>
					<td data-colname="' . esc_html( __( 'Email', 'ddfwm' ) ) . '" ><a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a></td>
					<td data-colname="' . esc_html( __( 'Address', 'ddfwm' ) ) . '">' . $billing_address . '</td>
					<td class="text-center">' . ddfwm_premium_feature( '<a href="#" class="' . $icon_class . ' ddfwm_availability" service="ddfwm_availability" driver_id="' . esc_attr( $driver_id ) . '">' . $availability_icon . '</a>' ) . '</td>
					<td class="text-center">' . ddfwm_premium_feature( '<a href="#" class="' . $icon_class . ' ddfwm_claim_permission" service="ddfwm_claim_permission" driver_id="' . esc_attr( $driver_id ) . '">' . $driver_claim_icon . '</a>' ) . '</td>
					<td  class="text-center">' . $store_name . '</td>
				</tr>';
				}
			}
		}
		$html     .= '</tbody>
				<tfoot class="table-secondary">
					<td class="title column-title has-row-actions column-primary">' . $total_driver . ' ' . esc_html( __( 'Drivers', 'ddfwm' ) ) . '</td>
					<td></td>
					<td></td>
					<td></td>
					<td class = "text-center">' . ddfwm_premium_feature( '<span id="ddfwm_available_counter"></span> ' . esc_html( __( 'Availables', 'ddfwm' ) ) . ' |  <span id="ddfwm_unavailable_counter"></span> ' . esc_html( __( 'Unavailables', 'ddfwm' ) ) ) . '</td>
					<td class = "text-center">' . ddfwm_premium_feature( '<span id="ddfwm_claim_counter"></span> ' . esc_html( __( 'Can claim', 'ddfwm' ) ) . ' | <span id="ddfwm_unclaim_counter"></span> ' . esc_html( __( 'Can\'t claim', 'ddfwm' ) ) ) . '</td>
					<td></td>
				</tfoot>
			</table></div>';
			$html .= '
			<hr style="margin-top:30px; margin-bottom:30px">
			<div class="driver_app row">
					<div class="col-2 col-md-1">
					<img alt="' . esc_attr( 'Drivers app', 'ddfwm' ) . '" title="' . esc_attr( 'Drivers app', 'ddfwm' ) . '" src="' . esc_url( plugins_url() . '/' . DDFWM_FOLDER . '/public/images/drivers_app.png?ver=' . DDFWM_VERSION ) . '">
					</div>
					<div class="col-10 col-md-11">
						<b><a target="_blank" href="' . lddfw_drivers_page_url( '' ) . '">' . lddfw_drivers_page_url( '' ) . '</a></b><br>' .
						 sprintf( esc_html( __( 'The link above is the delivery driver\'s Mobile-Friendly panel URL. %1$s The delivery drivers can access it from their mobile phones. %2$s', 'ddfwm' ) ), '<br>', '<br>' ) .
						 sprintf( esc_html( __( 'Notice: If you want to be logged in as an vendor and to check the drivers\' panel on the same device, %1$s %2$syou must work with two different browsers otherwise you will log out from the vendor panel and the drivers\' panel won\'t function correctly.%3$s', 'ddfwm' ) ), '<br>', '<b>', '</b>' ) . '
					 </div>
				</div>
				';

			return $html;
	}
}









