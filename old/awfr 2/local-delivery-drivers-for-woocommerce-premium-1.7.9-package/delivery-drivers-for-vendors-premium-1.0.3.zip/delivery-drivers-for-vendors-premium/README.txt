=== Delivery Drivers for Vendors ===
Contributors: powerfulwp
Donate link: https://powerfulwp.com
Tags: delivery, delivery manager, courier, vendors, woocommerce, shipping
Requires at least: 4.5
Requires PHP: 5.6
Tested up to: 5.7
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Let your WooCommerce marketplace vendors manage their drivers, assign drivers to orders, routes, reports, commission, and more!

== Description ==

## This plugin must have the following plugins activated on your WordPress:
* [Local Delivery Drivers for WooCommerce](https://wordpress.org/plugins/local-delivery-drivers-for-woocommerce/)
* WooCommerce
* One of the following multivendor plugins DOKAN or WCFM or WCMP.

## Manage Delivery Drivers
Allow your vendors to manage the delivery process and assign drivers to orders.

## Front-End Mobile-Friendly Dashboard
Allow your vendors to manage drivers with a front-end dashboard that can be accessed from any device like mobile tablet or desktop, with no need to access your admin panel.

## Manage Orders
Allow your vendors to assign delivery drivers to orders, update order statuses, and more.

## * PREMIUM FEATURES
Check out the [Delivery Drivers for Vendors Premium](https://powerfulwp.com/delivery-drivers-for-woocommerce-multi-vendor-marketplace/) plugin.
The premium plugin includes the following additional features:

## Manage Delivery Drivers
* Allow your vendors to manage the delivery process, assign drivers to orders, routes, reports, commission, and more!
* The vendor can create their own delivery drivers.
* The vendor can view all his drivers’ info, who is active, available, and have claim permission. each status can be updated easily with one click.

## Delivery Drivers Manager Dashboard
The dashboard lets the manager have a better view of all his drivers and orders.
Dashboard Includes:
* How many orders each driver has in each status.
* How many orders don’t have a driver.
* How many orders are ready to claim.
* List of all the active drivers, availability, and claim permissions all statuses can be updated in one click.

## Delivery Drivers Routes
The vendor can view all drivers routes duration and distance on the map.

## Manage Orders
Bulk Updates - The vendor can bulk assign drivers to orders and update orders status.
Filters - The vendor can filter orders with several options.

## Delivery Drivers Reports
The vendor can see the drivers commissions report, set his own drivers, commissions, rates, and more.

[SVG created by fontawesome - www.fontawesome.com](https://fontawesome.com/license)
[Design vector created by freepik - www.freepik.com](https://www.freepik.com/vectors/design)

== Installation ==
1. Make a backup of your website and database
1. Download the plugin
1. Upload the plugin to the wp-content/plugins directory,
1. Go to "plugins" in your WordPress admin, then click activate.
1. Go to vendor users on the admin panel and click on a vendor user.
1. On the edit user page set vendor account status to active and choose a vendor drivers option.
1. Go to the local delivery plugin settings and click on the Vendors settings tab
1. On this page you have the vendor manager panel link, send it to the vendors.
1. The vendor can log in to the delivery manager panel and start working.


== Frequently Asked Questions ==

== Screenshots ==
1. Premium - Delivery Drivers Vendor Dashboard.
1. Premium - Delivery Drivers Routes.
1. Premium - Manage Delivery Drivers.
1. Premium - Manage Orders.
1. Premium - Manage Order.
1. Premium - Delivery Drivers Vendor Reports.

== Changelog ==

= 1.0.1 =
* Initial release.

= 1.0.2 =
* Fix: Orders filters.

= 1.0.3 =
* Fix: Bulk orders update.

== Upgrade Notice ==




