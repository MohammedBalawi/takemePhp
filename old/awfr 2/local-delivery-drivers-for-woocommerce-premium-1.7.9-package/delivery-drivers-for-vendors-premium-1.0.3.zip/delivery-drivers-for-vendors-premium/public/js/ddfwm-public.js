(function($) {
    "use strict";

    function ddfwm_dates_range() {
        var $ddfwm_this = $("#ddfwm_dates_range");
        if ($ddfwm_this.val() == "custom") {
            $("#ddfwm_dates_custom_range").show();
        } else {
            var ddfwm_fromdate = $('option:selected', $ddfwm_this).attr('fromdate');
            var ddfwm_todate = $('option:selected', $ddfwm_this).attr('todate');
            $("#ddfwm_dates_custom_range").hide();
            $("#ddfwm_dates_range_from").val(ddfwm_fromdate);
            $("#ddfwm_dates_range_to").val(ddfwm_todate);
        }
    }

    $("#ddfwm_dates_range").change(
        function() {
            ddfwm_dates_range()
        }
    );

    if ($("#ddfwm_dates_range").length) {
        ddfwm_dates_range();
    }

    if ($(".ddfwm-datepicker").length) {
        $(".ddfwm-datepicker").datepicker({ dateFormat: "yy-mm-dd" });
    }

    function ddfwm_counters() {
        if (jQuery("#ddfwm_page.dashboard").length) {
            var ddfwm_unavailable_counter = jQuery(".ddfwm_availability .text-danger").length;
            var ddfwm_available_counter = jQuery(".ddfwm_availability .text-success").length;
            var ddfwm_unclaim_counter = jQuery(".ddfwm_claim_permission .text-danger").length;
            var ddfwm_claim_counter = jQuery(".ddfwm_claim_permission .text-success").length;
            jQuery("#ddfwm_available_counter").html(ddfwm_available_counter);
            jQuery("#ddfwm_claim_counter").html(ddfwm_claim_counter);
            jQuery("#ddfwm_unavailable_counter").html(ddfwm_unavailable_counter);
            jQuery("#ddfwm_unclaim_counter").html(ddfwm_unclaim_counter);
        }
    }

    ddfwm_counters();

    $("#ddfwm_orders_filter_btn").on(
        "click",
        function() {
            window.location.replace($("#ddfwm_orders_form").attr("action") + "&ddfwm_orders_filter=" + $("#ddfwm_orders_filter").val() + "&ddfwm_orders_status=" + $("#ddfwm_orders_status").val() + "&ddfwm_dates_range=" + $("#ddfwm_dates_range").val());
            return false;
        }
    );

    jQuery("#cancel_password_button").on(
        "click",
        function() {
            jQuery("#ddfwm_password_holder").hide();
            jQuery("#ddfwm_password").val("");
        }
    );

    jQuery("#new_password_button").on(
        "click",
        function() {
            jQuery("#ddfwm_password_holder").show();
            jQuery("#ddfwm_password").val(Math.random().toString(36).slice(2));
        }
    );

    jQuery("#billing_state_select").on(
        "change",
        function() {
            jQuery("#billing_state_input").val(jQuery(this).val());
        }
    );
    jQuery("#billing_country").on(
        "change",
        function() {
            if (jQuery(this).val() == "US") {
                jQuery("#billing_state_select").show();
                jQuery("#billing_state_input").hide();
            } else {
                jQuery("#billing_state_input").show();
                jQuery("#billing_state_select").hide();
            }
        }
    );
    if (jQuery("#billing_country").length) {
        jQuery("#billing_country").trigger("change");
    }

    jQuery(".ddfwm_user_icon").click(
        function() {
            var ddfwm_driver_id = jQuery(this).attr("driver_id");
            var ddfwm_service = jQuery(this).attr("service");
            var ddfwm_icon = jQuery(this).find("svg")
            if (ddfwm_icon.hasClass("text-success")) {

                ddfwm_icon.removeClass("text-success");
                ddfwm_icon.addClass("text-danger");
                jQuery.post(
                    ddfwm_ajax_url, {
                        action: 'ddfwm_ajax',
                        ddfwm_service: ddfwm_service,
                        ddfwm_status: "0",
                        ddfwm_vendor_id: ddfwm_vendor_id,
                        ddfwm_driver_id: ddfwm_driver_id,
                        ddfwm_wpnonce: ddfwm_nonce,
                        ddfwm_data_type: 'html'
                    }
                );
            } else {
                ddfwm_icon.addClass("text-success");
                ddfwm_icon.removeClass("text-danger");

                jQuery.post(
                    ddfwm_ajax_url, {
                        action: 'ddfwm_ajax',
                        ddfwm_service: ddfwm_service,
                        ddfwm_status: "1",
                        ddfwm_vendor_id: ddfwm_vendor_id,
                        ddfwm_driver_id: ddfwm_driver_id,
                        ddfwm_wpnonce: ddfwm_nonce,
                        ddfwm_data_type: 'html'
                    }
                );
            }
            ddfwm_counters();
            return false;
        }
    );

    function scrolltoelement(element) {
        jQuery('html, body').animate({
                scrollTop: element.offset().top
            },
            1000
        );
    }

    jQuery(".ddfwm_form").validate({
        submitHandler: function(form) {
            var ddfwm_form = jQuery(form);
            var ddfwm_loading_btn = ddfwm_form.find(".ddfwm_loading_btn")
            var ddfwm_submit_btn = ddfwm_form.find(".ddfwm_submit_btn")
            var ddfwm_alert_wrap = ddfwm_form.find(".ddfwm_alert_wrap");
            var ddfwm_service = ddfwm_form.attr("service");
            ddfwm_submit_btn.hide();
            ddfwm_loading_btn.show();
            ddfwm_alert_wrap.html("");
            jQuery.ajax({
                type: "POST",
                url: ddfwm_ajax_url,
                data: ddfwm_form.serialize() + '&action=ddfwm_ajax&ddfwm_service=' + ddfwm_service + '&ddfwm_wpnonce=' + ddfwm_nonce + '&ddfwm_data_type=json',
                success: function(data) {
                    try {
                        var ddfwm_json = JSON.parse(data);
                        if (ddfwm_json["result"] == "0") {
                            ddfwm_alert_wrap.html("<div class=\"alert alert-warning alert-dismissible fade show\" role=\"alert\">" + ddfwm_json["error"] + "</div>");
                            ddfwm_submit_btn.show();
                            ddfwm_loading_btn.hide();
                            scrolltoelement(ddfwm_alert_wrap);
                        }
                        if (ddfwm_json["result"] == "1") {
                            var ddfwm_hide_on_success = ddfwm_form.find(".ddfwm_hide_on_success");
                            if (ddfwm_hide_on_success.length) {
                                ddfwm_hide_on_success.replaceWith("");
                            }
                            ddfwm_alert_wrap.html("<div class=\"alert alert-success alert-dismissible fade show\" role=\"alert\">" + ddfwm_json["error"] + "</div>");
                            ddfwm_submit_btn.show();
                            ddfwm_loading_btn.hide();
                            scrolltoelement(ddfwm_alert_wrap);
                        }

                    } catch (e) {
                        ddfwm_alert_wrap.html("<div class=\"alert alert-warning alert-dismissible fade show\" role=\"alert\">" + e + "</div>");
                        ddfwm_submit_btn.show();
                        ddfwm_loading_btn.hide();
                        scrolltoelement(ddfwm_alert_wrap);
                    }
                },
                error: function(request, status, error) {
                    ddfwm_alert_wrap.html("<div class=\"alert alert-warning alert-dismissible fade show\" role=\"alert\">" + e + "</div>");
                    ddfwm_submit_btn.show();
                    ddfwm_loading_btn.hide();
                    scrolltoelement(ddfwm_alert_wrap);
                }
            });

            return false;
        }
    });

    $("#ddfwm_orders_status").change(
        function() {
            $(".ddfwm_dates_range_col").hide();
            if ($(this).val() == $("#ddfwm_orders_status option:last").val()) {
                $(".ddfwm_dates_range_col").show();
            }
        }
    );

    $("#ddfwm_multi_checkbox").click(
        function() {
            var ddfwm_chk_class = jQuery(this).attr("data");
            if ($(this).prop("checked") == true) {
                $('.' + ddfwm_chk_class).each(
                    function() {
                        $(this).prop("checked", true);
                    }
                );
            } else {
                $('.' + ddfwm_chk_class).each(
                    function() {
                        $(this).prop("checked", false);
                    }
                );
            }

        }
    );

    jQuery(".ddfwm_multi_checkbox .ddfwm_wrap").click(
        function() {
            var ddfwm_chk = jQuery(this).find(".custom-control-input");
            if (ddfwm_chk.prop("checked") == true) {
                jQuery(this).parents(".ddfwm_multi_checkbox").removeClass("ddfwm_active");
                ddfwm_chk.prop("checked", false);
            } else {
                jQuery(this).parents(".ddfwm_multi_checkbox").addClass("ddfwm_active");
                ddfwm_chk.prop("checked", true);
            }
        }
    );

    jQuery("#ddfwm_start").click(
        function() {
            jQuery("#ddfwm_home").hide();
            jQuery("#ddfwm_login").show();
        }
    );

    jQuery("#ddfwm_login_button").click(
        function() {
            // hide the sign up button
            jQuery("#ddfwm_signup_button").hide();
            // show the login form
            jQuery("#ddfwm_login_wrap").toggle();
            return false;
        }
    );

    /*
    	jQuery("#ddfwm_dates_range").change(
    		function() {
    			var ddfwm_location = jQuery(this).attr("data") + '&ddfwm_dates=' + this.value;
    			window.location.replace(ddfwm_location);
    			return false;
    		}
    	);
    */
    if (ddfwm_dates != "") {
        jQuery("#ddfwm_dates_range").val(ddfwm_dates);
    }

    function ddfwm_delivered_screen_open() {
        jQuery("#ddfwm_vendor_complete_btn").show();
        jQuery(".ddfwm_page_content").hide();
        jQuery("#ddfwm_delivery_signature").hide();
        jQuery("#ddfwm_delivery_photo").hide();
        jQuery("#ddfwm_delivered_form").hide();
        jQuery("#ddfwm_failed_delivery_form").hide();
        jQuery(".delivery_proof_bar a").removeClass("active");
        jQuery(".delivery_proof_bar a").eq(0).addClass("active");
    }

    jQuery("#ddfwm_delivered_screen_btn").click(
        function() {
            jQuery("#ddfwm_vendor_complete_btn").attr("delivery", "success");
            jQuery(".delivery_proof_notes").attr("href", "ddfwm_delivered_form");
            ddfwm_delivered_screen_open();
            jQuery("#ddfwm_delivered_form").show();
            jQuery("#ddfwm_delivery_screen").show();
            return false;
        }
    );

    jQuery("#ddfwm_failed_delivered_screen_btn").click(
        function() {
            jQuery("#ddfwm_vendor_complete_btn").attr("delivery", "failed");
            jQuery(".delivery_proof_notes").attr("href", "ddfwm_failed_delivery_form");
            ddfwm_delivered_screen_open();
            jQuery("#ddfwm_failed_delivery_form").show();
            jQuery("#ddfwm_delivery_screen").show();
            return false;
        }
    );

    jQuery(".ddfwm_dashboard .ddfwm_box a").click(
        function() {
            jQuery(this).parent().addClass("ddfwm_active");
        }
    );

    jQuery(".ddfwm_confirmation .ddfwm_cancel").click(
        function() {
            jQuery(".ddfwm_page_content").show();
            jQuery(this).parents(".ddfwm_lightbox").hide();
            return false;
        }
    );

    if (jQuery("#ddfwm_delivered_form .custom-control.custom-radio").length == 1) {
        jQuery("#ddfwm_delivered_form .custom-control.custom-radio").hide();
    }
    if (jQuery("#ddfwm_failed_delivery_form .custom-control.custom-radio").length == 1) {
        jQuery("#ddfwm_failed_delivery_form .custom-control.custom-radio").hide();
    }

    jQuery("#ddfwm_vendor_complete_btn").click(
        function() {
            jQuery("#ddfwm_delivery_screen").hide();
            if (jQuery(this).attr("delivery") == "success") {
                jQuery("#ddfwm_delivered_confirmation").show();
            } else {
                jQuery("#ddfwm_failed_delivery_confirmation").show();
            }
            return false;
        }
    );
    jQuery("#ddfwm_failed_delivery_confirmation .ddfwm_ok").click(
        function() {

            var ddfwm_reason = jQuery('input[name=ddfwm_delivery_failed_reason]:checked', '#ddfwm_failed_delivery_form');
            if (ddfwm_reason.attr("id") != "ddfwm_delivery_failed_6") {
                jQuery("#ddfwm_vendor_note").val(ddfwm_reason.val());
            }

            jQuery("#ddfwm_failed_delivery").hide();
            jQuery("#ddfwm_thankyou").show();

            var ddfwm_orderid = jQuery("#ddfwm_vendor_complete_btn").attr("order_id");

            var ddfwm_signature = '';
            var ddfwm_delivery_image = '';
            /* <fs_premium_only> */
            ddfwm_signature = ddfwm_get_signature();
            ddfwm_resizeImage(ddfwm_signature, 640, 640).then(
                (result) => {
                    ddfwm_signature = result;
                }
            );
            ddfwm_delivery_image = jQuery('#delivery_image').val();
            /* </fs_premium_only> */

            jQuery.ajax({
                type: "POST",
                url: ddfwm_ajax_url,
                data: {
                    action: 'ddfwm_ajax',
                    ddfwm_service: 'ddfwm_status',
                    ddfwm_order_id: ddfwm_orderid,
                    ddfwm_order_status: jQuery("#ddfwm_vendor_complete_btn").attr("failed_status"),
                    ddfwm_vendor_id: ddfwm_vendor_id,
                    ddfwm_note: jQuery("#ddfwm_vendor_note").val(),
                    ddfwm_wpnonce: ddfwm_nonce,
                    ddfwm_data_type: 'html',
                    ddfwm_signature: ddfwm_signature,
                    ddfwm_delivery_image: ddfwm_delivery_image
                },
                success: function(data) {
                    /* <fs_premium_only> */
                    ddfwm_next_delivery_service();
                    /* </fs_premium_only> */
                },
                error: function(request, status, error) {}
            });

            return false;
        }
    );

    jQuery("#ddfwm_delivered_form input[type=radio]").click(
        function() {
            jQuery("#ddfwm_vendor_delivered_note").val("");
            if (jQuery(this).attr("id") == "ddfwm_delivery_dropoff_other") {
                jQuery("#ddfwm_vendor_delivered_note_wrap").show();
            } else {
                jQuery("#ddfwm_vendor_delivered_note_wrap").hide();
            }
        }
    );

    jQuery("#ddfwm_failed_delivery_form input[type=radio]").click(
        function() {
            jQuery("#ddfwm_vendor_note").val("");
            if (jQuery(this).attr("id") == "ddfwm_delivery_failed_6") {
                jQuery("#ddfwm_vendor_note_wrap").show();
            } else {
                jQuery("#ddfwm_vendor_note_wrap").hide();
            }
        }
    );

    jQuery(".ddfwm_lightbox_close,#ddfwm_vendor_cancel_btn").click(
        function() {
            jQuery(".ddfwm_page_content").show();
            jQuery(this).parents(".ddfwm_lightbox").hide();
            return false;
        }
    );

    jQuery("#ddfwm_login_frm").submit(
        function(e) {
            e.preventDefault();

            var ddfwm_form = jQuery(this);
            var ddfwm_loading_btn = ddfwm_form.find(".ddfwm_loading_btn")
            var ddfwm_submit_btn = ddfwm_form.find(".ddfwm_submit_btn")
            var ddfwm_alert_wrap = ddfwm_form.find(".ddfwm_alert_wrap");

            var ddfwm_nextpage = ddfwm_form.attr('nextpage');

            ddfwm_submit_btn.hide();
            ddfwm_loading_btn.show();
            ddfwm_alert_wrap.html("");

            jQuery.ajax({
                type: "POST",
                url: ddfwm_ajax_url,
                data: {
                    action: 'ddfwm_ajax',
                    ddfwm_service: 'ddfwm_login',
                    ddfwm_login_email: jQuery("#ddfwm_login_email").val(),
                    ddfwm_login_password: jQuery("#ddfwm_login_password").val(),
                    ddfwm_wpnonce: ddfwm_nonce,
                    ddfwm_data_type: 'json'
                },
                success: function(data) {
                    var ddfwm_json = JSON.parse(data);
                    if (ddfwm_json["result"] == "0") {
                        ddfwm_alert_wrap.html("<div class=\"alert alert-warning alert-dismissible fade show\" role=\"alert\">" + ddfwm_json["error"] + "</div>");
                        ddfwm_submit_btn.show();
                        ddfwm_loading_btn.hide();
                    }
                    if (ddfwm_json["result"] == "1") {
                        window.location.replace(ddfwm_nextpage);
                    }
                },
                error: function(request, status, error) {
                    ddfwm_alert_wrap.html("<div class=\"alert alert-warning alert-dismissible fade show\" role=\"alert\">" + status + ' ' + error + "</div>");
                    ddfwm_submit_btn.show();
                    ddfwm_loading_btn.hide();
                }
            });
            return false;
        }
    );

    jQuery("#ddfwm_back_to_forgot_password_link").click(
        function() {
            jQuery(".ddfwm_page").hide();
            jQuery("#ddfwm_forgot_password").show();
        }
    );
    jQuery("#ddfwm_login_button").click(
        function() {
            jQuery(".ddfwm_page").hide();
            jQuery("#ddfwm_login").show();
        }
    );
    jQuery("#ddfwm_new_password_login_link").click(
        function() {
            jQuery(".ddfwm_page").hide();
            jQuery("#ddfwm_login").show();
        }
    );
    jQuery("#ddfwm_new_password_reset_link").click(
        function() {
            jQuery("#ddfwm_create_new_password").hide();
            jQuery("#ddfwm_forgot_password").show();
        }
    );
    jQuery("#ddfwm_forgot_password_link").click(
        function() {
            jQuery("#ddfwm_login").hide();
            jQuery("#ddfwm_forgot_password").show();
        }
    );
    jQuery(".ddfwm_back_to_login_link").click(
        function() {
            jQuery(".ddfwm_page").hide();
            jQuery("#ddfwm_login").show();

        }
    );
    jQuery("#ddfwm_resend_button").click(
        function() {
            jQuery(".ddfwm_page").hide();
            jQuery("#ddfwm_forgot_password").show();
        }
    );
    jQuery("#ddfwm_application_link").click(
        function() {
            jQuery(".ddfwm_page").hide();
            jQuery("#ddfwm_application").show();
        }
    );

    jQuery("#ddfwm_forgot_password_frm").submit(
        function(e) {
            e.preventDefault();

            var ddfwm_form = jQuery(this);
            var ddfwm_loading_btn = ddfwm_form.find(".ddfwm_loading_btn");
            var ddfwm_submit_btn = ddfwm_form.find(".ddfwm_submit_btn");
            var ddfwm_alert_wrap = ddfwm_form.find(".ddfwm_alert_wrap");

            ddfwm_submit_btn.hide();
            ddfwm_loading_btn.show();
            ddfwm_alert_wrap.html("");

            var ddfwm_nextpage = ddfwm_form.attr('nextpage');
            jQuery.ajax({
                type: "POST",
                url: ddfwm_ajax_url,
                data: {
                    action: 'ddfwm_ajax',
                    ddfwm_service: 'ddfwm_forgot_password',
                    ddfwm_user_email: jQuery("#ddfwm_user_email").val(),
                    ddfwm_wpnonce: ddfwm_nonce,
                    ddfwm_data_type: 'json'

                },
                success: function(data) {
                    var ddfwm_json = JSON.parse(data);

                    if (ddfwm_json["result"] == "0") {
                        ddfwm_alert_wrap.html("<div class=\"alert alert-warning alert-dismissible fade show\" role=\"alert\">" + ddfwm_json["error"] + "</div>");
                        ddfwm_submit_btn.show();
                        ddfwm_loading_btn.hide();
                    }
                    if (ddfwm_json["result"] == "1") {
                        jQuery(".ddfwm_page").hide();
                        jQuery("#ddfwm_forgot_password_email_sent").show();

                        ddfwm_submit_btn.show();
                        ddfwm_loading_btn.hide();
                    }
                },
                error: function(request, status, error) {
                    ddfwm_submit_btn.show();
                    ddfwm_loading_btn.hide();
                }
            });
            return false;
        }
    );

    jQuery("#ddfwm_new_password_frm").submit(
        function(e) {
            e.preventDefault();

            var ddfwm_form = jQuery(this);
            var ddfwm_loading_btn = ddfwm_form.find(".ddfwm_loading_btn");
            var ddfwm_submit_btn = ddfwm_form.find(".ddfwm_submit_btn");
            var ddfwm_alert_wrap = ddfwm_form.find(".ddfwm_alert_wrap");

            ddfwm_submit_btn.hide();
            ddfwm_loading_btn.show();
            ddfwm_alert_wrap.html("");

            var ddfwm_nextpage = ddfwm_form.attr('nextpage');
            jQuery.ajax({
                type: "POST",
                url: ddfwm_ajax_url,
                data: {
                    action: 'ddfwm_ajax',
                    ddfwm_service: 'ddfwm_newpassword',
                    ddfwm_new_password: jQuery("#ddfwm_new_password").val(),
                    ddfwm_confirm_password: jQuery("#ddfwm_confirm_password").val(),
                    ddfwm_reset_key: jQuery("#ddfwm_reset_key").val(),
                    ddfwm_reset_login: jQuery("#ddfwm_reset_login").val(),
                    ddfwm_wpnonce: ddfwm_nonce,
                    ddfwm_data_type: 'json'
                },

                success: function(data) {
                    var ddfwm_json = JSON.parse(data);
                    if (ddfwm_json["result"] == "0") {
                        ddfwm_alert_wrap.html("<div class=\"alert alert-warning alert-dismissible fade show\" role=\"alert\">" + ddfwm_json["error"] + "</div>");
                        ddfwm_submit_btn.show();
                        ddfwm_loading_btn.hide();
                    }
                    if (ddfwm_json["result"] == "1") {
                        jQuery(".ddfwm_page").hide();
                        jQuery("#ddfwm_new_password_created").show();

                    }
                },
                error: function(request, status, error) {
                    ddfwm_submit_btn.show();
                    ddfwm_loading_btn.hide();
                }
            });
            return false;
        }
    );

    jQuery("body").on(
        "click",
        "#ddfwm_orders_table .ddfwm_box a",
        function() {
            jQuery(this).closest(".ddfwm_box").addClass("ddfwm_active");
        }
    );
    /* <fs_premium_only> */
    jQuery("body").on(
        "click",
        "#delivery-image-clear",
        function() {
            jQuery("#delivery_image_wrap").html("");
            jQuery("#delivery_image").val("");
            return false;
        }
    );
    /* </fs_premium_only> */

})(jQuery);

function ddfwm_openNav() {
    jQuery(".ddfwm_page_content").hide();
    document.getElementById("ddfwm_mySidenav").style.width = "100%";
}

function ddfwm_closeNav() {
    jQuery(".ddfwm_page_content").show();
    document.getElementById("ddfwm_mySidenav").style.width = "0";
}


function ddfwm_resizeImage(base64Str, maxWidth = 1000, maxHeight = 1000) {
    return new Promise(
        (resolve) => {
            let ddfwm_img = new Image()
            ddfwm_img.src = base64Str
            ddfwm_img.onload = () => {
                let ddfwm_image_canvas = document.createElement('canvas')
                const MAX_WIDTH = maxWidth
                const MAX_HEIGHT = maxHeight
                let ddfwm_width = ddfwm_img.width
                let ddfwm_height = ddfwm_img.height

                if (ddfwm_width > ddfwm_height) {
                    if (ddfwm_width > MAX_WIDTH) {
                        ddfwm_height *= MAX_WIDTH / ddfwm_width
                        ddfwm_width = MAX_WIDTH
                    }
                } else {
                    if (ddfwm_height > MAX_HEIGHT) {
                        ddfwm_width *= MAX_HEIGHT / ddfwm_height
                        ddfwm_height = MAX_HEIGHT
                    }
                }
                ddfwm_image_canvas.width = ddfwm_width
                ddfwm_image_canvas.height = ddfwm_height
                let ddfwm_ctx = ddfwm_image_canvas.getContext('2d')
                ddfwm_ctx.drawImage(ddfwm_img, 0, 0, ddfwm_width, ddfwm_height)
                resolve(ddfwm_image_canvas.toDataURL())
            }
        }
    )
}

function ddfwm_resizeCanvas() {
    if (ddfwm_signaturePad.isEmpty()) {
        var ddfwm_ratio = Math.max(window.devicePixelRatio || 1, 1);
        ddfwm_canvas.width = ddfwm_canvas.offsetWidth;
        ddfwm_canvas.height = ddfwm_canvas.offsetHeight;
        ddfwm_canvas.getContext("2d").scale(1, 1);
        ddfwm_signaturePad.clear();
    }
}

if (jQuery("#signature-pad").length) {
    var ddfwm_canvas = document.getElementById('signature-pad');
    var ddfwm_signaturePad = new SignaturePad(
        ddfwm_canvas, {
            backgroundColor: '#ffffff'
        }
    );

    jQuery(".signature-clear").click(
        function() {
            jQuery("#signature-image").html("");
            ddfwm_signaturePad.clear();
            ddfwm_resizeCanvas();
            return false;
        }
    );

    window.onresize = ddfwm_resizeCanvas;
    ddfwm_resizeCanvas();
}

jQuery(".ddfwm_upload_image").change(
    function(e) {
        var $this = jQuery(this);
        if (this.files && this.files[0]) {
            var ddfwm_reader = new FileReader();
            ddfwm_reader.onload = function(e) {
                ddfwm_resizeImage(e.target.result, 640, 640).then(
                    (result) => {
                        $this.parents(".upload_image_form").find(".upload_image_wrap").html("<span class='ddfwm_helper'></span><img src='" + result + "'>");
                        $this.parent().find(".ddfwm_image_input").val(result);
                    }
                );
            }
            ddfwm_reader.readAsDataURL(this.files[0]);
        }
    }
);

function ddfwm_driver_commission_type() {
    jQuery("#ddfwm_driver_commission_symbol_currency").hide();
    jQuery("#ddfwm_driver_commission_symbol_percentage").hide();
    var $ddfwm_val = jQuery("#ddfwm_driver_commission_type").val();
    if ($ddfwm_val == "") {
        jQuery("#ddfwm_driver_commission_value_wrap").hide();
        jQuery("#ddfwm_driver_commission_value").val("");
    } else {
        jQuery("#ddfwm_driver_commission_value_wrap").show();
        if ($ddfwm_val == "fixed") {
            jQuery("#ddfwm_driver_commission_symbol_currency").show();
        } else {
            jQuery("#ddfwm_driver_commission_symbol_percentage").show();
        }
    }
}

jQuery("#ddfwm_driver_commission_type").change(
    function() {
        ddfwm_driver_commission_type()
    }
);

if (jQuery("#ddfwm_driver_commission_type").length) {
    ddfwm_driver_commission_type();
}

jQuery(".ddfwm_user_icon_disable").click(
    function() {
        return false;
    }
);