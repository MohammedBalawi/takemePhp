<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'WooCommerce' ) ) {
	die( esc_html( __( 'Delivery drivers for vendors is a WooCommerce add-on, you must activate a WooCommerce on your site.', 'ddfwm' ) ) );
}

if ( ! ddfwm_fs_is_parent_active_and_loaded() ) {
	die( esc_html( __( 'Delivery drivers for vendors is a local delivery drivers for woocommerce premium add-on, you must activate it on your site.', 'ddfwm' ) ) );
}


/**
 * Get WordPress query_var.
 */
$ddfwm_screen      = ( '' !== get_query_var( 'ddfwm_screen' ) ) ? get_query_var( 'ddfwm_screen' ) : 'dashboard';
$ddfwm_order_id    = get_query_var( 'ddfwm_orderid' );
$ddfwm_reset_key   = get_query_var( 'ddfwm_reset_key' );
$ddfwm_page        = ( '' !== get_query_var( 'ddfwm_page' ) ) ? get_query_var( 'ddfwm_page' ) : '1';
$ddfwm_reset_login = get_query_var( 'ddfwm_reset_login' );
$ddfwm_dates       = get_query_var( 'ddfwm_dates' );
$ddfwm_driverid    = get_query_var( 'ddfwm_driverid' );
$ddfwm_status      = get_query_var( 'ddfwm_status' );




/**
 * Set global variables.
*/
$ddfwm_vendor         = new DDFWM_Vendor();
$ddfwm_screens        = new DDFWM_Screens();
$ddfwm_content        = '';
$ddfwm_vendor_id      = '';
$ddfwm_vendor_drivers = '';

/**
 * Log out vendor.
*/
if ( 'logout' === $ddfwm_screen ) {
	DDFWM_Login::ddfwm_logout();
}


/**
 * Check if user is logged in.
*/
if ( ! is_user_logged_in() ) {
	$ddfwm_content = $ddfwm_screens->ddfwm_home();
} else {
	// Check if user is a vendor.
	$ddfwm_user           = wp_get_current_user();
	$ddfwm_vendor_id      = $ddfwm_user->ID;
	$ddfwm_vendor_account = get_user_meta( $ddfwm_vendor_id, 'ddfwm_vendor_account', true );
	$ddfwm_vendor_drivers = get_user_meta( $ddfwm_vendor_id, 'ddfwm_vendor_drivers', true );




	if ( ! in_array( ddfwm_vendor_role(), (array) $ddfwm_user->roles, true ) || '1' !== $ddfwm_vendor_account ) {
		DDFWM_Login::ddfwm_logout();
		// User is not a vendor.
		$ddfwm_user_is_vendor = 0;
		$ddfwm_content        = $ddfwm_screens->ddfwm_home();
	} else {
		/**
		 * User is a vendor.
		 */

		// Set global variables.
		$ddfwm_user_is_vendor = 1;
		$ddfwm_vendor_name    = $ddfwm_user->display_name;

		// Get the number of orders in each status.
		$ddfwm_orders                   = new DDFWM_Orders();
		$ddfwm_array                    = $ddfwm_orders->ddfwm_orders_count_query( $ddfwm_vendor_id );
		$ddfwm_out_for_delivery_counter = 0;
		$ddfwm_failed_attempt_counter   = 0;
		$ddfwm_delivered_counter        = 0;
		$ddfwm_assign_to_driver_counter = 0;
		$ddfwm_claim_orders_counter     = 0;

		/**
		 * Set current status names
		 */
		$ddfwm_vendor_assigned_status_name  = esc_html( __( 'Driver assigned', 'ddfwm' ) );
		$ddfwm_out_for_delivery_status_name = esc_html( __( 'Out for delivery', 'ddfwm' ) );
		$ddfwm_failed_attempt_status_name   = esc_html( __( 'Failed delivery', 'ddfwm' ) );
		if ( function_exists( 'wc_get_order_statuses' ) ) {
			$result = wc_get_order_statuses();
			if ( ! empty( $result ) ) {
				foreach ( $result as $key => $status_name ) {
					switch ( $key ) {
						case get_option( 'ddfwm_out_for_delivery_status' ):
							if ( $status_name !== $ddfwm_out_for_delivery_status_name ) {
								$ddfwm_out_for_delivery_status_name = $status_name;
							}
							break;
						case get_option( 'ddfwm_failed_attempt_status' ):
							if ( esc_html( __( 'Failed Delivery Attempt', 'ddfwm' ) ) !== $status_name ) {
								$ddfwm_failed_attempt_status_name = $status_name;
							}
							break;
						case get_option( 'ddfwm_vendor_assigned_status' ):
							if ( $status_name !== $ddfwm_vendor_assigned_status_name ) {
								$ddfwm_vendor_assigned_status_name = $status_name;
							}
							break;
					}
				}
			}
		}


		foreach ( $ddfwm_array as $row ) {

			switch ( $row->post_status ) {
				case get_option( 'ddfwm_out_for_delivery_status' ):
					$ddfwm_out_for_delivery_counter = $row->orders;
					break;
				case get_option( 'ddfwm_failed_attempt_status' ):
					$ddfwm_failed_attempt_counter = $row->orders;
					break;
				case get_option( 'ddfwm_delivered_status' ):
					$ddfwm_delivered_counter = $row->orders;
					break;
				case get_option( 'ddfwm_vendor_assigned_status' ):
					$ddfwm_assign_to_driver_counter = $row->orders;
					break;
			}
		}



		/**
		 * Vendor screens.
		*/
		if ( 'dashboard' === $ddfwm_screen ) {
			$ddfwm_content = $ddfwm_screens->ddfwm_dashboard_screen( $ddfwm_vendor_id );
		}

		if ( 'reports' === $ddfwm_screen ) {
			$ddfwm_content = $ddfwm_screens->ddfwm_reports_screen( $ddfwm_vendor_id );
		}

		if ( ddfwm_fs()->is__premium_only() ) {
			if ( ddfwm_fs()->is_plan( 'premium', true ) ) {
			if ( 'newdriver' === $ddfwm_screen && ( '1' === $ddfwm_vendor_drivers || '2' === $ddfwm_vendor_drivers ) ) {
				$ddfwm_content = $ddfwm_screens->ddfwm_new_driver_screen( $ddfwm_vendor_id );
				}
			}
		}

		if ( 'driver' === $ddfwm_screen && '' !== $ddfwm_driverid ) {
			$ddfwm_content = $ddfwm_screens->ddfwm_driver_screen( $ddfwm_vendor_id, $ddfwm_driverid );
		}

		if ( 'drivers' === $ddfwm_screen ) {
			$ddfwm_content = $ddfwm_screens->ddfwm_drivers_screen( $ddfwm_vendor_id );
		}

		if ( 'orders' === $ddfwm_screen ) {
			$ddfwm_content = $ddfwm_screens->ddfwm_orders_screen( $ddfwm_vendor_id );
		}

		if ( 'order' === $ddfwm_screen && '' !== $ddfwm_order_id ) {
			$ddfwm_content = $ddfwm_screens->ddfwm_order_screen( $ddfwm_vendor_id );
		}

		if ( 'settings' === $ddfwm_screen ) {
			$ddfwm_content = $ddfwm_screens->ddfwm_settings_screen( $ddfwm_vendor_id );
		}
	}
}
	/**
	 * Register scripts and css files
	 */
	wp_register_script( 'ddfwm-jquery-validate', plugin_dir_url( __FILE__ ) . 'public/js/jquery.validate.min.js', array( 'jquery', 'jquery-ui-core', 'jquery-ui-datepicker' ), DDFWM_VERSION, true );
	wp_register_script( 'ddfwm-bootstrap', plugin_dir_url( __FILE__ ) . 'public/js/bootstrap.min.js', array(), DDFWM_VERSION, false );
if ( ddfwm_fs()->is__premium_only() ) {
	if ( ddfwm_fs()->is_plan( 'premium', true ) ) {
		wp_register_script( 'ddfwm-signature', plugin_dir_url( __FILE__ ) . 'public/js/signature_pad.min.js', array(), DDFWM_VERSION, false );
	}
}
	wp_register_script( 'ddfwm-public', plugin_dir_url( __FILE__ ) . 'public/js/ddfwm-public.js', array(), DDFWM_VERSION, false );

	wp_register_script( 'wc-country-select', plugins_url() . '/woocommerce/assets/js/frontend/country-select.min.js', array( 'jquery' ), DDFWM_VERSION, false );

	wp_register_style( 'ddfwm-jquery-ui', plugin_dir_url( __FILE__ ) . 'public/css/jquery-ui.css', array(), DDFWM_VERSION, 'all' );
	wp_register_style( 'ddfwm-bootstrap', plugin_dir_url( __FILE__ ) . 'public/css/bootstrap.min.css', array(), DDFWM_VERSION, 'all' );
	wp_register_style( 'ddfwm-fonts', 'https://fonts.googleapis.com/css?family=Open+Sans|Roboto&display=swap', array(), DDFWM_VERSION, 'all' );
	wp_register_style( 'ddfwm-public', plugin_dir_url( __FILE__ ) . 'public/css/ddfwm-public.css', array(), DDFWM_VERSION, 'all' );




?>
<!DOCTYPE html>
<html>
<head>
<?php
	echo '<title>' . esc_js( __( 'vendor', 'ddfwm' ) ) . '</title>';
?>
<meta name="robots" content="noindex" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="<?php echo esc_url( get_site_icon_url( 32, esc_url( plugin_dir_url( __FILE__ ) . 'public/images/favicon-32x32.png?ver=' . DDFWM_VERSION ) ) ); ?>" >
<?php
	wp_print_styles( array( 'ddfwm-fonts', 'ddfwm-bootstrap', 'ddfwm-public', 'ddfwm-jquery-ui' ) );

if ( is_rtl() === true ) {
	wp_register_style( 'ddfwm-public-rtl', plugin_dir_url( __FILE__ ) . 'public/css/ddfwm-public-rtl.css', array(), DDFWM_VERSION, 'all' );
	wp_print_styles( array( 'ddfwm-public-rtl' ) );
}

	wp_print_scripts( array( 'ddfwm-jquery-validate' ) );



?>
<?php
echo '<script>
	var ddfwm_vendor_id = "' . esc_js( $ddfwm_vendor_id ) . '";
	var ddfwm_ajax_url = "' . esc_url( admin_url( 'admin-ajax.php' ) ) . '";
	var ddfwm_confirm_text = "' . esc_js( __( 'Are you sure?', 'ddfwm' ) ) . '";
	var ddfwm_nonce = "' . esc_js( wp_create_nonce( 'ddfwm-nonce' ) ) . '";
	var ddfwm_hour_text = "' . esc_js( __( 'hour', 'ddfwm' ) ) . '";
	var ddfwm_hours_text = "' . esc_js( __( 'hours', 'ddfwm' ) ) . '";
	var ddfwm_mins_text = "' . esc_js( __( 'mins', 'ddfwm' ) ) . '";
	var ddfwm_dates = "' . esc_js( $ddfwm_dates ) . '";
</script>';

if ( ddfwm_fs()->is__premium_only() ) {
	if ( ddfwm_fs()->is_plan( 'premium', true ) ) {
		/**
		 * Branding
		 */
		$ddfwm_branding_background        = esc_attr( get_option( 'ddfwm_branding_background', '' ) );
		$ddfwm_branding_text_color        = esc_attr( get_option( 'ddfwm_branding_text_color', '' ) );
		$ddfwm_branding_button_color      = esc_attr( get_option( 'ddfwm_branding_button_color', '' ) );
		$ddfwm_branding_button_background = esc_attr( get_option( 'ddfwm_branding_button_background', '' ) );
		echo '<style>';
		if ( '' !== $ddfwm_branding_background ) {
			echo '#ddfwm_home .ddfwm_cover , #ddfwm_home { background-color:' . esc_attr( $ddfwm_branding_background ) . '; }';
		}
		if ( '' !== $ddfwm_branding_text_color ) {
			echo '#ddfwm_home h1 , #ddfwm_home {  color:' . esc_attr( $ddfwm_branding_text_color ) . '; }';
		}
		if ( '' !== $ddfwm_branding_button_color ) {
			echo '#ddfwm_start { color:' . esc_attr( $ddfwm_branding_button_color ) . '; }';
		}
		if ( '' !== $ddfwm_branding_button_background ) {
			echo '#ddfwm_start { border-color: ' . esc_attr( $ddfwm_branding_button_background ) . '; background-color:' . esc_attr( $ddfwm_branding_button_background ) . '; }';
		}
		echo '</style>';
	}
}
?>


</head>
<body>
	<div id="ddfwm_page" class="<?php echo esc_attr( $ddfwm_screen ); ?>" >
	<?php
	if ( 'routes' === $ddfwm_screen ) {
		 $ddfwm_screens->ddfwm_routes_screen( $ddfwm_vendor_id );
	} else {
		echo $ddfwm_content;
	}
	?>
	</div>
<?php

		wp_print_scripts( array( 'wc-country-select', 'ddfwm-bootstrap', 'ddfwm-signature', 'ddfwm-public' ) );

?>
</body>
</html>
