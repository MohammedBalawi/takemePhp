jQuery( document ).ready(
	function($) {

		function ddfwm_dates_range() {
			var $ddfwm_this = $( "#ddfwm_dates_range" );
			if ($ddfwm_this.val() == "custom") {
				$( "#ddfwm_dates_custom_range" ).show();
			} else {
				var ddfwm_fromdate = $( 'option:selected', $ddfwm_this ).attr( 'fromdate' );
				var ddfwm_todate   = $( 'option:selected', $ddfwm_this ).attr( 'todate' );
				$( "#ddfwm_dates_custom_range" ).hide();
				$( "#ddfwm_dates_range_from" ).val( ddfwm_fromdate );
				$( "#ddfwm_dates_range_to" ).val( ddfwm_todate );
			}
		}

		$( "#ddfwm_dates_range" ).change(
			function() {
				ddfwm_dates_range()
			}
		);

		if ($( "#ddfwm_dates_range" ).length) {
			ddfwm_dates_range();
		}

		function ddfwm_vendor_commission_type() {
			$( "#ddfwm_vendor_commission_symbol_currency" ).hide();
			$( "#ddfwm_vendor_commission_symbol_percentage" ).hide();
			var $ddfwm_val = $( "#ddfwm_vendor_commission_type" ).val();
			if ($ddfwm_val == "") {
				$( "#ddfwm_vendor_commission_value_wrap" ).hide();
				$( "#ddfwm_vendor_commission_value" ).val( "" );
			} else {
				$( "#ddfwm_vendor_commission_value_wrap" ).show();
				if ($ddfwm_val == "fixed") {
					$( "#ddfwm_vendor_commission_symbol_currency" ).show();
				} else {
					$( "#ddfwm_vendor_commission_symbol_percentage" ).show();
				}
			}
		}

		$( "#ddfwm_vendor_commission_type" ).change(
			function() {
				ddfwm_vendor_commission_type()
			}
		);

		if ($( "#ddfwm_vendor_commission_type" ).length) {
			ddfwm_vendor_commission_type();
		}

		$( ".ddfwm_media_delete" ).click(
			function() {
				var ddfwm_object_id = $( this ).attr( "data" );
				$( "#" + ddfwm_object_id ).val( "" );
				$( "#" + ddfwm_object_id + "_preview" ).html( "" );
			}
		);

		$( '.ddfwm_media_manager' ).click(
			function(e) {
				var ddfwm_object_id = $( this ).attr( "data" );
				e.preventDefault();
				var ddfwm_image_frame;
				if (ddfwm_image_frame) {
					ddfwm_image_frame.open();
				}
				// Define image_frame as wp.media object
				ddfwm_image_frame = wp.media(
					{
						title: 'Select Media',
						multiple: false,
						library: {
							type: 'image',
						}
					}
				);

				ddfwm_image_frame.on(
					'close',
					function() {
						var ddfwm_selection   = ddfwm_image_frame.state().get( 'selection' );
						var ddfwm_gallery_ids = new Array();
						var ddfwm_index       = 0;
						ddfwm_selection.each(
							function(attachment) {
								ddfwm_gallery_ids[ddfwm_index] = attachment['id'];
								ddfwm_index++;
							}
						);
						var ddfwm_ids = ddfwm_gallery_ids.join( "," );
						jQuery( 'input#' + ddfwm_object_id ).val( ddfwm_ids );
						ddfwm_refresh_image( ddfwm_ids, ddfwm_object_id );
					}
				);

				ddfwm_image_frame.on(
					'open',
					function() {
						var ddfwm_selection = ddfwm_image_frame.state().get( 'selection' );
						var ddfwm_ids       = jQuery( 'input#' + ddfwm_object_id ).val().split( ',' );
						ddfwm_ids.forEach(
							function(id) {
								var ddfwm_attachment = wp.media.attachment( id );
								ddfwm_attachment.fetch();
								ddfwm_selection.add( ddfwm_attachment ? [ddfwm_attachment] : [] );
							}
						);

					}
				);

				ddfwm_image_frame.open();
			}
		);

		if ($( ".ddfwm-color-picker" ).length) {
			$( ".ddfwm-color-picker" ).wpColorPicker();
		}
		if ($( ".ddfwm-datepicker" ).length) {
			$( ".ddfwm-datepicker" ).datepicker( { dateFormat: "yy-mm-dd" } );
		}

		$( ".ddfwm_account_icon" ).click(
			function() {
				var ddfwm_vendor_id = $( this ).attr( "vendor_id" );
				if ($( this ).hasClass( "ddfwm_active" )) {
					$( this ).removeClass( "ddfwm_active" );
					$( this ).html( "<i class='ddfwm-toggle-off'></i>" );
					jQuery.post(
						ddfwm_ajax.ajaxurl,
						{
							action: 'ddfwm_ajax',
							ddfwm_service: 'ddfwm_account_status',
							ddfwm_account_status: "0",
							ddfwm_vendor_id: ddfwm_vendor_id,
							ddfwm_wpnonce: ddfwm_nonce.nonce,
							ddfwm_data_type: 'html'
						}
					);
				} else {
					$( this ).addClass( "ddfwm_active" );
					$( this ).html( "<i class='ddfwm-toggle-on'></i>" );
					jQuery.post(
						ddfwm_ajax.ajaxurl,
						{
							action: 'ddfwm_ajax',
							ddfwm_service: 'ddfwm_account_status',
							ddfwm_account_status: "1",
							ddfwm_vendor_id: ddfwm_vendor_id,
							ddfwm_wpnonce: ddfwm_nonce.nonce,
							ddfwm_data_type: 'html'
						}
					);
				}
				return false;
			}
		);

		function checkbox_toggle(element) {
			if ( ! element.is( ':checked' )) {
				element.parent().next().hide();
			} else {
				element.parent().next().show();
			}

		}

		$( ".checkbox_toggle input" ).click(
			function() {
				checkbox_toggle( $( this ) )

			}
		);
		$( ".checkbox_toggle input" ).each(
			function() {
				checkbox_toggle( $( this ) )
			}
		);

		$( ".ddfwm_copy_template_to_textarea" ).click(
			function() {
				var textarea_id = $( this ).parent().parent().find( "textarea" ).attr( "id" );

				var text = $( this ).attr( "data" );
				$( "#" + textarea_id ).val( text );

				return false;
			}
		);

		$( ".ddfwm_copy_tags_to_textarea a" ).click(
			function() {
				var textarea_id = $( this ).parent().attr( "data-textarea" );
				var text        = $( "#" + textarea_id ).val() + $( this ).attr( "data" );
				$( "#" + textarea_id ).val( text );

				return false;
			}
		);

		$( "#ddfwm_custom_fields_new" ).click(
			function() {
				$( "#ddfwm_custom_fields_raw" ).clone().appendTo( "#ddfwm_custom_fields_table" );
				return false;
			}
		);

	}
);




// Ajax request to refresh the image preview
function ddfwm_refresh_image(the_id, div_id) {
	var data = {
		action: 'ddfwm_ajax',
		ddfwm_service: 'ddfwm_set_image',
		ddfwm_image_id: the_id,
		ddfwm_wpnonce: ddfwm_nonce.nonce,
	};
	jQuery.post(
		ajaxurl,
		data,
		function(response) {

			if (response.success === true) {
				jQuery( '#' + div_id + '_preview' ).html( response.data.image );
			}
		}
	);
}
