<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link  http://www.powerfulwp.com
 * @since 1.0.0
 *
 * @package    DDFWM
 * @subpackage DDFWM/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    DDFWM
 * @subpackage DDFWM/admin
 * @author     powerfulwp <cs@powerfulwp.com>
 */
class DDFWM_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since  1.0.0
	 * @access private
	 * @var    string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since  1.0.0
	 * @access private
	 * @var    string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since 1.0.0
	 * @param string $plugin_name The name of this plugin.
	 * @param string $version     The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {
		 $this->plugin_name = $plugin_name;
		$this->version      = $version;
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_styles() {
		/**
		   * This function is provided for demonstration purposes only.
		   *
		   * An instance of this class should be passed to the run() function
		   * defined in DDFWM_Loader as all of the hooks are defined
		   * in that particular class.
		   *
		   * The DDFWM_Loader will then create the relationship
		   * between the defined hooks and the functions defined in this
		   * class.
		   */
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/ddfwm-admin.css', array(), $this->version, 'all' );
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_scripts() {
		 /**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in DDFWM_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The DDFWM_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		$script_array = array( 'jquery' );
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/ddfwm-admin.js', $script_array, $this->version, false );
		wp_localize_script( $this->plugin_name, 'ddfwm_ajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
		wp_localize_script( $this->plugin_name, 'ddfwm_nonce', array( 'nonce' => esc_js( wp_create_nonce( 'ddfwm-nonce' ) ) ) );

	}


	/**
	 * The function that handles ajax requests.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function ddfwm_ajax() {
		$ddfwm_data_type = ( isset( $_POST['ddfwm_data_type'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_data_type'] ) ) : '';
		$ddfwm_obj_id    = ( isset( $_POST['ddfwm_obj_id'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_obj_id'] ) ) : '';
		$ddfwm_service   = ( isset( $_POST['ddfwm_service'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_service'] ) ) : '';
		$ddfwm_vendor_id = ( isset( $_POST['ddfwm_vendor_id'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_vendor_id'] ) ) : '';
		$ddfwm_driver_id = ( isset( $_POST['ddfwm_driver_id'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_driver_id'] ) ) : '';
		$result          = 0;

		/**
		 * Security check.
		 */
		if ( isset( $_POST['ddfwm_wpnonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_POST['ddfwm_wpnonce'] ) );
			if ( ! wp_verify_nonce( $nonce, 'ddfwm-nonce' ) ) {
				$error = esc_js( __( 'Security Check Failure - This alert may occur when you are logged in as an administrator and as a delivery driver on the same browser and the same device. If you want to work on both panels please try to work with two different browsers.', 'ddfwm' ) );
				if ( 'json' === $ddfwm_data_type ) {
					echo '{"result":"' . esc_attr( $result ) . '", "error":"' . $error . '"}';
				} else {
					echo '<div class=\'alert alert-danger alert-dismissible fade show\'>' . esc_html( $error ) . '<button type=\'button\' class=\'close\' data-dismiss=\'alert\' aria-label=\'Close\'><span aria-hidden=\'true\'>&times;</span></button></div>';
				}
				exit;
			}
		}

		/* Update order */
		if ( 'ddfwm_update_order' === $ddfwm_service ) {
			$ddfwm_orders_status  = ( isset( $_POST['ddfwm_orders_status'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_orders_status'] ) ) : '';
			$ddfwm_assign_drivers = ( isset( $_POST['ddfwm_assign_drivers'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_assign_drivers'] ) ) : '';
			$order                = new DDFWM_Order();
			$order->ddfwm_order_update( $ddfwm_obj_id, esc_attr( $ddfwm_vendor_id ), esc_attr( $ddfwm_orders_status ), esc_attr( $ddfwm_assign_drivers ) );
		}

		if ( ddfwm_fs()->is__premium_only() ) {
			if ( ddfwm_fs()->can_use_premium_code() ) {
				/* drivers routes service */
				if ( 'ddfwm_drivers_routes' === $ddfwm_service ) {
					$route = new DDFWM_Route();
					echo $route->ddfwm_drivers_routes__premium_only( $ddfwm_vendor_id );
				}
			}
		}

		/* Login vendor service */
		if ( 'ddfwm_login' === $ddfwm_service ) {
			$login = new DDFWM_Login();
			$login->ddfwm_login_vendor();
		}

		/* Send reset password link */
		if ( 'ddfwm_forgot_password' === $ddfwm_service ) {
			$password = new DDFWM_Password();
			$password->ddfwm_reset_password();
		}

		/* Create a new password*/
		if ( 'ddfwm_newpassword' === $ddfwm_service ) {
			$password = new DDFWM_Password();
			$password->ddfwm_new_password();
		}

		/*
		Log out vendor.
		*/
		if ( 'ddfwm_logout' === $ddfwm_service ) {
			DDFWM_Login::ddfwm_logout();
		}

		/*
		New driver.
		*/
		if ( 'ddfwm_new_driver' === $ddfwm_service ) {
			$driver = new DDFWM_Driver();
			$driver->ddfwm_create_new_driver_service();
		}

		/*
		Edit driver.
		*/
		if ( 'ddfwm_edit_driver' === $ddfwm_service ) {
			$driver = new DDFWM_Driver();
			$driver->ddfwm_edit_driver_service();
		}

		/*
		Edit settings.
		*/
		if ( 'ddfwm_edit_settings' === $ddfwm_service ) {
			$vendor = new DDFWM_Vendor();
			$vendor->ddfwm_edit_settings_service();
		}

		/*
		Set vendor account status.
		*/
		if ( 'ddfwm_account_status' === $ddfwm_service ) {

			$user = wp_get_current_user();

			// Check if user is an administrator.
			if ( in_array( 'administrator', (array) $user->roles, true ) ) {
				$user = get_user_by( 'id', $ddfwm_vendor_id );

				// Check if user has a vendor role.
				if ( in_array( ddfwm_vendor_role(), (array) $user->roles, true ) ) {
					$status = ( isset( $_POST['ddfwm_account_status'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_account_status'] ) ) : '';
					update_user_meta( $ddfwm_vendor_id, 'ddfwm_vendor_account', $status );
					$result = 1;
				}
				echo esc_html( $result );
			}
		}

		/*
		Set driver claim permission.
		*/
		if ( 'ddfwm_driver_account_status' === $ddfwm_service ) {

			$user = wp_get_current_user();

			// Switch to vendor user if administrator is logged in.
			if ( in_array( 'administrator', (array) $user->roles, true ) && '' !== $ddfwm_vendor_id ) {
				$user = get_user_by( 'id', $ddfwm_vendor_id );
			}

			// Check if user has a vendor role.
			if ( in_array( ddfwm_vendor_role(), (array) $user->roles, true ) ) {

				// Check if driver has a driver role.
				$user = get_user_by( 'id', $ddfwm_driver_id );
				if ( in_array( 'driver', (array) $user->roles, true ) ) {

					$status = ( isset( $_POST['ddfwm_status'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_status'] ) ) : '';
					update_user_meta( $ddfwm_driver_id, 'lddfw_driver_account', $status );
					$result = 1;
				}
			}

			echo esc_html( $result );
		}

		/*
		Set driver claim permission.
		*/
		if ( 'ddfwm_claim_permission' === $ddfwm_service ) {

			$user = wp_get_current_user();

			// Switch to vendor user if administrator is logged in.
			if ( in_array( 'administrator', (array) $user->roles, true ) && '' !== $ddfwm_vendor_id ) {
				$user = get_user_by( 'id', $ddfwm_vendor_id );
			}

			// Check if user has a vendor role.
			if ( in_array( ddfwm_vendor_role(), (array) $user->roles, true ) ) {

				// Check if driver has a driver role.
				$user = get_user_by( 'id', $ddfwm_driver_id );
				if ( in_array( 'driver', (array) $user->roles, true ) ) {

					$status = ( isset( $_POST['ddfwm_status'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_status'] ) ) : '';
					update_user_meta( $ddfwm_driver_id, 'lddfw_driver_claim', $status );
					$result = 1;
				}
			}

			echo esc_html( $result );
		}

		/*
		Set driver availability.
		*/
		if ( 'ddfwm_availability' === $ddfwm_service ) {
			$user = wp_get_current_user();

			// Switch to vendor user if administrator is logged in.
			if ( in_array( 'administrator', (array) $user->roles, true ) && '' !== $ddfwm_vendor_id ) {
				$user = get_user_by( 'id', $ddfwm_vendor_id );
			}

			// Check if user has a vendor role.
			if ( in_array( ddfwm_vendor_role(), (array) $user->roles, true ) ) {

				// Check if driver has a driver role.
				$user = get_user_by( 'id', $ddfwm_driver_id );
				if ( in_array( 'driver', (array) $user->roles, true ) ) {

					$status = ( isset( $_POST['ddfwm_status'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_status'] ) ) : '';
					update_user_meta( $ddfwm_driver_id, 'lddfw_driver_availability', $status );
					$result = 1;
				}
			}

			echo esc_html( $result );
		}

		if ( 'ddfwm_get_drivers_list' === $ddfwm_service ) {
			 ddfwm_vendor_drivers_selectbox( DDFWM_Vendor::ddfwm_get_drivers(), '', $ddfwm_obj_id, 'bulk' );
		}

		// Set logo service.
		if ( 'ddfwm_set_image' === $ddfwm_service ) {
			$ddfwm_image_id = ( isset( $_POST['ddfwm_image_id'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_image_id'] ) ) : '';
			if ( '' !== $ddfwm_image_id ) {
				$image = wp_get_attachment_image( filter_input( INPUT_POST, 'ddfwm_image_id', FILTER_VALIDATE_INT ), 'medium', false, array() );
				$data  = array(
					'image' => $image,
				);
				wp_send_json_success( $data );
			} else {
				wp_send_json_error();
			}
		}

		exit;
	}

	/**
	 * Plugin register settings.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function ddfwm_settings_init() {
		 // Get settings tab.
		$tab = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';
		register_setting( 'ddfwm', 'ddfwm_vendors_page' );

		// Admin notices.
		add_action( 'admin_notices', array( $this, 'ddfwm_admin_notices' ) );

		if ( 'ddfwm' === $tab ) {

			// General Settings.
			add_settings_section(
				'ddfwm_setting_section',
				'',
				'',
				'ddfwm'
			);

			add_settings_field(
				'ddfwm_vendors_page',
				__( 'Vendor panel', 'ddfwm' ),
				array( $this, 'ddfwm_vendors_page' ),
				'ddfwm',
				'ddfwm_setting_section'
			);
		}
	}

	/**
	 * Plugin settings.
	 *
	 * @since 1.0.0
	 */
	public function ddfwm_settings() {
		// Get the active tab from the $_GET param.
		$tab = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';

		?>
		<div class="wrap">
			<form action='options.php' method='post'>
				<h1 class="wp-heading-inline"><?php echo esc_html( __( 'General Settings', 'ddfwm' ) ); ?></h1>
				<?php
				  self::ddfwm_admin_plugin_bar();
				if ( ddfwm_fs()->is__premium_only() ) {
					if ( ddfwm_fs()->can_use_premium_code() ) {
						?>
						<nav class="nav-tab-wrapper">
							<a href="?page=ddfwm-settings" class="nav-tab 
							<?php
							if ( '' === $tab ) :
								?>
								nav-tab-active<?php endif; ?>"><?php echo esc_html( __( 'General settings', 'ddfwm' ) ); ?></a>
						</nav>
						<?php
					}
				}

				echo '<hr class="wp-header-end">';

				if ( '' === $tab ) {
					settings_fields( 'ddfwm' );
					do_settings_sections( 'ddfwm' );
				}

				submit_button();

				?>
			</form>
		</div>
		<?php
	}


	/**
	 * Admin plugin bar.
	 *
	 * @since 1.1.0
	 */
	public static function ddfwm_admin_plugin_bar() {
		echo '<div class="ddfwm_admin_bar">' . esc_html( __( 'Developed by', 'ddfwm' ) ) . ' <a href="https://powerfulwp.com/" target="_blank">PowerfulWP</a> | <a href="https://powerfulwp.com/local-delivery-drivers-for-woocommerce-premium/" target="_blank" >' . esc_html( __( 'Premium', 'ddfwm' ) ) . '</a> | <a href="https://powerfulwp.com/docs/local-delivery-drivers-for-woocommerce-premium/" target="_blank" >' . esc_html( __( 'Documents', 'ddfwm' ) ) . '</a></div>';
	}

	/**
	 * Users list columns
	 *
	 * @param  mixed $column column.
	 * @return statement
	 */
	public function ddfwm_users_list_columns( $column ) {
		if ( isset( $_GET['role'] ) && ddfwm_vendor_role() === $_GET['role'] ) {
			$column['ddfwm_vendor_account'] = __( 'Drivers Account', 'ddfwm' );
		}
		if ( isset( $_GET['role'] ) && 'driver' === $_GET['role'] ) {
			$column['ddfwm_driver_vendor'] = __( 'Vendor', 'ddfwm' );
		}
		return $column;
	}

	/**
	 * Users list columns raw
	 *
	 * @param  mixed $val val.
	 * @param  mixed $column_name column_name.
	 * @param  mixed $user_id user_id.
	 * @return statement
	 */
	public function ddfwm_users_list_columns_raw( $val, $column_name, $user_id ) {
		$driver_account_icon = '';
		$vendor              = new DDFWM_Vendor();
		$vendor_name = '';
		if ( ddfwm_fs()->is__premium_only() ) {

			if ( ddfwm_fs()->can_use_premium_code() ) {

				$driver_account = get_user_meta( $user_id, 'ddfwm_vendor_account', true );
				$seller_id      = get_user_meta( $user_id, 'ddfwm_vendor', true );
				$vendor_name    = $vendor->ddfwm_store_name( '', $seller_id );

				/**
				 * Driver status icons and counters.
				 */
				if ( '1' === $driver_account ) {
					$driver_account_icon = '<a href="#" class="ddfwm_account_icon ddfwm_icon ddfwm_active" vendor_id="' . esc_attr( $user_id ) . '" ><i class="ddfwm-toggle-on"></i></a>';
				} else {
					$driver_account_icon = '<a href="#" class="ddfwm_account_icon ddfwm_icon" vendor_id="' . esc_attr( $user_id ) . '" ><i class="ddfwm-toggle-off"></i></a>';
				}
			}
		}
		switch ( $column_name ) {

			case 'ddfwm_vendor_account':
				return ddfwm_premium_feature( $driver_account_icon );
			case 'ddfwm_driver_vendor':
				return $vendor_name;
			default:
		}

		return $val;
	}


	/**
	 * Save user fields
	 *
	 * @since 1.0.0
	 * @param int $user_id user id.
	 */
	public function ddfwm_user_fields_save( $user_id ) {
		if ( ! current_user_can( 'edit_user', $user_id ) ) {
			return false;
		}

		$nonce_key = 'ddfwm_nonce_user';
		if ( isset( $_REQUEST[ $nonce_key ] ) ) {
			$retrieved_nonce = sanitize_text_field( wp_unslash( $_REQUEST[ $nonce_key ] ) );
			if ( ! wp_verify_nonce( $retrieved_nonce, basename( __FILE__ ) ) ) {
				die( 'Failed security check' );
			}
		}

		$user_meta  = get_userdata( $user_id );
		$user_roles = $user_meta->roles;

		// Update vendor settings.
		if ( in_array( ddfwm_vendor_role(), (array) $user_roles, true ) ) {
			$ddfwm_vendor_account = ( isset( $_POST['ddfwm_vendor_account'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_vendor_account'] ) ) : '';
			update_user_meta( $user_id, 'ddfwm_vendor_account', $ddfwm_vendor_account );

			$ddfwm_vendor_drivers = ( isset( $_POST['ddfwm_vendor_drivers'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_vendor_drivers'] ) ) : '';
			update_user_meta( $user_id, 'ddfwm_vendor_drivers', $ddfwm_vendor_drivers );
		}

		// Update driver vendor.
		if ( in_array( 'driver', (array) $user_roles, true ) ) {
			$ddfwm_vendor = ( isset( $_POST['ddfwm_vendor'] ) ) ? sanitize_text_field( wp_unslash( $_POST['ddfwm_vendor'] ) ) : '';
			update_user_meta( $user_id, 'ddfwm_vendor', $ddfwm_vendor );
		}

	}

	/**
	 * Get user fields
	 *
	 * @since 1.0.0
	 * @param object $user user data object.
	 */
	public function ddfwm_user_fields( $user ) {
		wp_nonce_field( basename( __FILE__ ), 'ddfwm_nonce_user' );

		?>
		
		<?php

		if ( in_array( ddfwm_vendor_role(), (array) $user->roles, true ) ) {

			$ddfwm_vendor_drivers = get_user_meta( $user->ID, 'ddfwm_vendor_drivers', true );
			?>
		<h3><?php echo esc_html( __( 'Vendor Delivery Drivers', 'ddfwm' ) ); ?></h3>
			<table class="form-table">
				<tr>
					<th><label for="ddfwm_vendor_account"><?php echo esc_html( __( 'Vendor account status', 'ddfwm' ) ); ?></label></th>
					<td>
						<select name="ddfwm_vendor_account" id="ddfwm_vendor_account">
							<option value="0"><?php echo esc_html( __( 'Not active', 'ddfwm' ) ); ?></option>
							<?php $selected = get_user_meta( $user->ID, 'ddfwm_vendor_account', true ) === '1' ? 'selected' : ''; ?>
							<option <?php echo esc_attr( $selected ); ?> value="1"><?php echo esc_html( __( 'Active', 'ddfwm' ) ); ?></option>
						</select>
						<p class="ddfwm_description"><?php echo esc_html( __( 'Only vendors with active accounts can access the delivery drivers manager.', 'ddfwm' ) ); ?></p>
					</td>
				</tr>
				<tr>
					<th><label for="ddfwm_vendor_drivers"><?php echo esc_html( __( 'Vendor drivers', 'ddfwm' ) ); ?></label></th>
					<td>
						<select name="ddfwm_vendor_drivers" id="ddfwm_vendor_drivers">
							<option value="0"><?php echo esc_html( __( 'Admin drivers only', 'ddfwm' ) ); ?></option>
							<?php
							if ( ddfwm_fs()->is__premium_only() ) {
								if ( ddfwm_fs()->is_plan( 'premium', true ) ) {
									?>
										<option <?php echo selected( esc_attr( $ddfwm_vendor_drivers ), '1' ); ?> value="1"><?php echo esc_html( __( 'Vendor & Admin drivers', 'ddfwm' ) ); ?></option>
										<option <?php echo selected( esc_attr( $ddfwm_vendor_drivers ), '2' ); ?> value="2"><?php echo esc_html( __( 'Vendor drivers only', 'ddfwm' ) ); ?></option>
									<?php
								}
							}
							?>
						</select>
						<p class="ddfwm_description"><?php echo esc_html( __( 'Allow vendor to work with drivers.', 'ddfwm' ) ); ?></p>
					</td>
				</tr>
			</table>
			<?php
		}

		if ( in_array( 'driver', (array) $user->roles, true ) ) {
			$vendor       = new DDFWM_Vendor();
			$ddfwm_vendor = get_user_meta( $user->ID, 'ddfwm_vendor', true );
			?>
			<table class="form-table">
				<tr>
					<th><label for="ddfwm_vendor"><?php echo esc_html( __( 'Driver Vendor', 'ddfwm' ) ); ?></label></th>
					<td>
						 <?php
							  $vendor->ddfwm_vendor_selectbox( $ddfwm_vendor, 'ddfwm_vendor' );
							?>
						<p class="ddfwm_description"><?php echo esc_html( __( 'Select the driver vendor.', 'ddfwm' ) ); ?></p>
					</td>
				</tr>
			</table>
			<?php
		}
	}

	/**
	 * Plugin settings.
	 *
	 * @since 1.0.0
	 */
	public function ddfwm_vendors_page() {
		$args  = array(
			'sort_order'   => 'asc',
			'sort_column'  => 'post_title',
			'hierarchical' => 1,
			'exclude'      => '',
			'include'      => '',
			'meta_key'     => '',
			'meta_value'   => '',
			'authors'      => '',
			'child_of'     => 0,
			'parent'       => -1,
			'exclude_tree' => '',
			'number'       => '',
			'offset'       => 0,
			'post_type'    => 'page',
			'post_status'  => 'publish',
		);
		$pages = get_pages( $args );

		?>
		<select name='ddfwm_vendors_page'>
			<?php
			if ( ! empty( $pages ) ) {
				foreach ( $pages as $page ) {
					$page_id    = $page->ID;
					$page_title = $page->post_title;
					?>
					<option value="<?php echo esc_attr( $page_id ); ?>" <?php selected( esc_attr( get_option( 'ddfwm_vendors_page', '' ) ), $page_id ); ?>><?php echo esc_html( $page_title ); ?></option>
					<?php
				}
			}
			?>
		</select>
		<p class="ddfwm_description" id="ddfwm-gooogle-api-key-description">
			<?php
			echo '<div class="driver_app">
				<p>
					<b><a target="_blank" href="' . ddfwm_vendors_page_url( '' ) . '">' . ddfwm_vendors_page_url( '' ) . '</a></b><br>' .
				sprintf( esc_html( __( 'The link above is the vendor delivery driver\'s manager URL.', 'ddfwm' ) ), '<br>', '<br>' ) .
				'
				</p>
			</div>';
			?>
		</p>
		<?php
	}

	/**
	 * Admin notices function.
	 *
	 * @since 1.0.0
	 */
	public function ddfwm_admin_notices() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			echo '<div class="notice notice-info is-dismissible">
          			<p>' . esc_html( __( 'Local delivery drivers for WooCommerce is a WooCommerce add-on, you must activate a WooCommerce on your site.', 'ddfwm' ) ) . '</p>
		 		  </div>';
		}
	}

	/**
	 * Set order commission.
	 *
	 * @param  mixed $commission .
	 * @param  mixed $order .
	 * @return statement
	 */
	public function ddfwm_set_order_commission( $commission, $order ) {
		 $driver_id = $order->get_meta( 'lddfw_driverid' );
		$seller_id  = get_user_meta( $driver_id, 'ddfwm_vendor', true );
		// if the driver works for the seller only we set the seller commision.
		if ( '' !== $seller_id ) {
			// set driver commission.
			$order_commission = $order->get_meta( 'lddfw_driver_commission' );
			if ( '' === $order_commission ) {
				$ddfwm_driver_commission_type  = get_user_meta( $seller_id, 'ddfwm_driver_commission_type', true );
				$ddfwm_driver_commission_value = get_user_meta( $seller_id, 'ddfwm_driver_commission_value', true );
				if ( '' !== $ddfwm_driver_commission_type && '' !== $ddfwm_driver_commission_value ) {

					if ( 'fixed' === $ddfwm_driver_commission_type ) {
						$commission = $ddfwm_driver_commission_value;
					}

					if ( 'delivery_percentage' === $ddfwm_driver_commission_type ) {
						$commission = $order->get_shipping_total() * $ddfwm_driver_commission_value / 100;
					}

					if ( 'order_percentage' === $ddfwm_driver_commission_type ) {
						$order_total = $order->get_total();
						$refund      = $order->get_total_refunded();
						if ( '' !== $refund ) {
							$order_total = $order_total - $refund;
						}
						$commission = $order_total * $ddfwm_driver_commission_value / 100;
					}
				}
			}
		}
		return $commission;
	}

	/**
	 * Settings tabs.
	 *
	 * @param  mixed $tabs .
	 * @since 1.0.0
	 */
	public function ddfwm_settings_tabs( $tabs ) {
		$ddfwm_tabs = array(
			array(
				'slug'  => 'ddfwm',
				'label' => esc_html( __( 'Vendors settings', 'lddfw' ) ),
				'title' => esc_html( __( 'Vendors settings', 'lddfw' ) ),
				'url'   => '?page=lddfw-settings&tab=ddfwm',
			),
		);
		return array_merge( $tabs, $ddfwm_tabs );
	}

	/**
	 * Getting driver seller.
	 *
	 * @param  mixed $driver_id .
	 * @since 1.0.0
	 */
	public function ddfwm_get_driver_seller( $driver_id ) {
		$seller_id = get_user_meta( $driver_id, 'ddfwm_vendor', true );
		if ( '' === $seller_id ) {
			$ddfwm_user      = wp_get_current_user();
			$ddfwm_vendor_id = $ddfwm_user->ID;
			$seller_drivers  = get_user_meta( $ddfwm_vendor_id, 'ddfwm_vendor_drivers', true );
			if ( '0' === $seller_drivers || '1' === $seller_drivers ) {
				$seller_id = $ddfwm_vendor_id;
			}
		}
		return strval( $seller_id );
	}

	/**
	 * Assign driver permission
	 *
	 * @param int $order_seller_id seller id.
	 * @param int $driver_seller_id seller id.
	 * @return statement
	 */
	public function ddfwm_assign_driver_permission( $order_seller_id, $driver_seller_id ) {

		// Admin order and driver.
		if ( '' === $order_seller_id && '' === $driver_seller_id ) {
			return true;
		}

		 // Seller order.
		if ( '' !== $order_seller_id ) {
			// Seller drivers permission.
			$seller_drivers = get_user_meta( $order_seller_id, 'ddfwm_vendor_drivers', true );

			if ( '1' === $seller_drivers && ( '' === $driver_seller_id || $driver_seller_id === $order_seller_id ) ) {
				// Seller allow to assign his drivers and the admin drivers.
				return true;
			} elseif ( '2' === $seller_drivers && $driver_seller_id === $order_seller_id ) {
				// Seller allow to assign his drivers only.
				return true;
			} else {
				if ( '' === $driver_seller_id && '2' !== $seller_drivers ) {
					// Seller allow to assign admin drivers only.
					return true;
				}
			}
		}
		return false;
	}

}
